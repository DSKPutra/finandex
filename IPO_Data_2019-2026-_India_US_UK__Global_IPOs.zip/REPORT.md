# IPO Data 2019-2026: India, US, UK & Global IPOs: findings, method and data card

*Fliar Research · released October 2026 · licence CC BY-NC 4.0*

**How this dataset was acquired.** Every row comes from the [Radar API](https://github.com/fliarbi/radar-api-mcp), Fliar's company-data API and MCP server. Radar reads
business news continuously, picks out sentences about initial public offerings (filings, price bands, subscriptions, pricing, listings,
withdrawals) and extracts the company, exchange, issue size, price band, issue price and dates, linking each company to its website in
a database of five million companies. This release collapses about 129,000 such reports into one row per company IPO, from January 2019 to
June 2026: India's mainboard (NSE, BSE) and SME platforms (NSE Emerge, BSE SME) in depth, plus the United States, the United Kingdom and
more than 100 other countries. Each row says whether a report confirmed the listing, carries the issue size only when it matches a money
figure in the report's own sentence, and quotes that sentence with its publisher where the article could be retrieved. The full event
timeline for any company, including follow-on offerings and every source article, is available through `POST /v1/companies/events`
([reference](https://github.com/fliarbi/radar-api-mcp/blob/main/docs/reference/get_company_events.md)) or the `get_company_events` MCP tool.

> **This file is a 38% sample: 5,000 of 13,316 company IPOs.** It keeps every record for a fixed subset of companies.
> The subset is chosen by a hash, so it stays the same from one release to the next. The findings and tables below were computed
> on the **full** data. For the rest, the withheld fields and monthly updates, [get a Radar API key](https://fliarbi.com/radar-api/developer) ([docs](https://github.com/fliarbi/radar-api-mcp)).
> Each row's `fliar_profile_url` opens the company's full profile on Fliar.

## Key findings

1. **13,316 company IPOs, January 2019 to June 2026, one row per company.** 3,014 have a report that the shares listed or the issue was priced; 186 were reported withdrawn or postponed; the rest were announced or filed.
2. **The United States (3,412 IPOs, 26%) and India (2,913, 22%) lead**, far ahead of China (841), Canada (723) and the United Kingdom (486). Of the Indian IPOs with a known board, 941 are SME issues and 955 mainboard.
3. **Indian SME IPOs took off after 2022:** 85 in 2022, 164 in 2023, 276 in 2024 and 268 in 2025. The median SME issue with a verified size is ₹31 cr; the median mainboard issue is ₹650 cr.
4. **2021 was the peak year** (2,857 IPOs, 323 of them blank-check SPACs), against 920 in 2019, 1,615 in 2022 and 2,225 in 2025. Completed listings were 697 in 2021 and 557 in 2025.
5. **Largest completed IPO: SpaceX** ($75.0B, Nasdaq, 2026), then Saudi Aramco ($29.4B, 2019) and Rivian ($12.0B). India's largest is Hyundai Motor Company (₹27,390 cr, 2024).
6. **SPACs:** 690 blank-check IPOs and 785 companies that went public by merging with one; 47% of the blank-check IPOs are dated 2021.

![IPOs per year by company country, 2019 to June 2026](figures/ipos_by_year_country.png)

![India IPOs: SME vs mainboard by year](figures/india_sme_vs_mainboard.png)

![Exchanges with the most IPOs, 2019 to June 2026](figures/top_exchanges.png)

### IPOs by year: status, India, US, China, UK and SPACs

One row per company IPO. "Raised" sums completed IPOs whose size is verified against the report sentence and reported more than once.

| Year      | IPOs   | Completed   | Withdrawn / postponed   | India mainboard   | India SME   | United States   | China   | United Kingdom   | SPAC IPOs   | Raised, completed IPOs (US$)   |
|:----------|:-------|:------------|:------------------------|:------------------|:------------|:----------------|:--------|:-----------------|:------------|:-------------------------------|
| 2019      | 920    | 118         | 24                      | 36                | 31          | 246             | 76      | 44               | 7           | $52.1B                         |
| 2020      | 1,302  | 260         | 19                      | 45                | 17          | 432             | 120     | 37               | 53          | $67.9B                         |
| 2021      | 2,857  | 697         | 38                      | 140               | 44          | 1,034           | 126     | 152              | 323         | $142.1B                        |
| 2022      | 1,615  | 281         | 51                      | 104               | 85          | 374             | 114     | 75               | 110         | $54.5B                         |
| 2023      | 1,560  | 374         | 18                      | 126               | 164         | 336             | 103     | 37               | 51          | $32.7B                         |
| 2024      | 1,985  | 556         | 13                      | 206               | 276         | 370             | 92      | 62               | 47          | $60.7B                         |
| 2025      | 2,225  | 557         | 17                      | 236               | 268         | 413             | 140     | 62               | 64          | $82.5B                         |
| 2026 (H1) | 852    | 171         | 6                       | 62                | 56          | 207             | 70      | 17               | 35          | $100.0B                        |

### IPOs by country and year (top 30 countries)

| Country              | 2019   | 2020   | 2021   | 2022   | 2023   | 2024   | 2025   | 2026 (H1)   | Total   |
|:---------------------|:-------|:-------|:-------|:-------|:-------|:-------|:-------|:------------|:--------|
| United States        | 246    | 432    | 1,034  | 374    | 336    | 370    | 413    | 207         | 3,412   |
| India                | 120    | 104    | 326    | 305    | 379    | 688    | 799    | 192         | 2,913   |
| China                | 76     | 120    | 126    | 114    | 103    | 92     | 140    | 70          | 841     |
| Canada               | 44     | 95     | 207    | 139    | 81     | 67     | 58     | 32          | 723     |
| Australia            | 54     | 85     | 122    | 93     | 53     | 36     | 32     | 11          | 486     |
| United Kingdom       | 44     | 37     | 152    | 75     | 37     | 62     | 62     | 17          | 486     |
| Brazil               | 34     | 81     | 117    | 32     | 32     | 34     | 19     | 16          | 365     |
| Singapore            | 21     | 13     | 40     | 25     | 29     | 31     | 46     | 8           | 213     |
| Hong Kong            | 18     | 17     | 29     | 27     | 18     | 41     | 43     | 15          | 208     |
| Germany              | 23     | 18     | 38     | 19     | 20     | 35     | 29     | 14          | 196     |
| Malaysia             | 10     | 3      | 11     | 11     | 17     | 48     | 53     | 25          | 178     |
| South Korea          | 3      | 17     | 32     | 14     | 31     | 26     | 30     | 14          | 167     |
| Saudi Arabia         | 6      | 8      | 15     | 25     | 24     | 25     | 28     | 10          | 141     |
| Cayman Islands       | 3      | 1      | 24     | 4      | 10     | 24     | 51     | 17          | 134     |
| Israel               | 7      | 17     | 60     | 11     | 9      | 15     | 10     | 3           | 132     |
| France               | 11     | 10     | 22     | 21     | 15     | 15     | 14     | 3           | 111     |
| United Arab Emirates | 1      | 13     | 16     | 16     | 25     | 20     | 13     | 4           | 108     |
| Japan                | 3      | 8      | 4      | 12     | 23     | 14     | 20     | 8           | 92      |
| Spain                | 5      | 7      | 22     | 8      | 12     | 15     | 15     | 5           | 89      |
| Nigeria              | 17     | 7      | 11     | 8      | 13     | 13     | 10     | 8           | 87      |
| Switzerland          | 9      | 5      | 19     | 12     | 8      | 9      | 12     | 3           | 77      |
| Italy                | 6      | 1      | 14     | 10     | 15     | 13     | 14     | 4           | 77      |
| Indonesia            | 3      | 6      | 10     | 14     | 20     | 6      | 13     | 4           | 76      |
| Pakistan             | 0      | 12     | 15     | 4      | 9      | 11     | 13     | 7           | 71      |
| Sweden               | 6      | 9      | 26     | 13     | 3      | 3      | 10     | 1           | 71      |
| Norway               | 4      | 19     | 14     | 5      | 4      | 9      | 7      | 2           | 64      |
| Netherlands          | 6      | 5      | 15     | 8      | 8      | 10     | 7      | 3           | 62      |
| Philippines          | 7      | 6      | 16     | 10     | 4      | 5      | 8      | 5           | 61      |
| Vietnam              | 6      | 11     | 12     | 4      | 6      | 2      | 12     | 3           | 56      |
| Nepal                | 1      | 1      | 10     | 8      | 6      | 5      | 14     | 8           | 53      |

### Largest IPOs worldwide, 2019 to June 2026 (top 50)

Completed IPOs with a verified size, ranked by US$. Sizes are as reported in the news and include any upsizing reported at pricing.

| #   | Company                             | Exchange                      | Board               | Country              | Sector                         | Year   | Listing date   | Issue size (local)   | Issue size (US$)   | Issue price   |
|:----|:------------------------------------|:------------------------------|:--------------------|:---------------------|:-------------------------------|:-------|:---------------|:---------------------|:-------------------|:--------------|
| 1   | SpaceX                              | Nasdaq                        | Main market         | United States        | Industrials & manufacturing    | 2026   | 2026-06-12     |                      | $75.0B             | 135           |
| 2   | Saudi Aramco                        | Saudi Exchange (Tadawul)      | Main market         | Saudi Arabia         | Energy & utilities             | 2019   | 2019-12-11     |                      | $29.4B             | 32            |
| 3   | Rivian                              | Nasdaq                        | Main market         | United States        | Automotive & EV                | 2021   | 2021-11-10     |                      | $12.0B             | 78            |
| 4   | Porsche                             | Frankfurt Stock Exchange      | Main market         | Germany              | Automotive & EV                | 2022   | 2022-09-29     |                      | $9.2B              | 82.5          |
| 5   | Uber                                | NYSE                          | Main market         | United States        | Automotive & EV                | 2019   | 2019-05-10     |                      | $8.1B              | 45            |
| 6   | China Mobile                        | Shanghai Stock Exchange       | Main market         | China                | Telecom & media                | 2022   | 2022-01-05     |                      | $7.7B              |               |
| 7   | SMIC                                | Shanghai STAR Market          | Growth / SME market | China                | Semiconductors & electronics   | 2020   |                | CNY 53,000.0M        | $7.4B              |               |
| 8   | China Telecom Global                | Shanghai Stock Exchange       | Main market         | China                | Telecom & media                | 2021   |                |                      | $7.3B              | 4.53          |
| 9   | Medline                             | Nasdaq                        | Main market         | United States        | Healthcare                     | 2025   | 2025-12-17     |                      | $6.3B              | 29            |
| 10  | DEWA                                | Dubai Financial Market        | Main market         | United Arab Emirates | Energy & utilities             | 2022   | 2022-04-12     | AED 22,410.0M        | $6.1B              | 2.48          |
| 11  | Contemporary Amperex Technology     | Hong Kong Stock Exchange      | Main market         | China                | Energy & utilities             | 2025   | 2025-02-25     |                      | $4.6B              | 263           |
| 12  | Coupang                             | NYSE                          | Main market         | South Korea          | Consumer internet & e-commerce | 2021   | 2021-03-11     |                      | $4.6B              | 35            |
| 13  | Lineage                             | Nasdaq                        | Main market         | United States        | Banking & financial services   | 2024   | 2024-07-24     |                      | $4.4B              | 78            |
| 14  | DiDi                                | NYSE                          | Main market         | China                | Automotive & EV                | 2021   | 2021-06-30     |                      | $4.4B              | 14            |
| 15  | Krafton                             | Korea Exchange (KOSPI)        | Main market         | South Korea          | Telecom & media                | 2021   |                |                      | $3.7B              | 353.02–439.51 |
| 16  | Verisure                            | Nasdaq Nordic                 | Main market         | Sweden               | Retail & consumer goods        | 2025   |                |                      | $3.7B              | 142–153       |
| 17  | DoorDash                            | NYSE                          | Main market         | United States        | Consumer internet & e-commerce | 2020   |                |                      | $3.4B              | 102           |
| 18  | Snowflake                           | NYSE                          | Main market         | United States        | Software & IT                  | 2020   | 2020-08-27     |                      | $3.4B              | 120           |
| 19  | Hyundai Motor Company               | NSE & BSE                     | Mainboard           | India                | Automotive & EV                | 2024   | 2024-10-22     |                      | $3.3B              | 1960          |
| 20  | JD Logistics                        | Hong Kong Stock Exchange      | Main market         | China                | Logistics & transport          | 2021   | 2021-05-28     |                      | $3.2B              | 40.36         |
| 21  | JX Advanced Metals Corp             | Tokyo Stock Exchange          | Main market         | Japan                | Mining & metals                | 2025   |                | JPY 439,000.0M       | $3.0B              |               |
| 22  | Puig Brands SA                      | BME Spanish Exchanges         | Main market         | Spain                | Retail & consumer goods        | 2024   |                |                      | $2.8B              | 26.38         |
| 23  | NetEase Games                       | Hong Kong Stock Exchange      | Main market         | China                | Telecom & media                | 2020   |                |                      | $2.7B              | 126           |
| 24  | GLOBALFOUNDRIES                     | Nasdaq                        | Main market         | United States        | Semiconductors & electronics   | 2021   |                |                      | $2.6B              | 47            |
| 25  | Nubank                              | NYSE                          | Main market         | Brazil               | Fintech & payments             | 2021   |                |                      | $2.6B              | 9             |
| 26  | Victory Giant                       | Hong Kong Stock Exchange      | Main market         | China                | Industrials & manufacturing    | 2026   |                | HKD 20,100.0M        | $2.6B              |               |
| 27  | Life Insurance Corporation Of India | BSE                           | Mainboard           | India                | Insurance                      | 2022   | 2022-05-17     | INR 210,000.0M       | $2.5B              | 949           |
| 28  | ADNOC Gas                           | Abu Dhabi Securities Exchange | Main market         | United Arab Emirates | Energy & utilities             | 2023   | 2023-03-13     |                      | $2.5B              | 2.37          |
| 29  | Lottomatica                         | Euronext                      | Main market         | Italy                | Telecom & media                | 2023   |                | EUR 2,260.0M         | $2.4B              | 9             |
| 30  | INNIO                               | Nasdaq                        | Main market         | Germany              | Energy & utilities             | 2026   |                |                      | $2.4B              | 27            |
| 31  | JDE Peet's                          | Euronext                      | Main market         | Netherlands          | Other                          | 2020   |                | EUR 2,250.0M         | $2.4B              | 31.5          |
| 32  | The Hut Group                       | London Stock Exchange         | Main market         | United Kingdom       | Consumer internet & e-commerce | 2020   |                | GBP 1,880.0M         | $2.4B              | 5             |
| 33  | Tokyo Metro                         | Tokyo Stock Exchange          | Main market         | Japan                | Telecom & media                | 2024   | 2024-10-23     | JPY 348,600.0M       | $2.4B              | 1200          |
| 34  | Lufax                               | NYSE                          | Main market         | China                | Fintech & payments             | 2020   |                |                      | $2.4B              | 11.5–13.5     |
| 35  | Lyft                                | Nasdaq                        | Main market         | United States        | Automotive & EV                | 2019   | 2019-03-29     |                      | $2.3B              | 72            |
| 36  | Nexi                                | Euronext Milan                | Main market         | Italy                | Fintech & payments             | 2019   |                |                      | $2.3B              | 9             |
| 37  | Madison Air                         | NYSE                          | Main market         | United States        | Industrials & manufacturing    | 2026   | 2026-04-16     |                      | $2.2B              | 27            |
| 38  | Paytm                               | BSE                           | Mainboard           | India                | Fintech & payments             | 2021   | 2021-11-10     | INR 183,000.0M       | $2.2B              | 2150          |
| 39  | KakaoBank                           | Korea Exchange (KOSPI)        | Main market         | South Korea          | Banking & financial services   | 2021   |                |                      | $2.2B              | 39000         |
| 40  | Central Retail                      | Stock Exchange of Thailand    | Main market         | Thailand             | Retail & consumer goods        | 2020   |                | THB 78,120.0M        | $2.2B              | 42            |
| 41  | Royalty Pharma                      | Nasdaq                        | Main market         | United States        | Pharma & biotech               | 2020   |                |                      | $2.2B              | 28            |
| 42  | Bumble                              | Nasdaq                        | Main market         | United States        | Software & IT                  | 2021   | 2021-02-11     |                      | $2.1B              | 43            |
| 43  | KE Holdings                         | NYSE                          | Main market         | China                | Real estate & construction     | 2020   |                |                      | $2.1B              | 20            |
| 44  | AUTO1 Group                         | Frankfurt Stock Exchange      | Main market         | Germany              | Automotive & EV                | 2021   |                |                      | $2.1B              | 38            |
| 45  | OQEP                                | Muscat Stock Exchange         | Main market         | Oman                 | Energy & utilities             | 2024   | 2024-10-28     |                      | $2.0B              | 390           |
| 46  | Applovin                            | Nasdaq                        | Main market         | United States        | Software & IT                  | 2021   |                |                      | $2.0B              | 80            |
| 47  | Talabat.com                         | Dubai Financial Market        | Main market         | United Arab Emirates | Consumer internet & e-commerce | 2024   | 2024-12-10     |                      | $2.0B              | 0.4357        |
| 48  | Deliveroo                           | London Stock Exchange         | Main market         | United Kingdom       | Consumer internet & e-commerce | 2021   | 2021-03-31     | GBP 1,500.0M         | $1.9B              | 3.9           |
| 49  | Warner Music Group                  | Nasdaq                        | Main market         | United States        | Telecom & media                | 2020   |                |                      | $1.9B              | 25            |
| 50  | Playtika                            | Nasdaq                        | Main market         | Israel               | Telecom & media                | 2021   |                |                      | $1.9B              | 27            |

### Largest US IPOs (top 50)

US-headquartered companies, any exchange.

| #   | Company                         | Exchange   | Board       | Country       | Sector                         | Year   | Listing date   | Issue size (local)   | Issue size (US$)   | Issue price   |
|:----|:--------------------------------|:-----------|:------------|:--------------|:-------------------------------|:-------|:---------------|:---------------------|:-------------------|:--------------|
| 1   | SpaceX                          | Nasdaq     | Main market | United States | Industrials & manufacturing    | 2026   | 2026-06-12     |                      | $75.0B             | 135           |
| 2   | Rivian                          | Nasdaq     | Main market | United States | Automotive & EV                | 2021   | 2021-11-10     |                      | $12.0B             | 78            |
| 3   | Uber                            | NYSE       | Main market | United States | Automotive & EV                | 2019   | 2019-05-10     |                      | $8.1B              | 45            |
| 4   | Medline                         | Nasdaq     | Main market | United States | Healthcare                     | 2025   | 2025-12-17     |                      | $6.3B              | 29            |
| 5   | Lineage                         | Nasdaq     | Main market | United States | Banking & financial services   | 2024   | 2024-07-24     |                      | $4.4B              | 78            |
| 6   | Snowflake                       | NYSE       | Main market | United States | Software & IT                  | 2020   | 2020-08-27     |                      | $3.4B              | 120           |
| 7   | DoorDash                        | NYSE       | Main market | United States | Consumer internet & e-commerce | 2020   |                |                      | $3.4B              | 102           |
| 8   | GLOBALFOUNDRIES                 | Nasdaq     | Main market | United States | Semiconductors & electronics   | 2021   |                |                      | $2.6B              | 47            |
| 9   | Lyft                            | Nasdaq     | Main market | United States | Automotive & EV                | 2019   | 2019-03-29     |                      | $2.3B              | 72            |
| 10  | Madison Air                     | NYSE       | Main market | United States | Industrials & manufacturing    | 2026   | 2026-04-16     |                      | $2.2B              | 27            |
| 11  | Royalty Pharma                  | Nasdaq     | Main market | United States | Pharma & biotech               | 2020   |                |                      | $2.2B              | 28            |
| 12  | Bumble                          | Nasdaq     | Main market | United States | Software & IT                  | 2021   | 2021-02-11     |                      | $2.1B              | 43            |
| 13  | Applovin                        | Nasdaq     | Main market | United States | Software & IT                  | 2021   |                |                      | $2.0B              | 80            |
| 14  | Warner Music Group              | Nasdaq     | Main market | United States | Telecom & media                | 2020   |                |                      | $1.9B              | 25            |
| 15  | RocketCompanies                 | NYSE       | Main market | United States | Banking & financial services   | 2020   |                |                      | $1.8B              | 18            |
| 16  | Venture Global                  | NYSE       | Main market | United States | Energy & utilities             | 2025   | 2025-01-24     |                      | $1.8B              | 25            |
| 17  | Corebridge Financial            | NYSE       | Main market | United States | Insurance                      | 2022   | 2022-09-15     |                      | $1.7B              | 21            |
| 18  | Olaplex                         | Nasdaq     | Main market | United States | Retail & consumer goods        | 2022   |                |                      | $1.6B              | 21            |
| 19  | Soaring Eagle                   | Nasdaq     | Main market | United States | Education                      | 2021   | 2021-02-24     |                      | $1.5B              | 10            |
| 20  | CoreWeave                       | Nasdaq     | Main market | United States | Software & IT                  | 2025   | 2025-03-28     |                      | $1.5B              | 40            |
| 21  | Oscar                           | NYSE       | Main market | United States | Insurance                      | 2021   |                |                      | $1.4B              | 39            |
| 22  | Pinterest                       | NYSE       | Main market | United States | Software & IT                  | 2019   | 2019-04-18     |                      | $1.4B              | 19            |
| 23  | SailPoint                       | Nasdaq     | Main market | United States | Software & IT                  | 2025   | 2025-02-12     |                      | $1.4B              | 22            |
| 24  | Unity Software                  | NYSE       | Main market | United States | Software & IT                  | 2020   |                |                      | $1.3B              | 52            |
| 25  | Agilon Health                   | NYSE       | Main market | United States | Healthcare                     | 2021   |                |                      | $1.2B              | 23            |
| 26  | Affirm                          | Nasdaq     | Main market | United States | Fintech & payments             | 2021   |                |                      | $1.2B              | 49            |
| 27  | Marqeta                         | Nasdaq     | Main market | United States | Fintech & payments             | 2021   |                |                      | $1.2B              | 27            |
| 28  | Sotera Health                   | Nasdaq     | Main market | United States | Pharma & biotech               | 2020   |                |                      | $1.2B              | 23            |
| 29  | KKR Acquisition Holdings I Corp | NYSE       | Main market | United States | Retail & consumer goods        | 2021   |                |                      | $1.2B              | 10            |
| 30  | Figma                           | NYSE       | Main market | United States | Software & IT                  | 2025   | 2025-07-31     |                      | $1.2B              | 33            |
| 31  | Array Technologies              | Nasdaq     | Main market | United States | Energy & utilities             | 2021   |                |                      | $1.2B              | 20            |
| 32  | SentinelOne                     | NYSE       | Main market | United States | Software & IT                  | 2021   |                |                      | $1.2B              | 35            |
| 33  | Peloton                         | Nasdaq     | Main market | United States | Industrials & manufacturing    | 2019   |                |                      | $1.2B              | 29            |
| 34  | Arxis                           | Nasdaq     | Main market | United States | Industrials & manufacturing    | 2026   | 2026-04-16     |                      | $1.1B              | 28            |
| 35  | Wish Shopping                   | Nasdaq     | Main market | United States | Consumer internet & e-commerce | 2020   | 2020-12-16     |                      | $1.1B              | 24            |
| 36  | Bullish                         | NYSE       | Main market | United States | Software & IT                  | 2025   | 2025-08-13     |                      | $1.1B              | 37            |
| 37  | TuSimple                        | Nasdaq     | Main market | United States | Automotive & EV                | 2021   |                |                      | $1.1B              | 40            |
| 38  | Circle                          | NYSE       | Main market | United States | Fintech & payments             | 2025   | 2025-06-05     |                      | $1.1B              | 31            |
| 39  | Beta Technologies               | NYSE       | Main market | United States | Industrials & manufacturing    | 2025   | 2025-11-04     |                      | $1.0B              | 34            |
| 40  | Chewy                           | NYSE       | Main market | United States | Retail & consumer goods        | 2019   | 2019-06-14     |                      | $1.0B              | 22            |
| 41  | Waystar                         | Nasdaq     | Main market | United States | Fintech & payments             | 2024   | 2024-06-07     |                      | $968.0M            | 21.5          |
| 42  | UL Solutions Inc                | NYSE       | Main market | United States | Industrials & manufacturing    | 2024   |                |                      | $946.0M            | 28            |
| 43  | Bright Health Group             | NYSE       | Main market | United States | Insurance                      | 2021   |                |                      | $924.3M            | 18            |
| 44  | Navan                           | Nasdaq     | Main market | United States | Hospitality & travel           | 2025   | 2025-10-30     |                      | $923.1M            | 25            |
| 45  | Netskope                        | Nasdaq     | Main market | United States | Software & IT                  | 2025   | 2025-09-18     |                      | $908.2M            | 19            |
| 46  | TOAST                           | NYSE       | Main market | United States | Retail & consumer goods        | 2021   | 2021-09-22     |                      | $870.0M            | 40            |
| 47  | Chime                           | Nasdaq     | Main market | United States | Fintech & payments             | 2025   | 2025-06-12     |                      | $864.0M            | 27            |
| 48  | Mobileye                        | Nasdaq     | Main market | United States | Automotive & EV                | 2022   |                |                      | $861.0M            | 21            |
| 49  | Janus Living, Inc               | NYSE       | Main market | United States | Real estate & construction     | 2026   | 2026-03-20     |                      | $840.0M            | 20            |
| 50  | Alliance Laundry                | NYSE       | Main market | United States | Industrials & manufacturing    | 2025   | 2025-10-09     |                      | $826.0M            | 22            |

### Largest Indian mainboard IPOs (top 50)

Rupee figures as reported; a US$-only figure is shown in rupees at ₹83 = US$1.

| #   | Company                                   | Exchange   | Board     | Country   | Sector                         | Year   | Listing date   | Issue size (₹)   | Issue size (US$)   | Issue price   |
|:----|:------------------------------------------|:-----------|:----------|:----------|:-------------------------------|:-------|:---------------|:-----------------|:-------------------|:--------------|
| 1   | Hyundai Motor Company                     | NSE & BSE  | Mainboard | India     | Automotive & EV                | 2024   | 2024-10-22     | ₹27,390 cr       | $3.3B              | 1960          |
| 2   | Life Insurance Corporation Of India       | BSE        | Mainboard | India     | Insurance                      | 2022   | 2022-05-17     | ₹21,000 cr       | $2.5B              | 949           |
| 3   | Paytm                                     | BSE        | Mainboard | India     | Fintech & payments             | 2021   | 2021-11-10     | ₹18,300 cr       | $2.2B              | 2150          |
| 4   | Tata Capital                              | NSE & BSE  | Mainboard | India     | Banking & financial services   | 2025   | 2025-10-13     | ₹15,512 cr       | $1.9B              | 326           |
| 5   | Hdb Financial Services                    | NSE & BSE  | Mainboard | India     | Banking & financial services   | 2025   | 2025-07-02     | ₹12,500 cr       | $1.5B              | 740           |
| 6   | LG Electronics India Ltd                  | NSE        | Mainboard | India     | Semiconductors & electronics   | 2025   | 2025-10-14     | ₹11,607 cr       | $1.4B              | 1140          |
| 7   | Swiggy                                    | NSE & BSE  | Mainboard | India     | Consumer internet & e-commerce | 2024   | 2024-11-13     | ₹11,327 cr       | $1.4B              | 390           |
| 8   | ICICI Prudential Asset Management Company | NSE & BSE  | Mainboard | India     | Energy & utilities             | 2025   | 2025-12-19     | ₹10,602 cr       | $1.3B              | 1053          |
| 9   | SBI Card                                  | NSE & BSE  | Mainboard | India     | Banking & financial services   | 2020   |                | ₹10,354 cr       | $1.2B              | 755           |
| 10  | Zomato                                    | BSE        | Mainboard | India     | Consumer internet & e-commerce | 2021   | 2021-07-23     | ₹9,375 cr        | $1.1B              | 76            |
| 11  | Hexaware                                  | NSE & BSE  | Mainboard | India     | Software & IT                  | 2025   | 2025-02-19     | ₹8,750 cr        | $1.1B              | 708           |
| 12  | Vishal Mega Mart                          | NSE & BSE  | Mainboard | India     | Retail & consumer goods        | 2024   | 2024-12-18     | ₹8,000 cr        | $963.9M            | 78            |
| 13  | NTPC Green Energy Ltd                     | NSE & BSE  | Mainboard | India     | Energy & utilities             | 2024   | 2024-11-27     | ₹7,500 cr        | $903.6M            | 108           |
| 14  | Lenskart                                  | NSE & BSE  | Mainboard | India     | Retail & consumer goods        | 2025   | 2025-11-10     | ₹7,278 cr        | $876.9M            | 402           |
| 15  | Groww                                     | NSE        | Mainboard | India     | Fintech & payments             | 2025   | 2025-11-12     | ₹6,630 cr        | $798.8M            | 100           |
| 16  | Bajaj Housing Finance                     | NSE & BSE  | Mainboard | India     | Banking & financial services   | 2024   | 2024-09-16     | ₹6,560 cr        | $790.4M            | 70            |
| 17  | Star Health and Allied Insurance          | NSE & BSE  | Mainboard | India     | Insurance                      | 2021   | 2021-12-10     | ₹6,400 cr        | $771.1M            | 900           |
| 18  | Ola Electric                              | NSE & BSE  | Mainboard | India     | Automotive & EV                | 2024   | 2024-08-09     | ₹6,145 cr        | $740.4M            | 76            |
| 19  | Raajmarg Infra Investment Trust           | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2026   |                | ₹6,000 cr        | $722.9M            | 99–100        |
| 20  | PB Fintech                                | BSE        | Mainboard | India     | Fintech & payments             | 2021   | 2021-11-15     | ₹5,710 cr        | $688.0M            | 980           |
| 21  | Sona Comstar                              | NSE & BSE  | Mainboard | India     | Automotive & EV                | 2021   | 2021-06-24     | ₹5,550 cr        | $668.7M            | 291           |
| 22  | Afcons                                    | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2024   | 2024-11-04     | ₹5,430 cr        | $654.2M            | 463           |
| 23  | Meesho                                    | NSE        | Mainboard | India     | Consumer internet & e-commerce | 2025   | 2025-12-10     | ₹5,421 cr        | $653.1M            | 111           |
| 24  | Nykaa                                     | NSE & BSE  | Mainboard | India     | Retail & consumer goods        | 2021   | 2021-11-10     | ₹5,350 cr        | $644.6M            | 1125          |
| 25  | Delhivery                                 | NSE & BSE  | Mainboard | India     | Logistics & transport          | 2022   | 2022-05-24     | ₹5,235 cr        | $630.7M            | 487           |
| 26  | Nuvoco                                    | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2021   | 2021-08-23     | ₹5,000 cr        | $602.4M            | 570           |
| 27  | Knowledge Realty Trust                    | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2025   |                | ₹4,800 cr        | $578.3M            | 100           |
| 28  | IRFC                                      | NSE & BSE  | Mainboard | India     | Banking & financial services   | 2021   | 2021-01-29     | ₹4,633 cr        | $558.2M            | 26            |
| 29  | Mindspace REIT                            | BSE        | Mainboard | India     | Banking & financial services   | 2021   |                | ₹4,500 cr        | $542.2M            | 275           |
| 30  | Mankind Pharma                            | NSE & BSE  | Mainboard | India     | Pharma & biotech               | 2023   | 2023-05-09     | ₹4,326 cr        | $521.2M            | 1080          |
| 31  | Waaree Energies                           | NSE & BSE  | Mainboard | India     | Energy & utilities             | 2024   | 2024-10-28     | ₹4,321 cr        | $520.6M            | 1503          |
| 32  | Bharti Hexacom                            | NSE & BSE  | Mainboard | India     | Telecom & media                | 2024   | 2024-04-12     | ₹4,275 cr        | $515.1M            | 570           |
| 33  | International Gemological Institute       | NSE & BSE  | Mainboard | India     | Retail & consumer goods        | 2024   | 2024-12-17     | ₹4,225 cr        | $509.0M            | 417           |
| 34  | NSDL                                      | BSE        | Mainboard | India     | Banking & financial services   | 2025   | 2025-08-06     | ₹4,011 cr        | $483.3M            | 800           |
| 35  | Pine Labs                                 | NSE & BSE  | Mainboard | India     | Fintech & payments             | 2025   | 2025-11-14     | ₹3,900 cr        | $469.9M            | 221           |
| 36  | Chemplast Sanmar                          | NSE & BSE  | Mainboard | India     | Chemicals & materials          | 2021   | 2021-08-24     | ₹3,850 cr        | $463.9M            | 541           |
| 37  | Brookfield India                          | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2021   |                | ₹3,800 cr        | $457.8M            | 275           |
| 38  | JSW Cement                                | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2025   | 2025-08-14     | ₹3,600 cr        | $433.7M            | 147           |
| 39  | Adani Wilmar                              | BSE        | Mainboard | India     | Retail & consumer goods        | 2022   | 2022-02-08     | ₹3,600 cr        | $433.7M            | 230           |
| 40  | Tenneco Clean Air India                   | NSE & BSE  | Mainboard | India     | Automotive & EV                | 2025   |                | ₹3,600 cr        | $433.7M            | 397           |
| 41  | Schloss                                   | NSE & BSE  | Mainboard | India     | Hospitality & travel           | 2025   | 2025-06-02     | ₹3,500 cr        | $421.7M            | 435           |
| 42  | Physicswallah                             | NSE & BSE  | Mainboard | India     | Software & IT                  | 2025   | 2025-11-18     | ₹3,480 cr        | $419.3M            | 109           |
| 43  | Anthem Biosciences                        | NSE & BSE  | Mainboard | India     | Pharma & biotech               | 2025   | 2025-07-21     | ₹3,278 cr        | $395.0M            | 570           |
| 44  | Vedant Fashions                           | NSE & BSE  | Mainboard | India     | Retail & consumer goods        | 2022   | 2022-02-16     | ₹3,150 cr        | $379.5M            | 866           |
| 45  | Tata Technologies                         | NSE & BSE  | Mainboard | India     | Software & IT                  | 2023   | 2023-11-30     | ₹3,042 cr        | $366.6M            | 500           |
| 46  | Sai Life Sciences                         | NSE & BSE  | Mainboard | India     | Pharma & biotech               | 2024   | 2024-12-18     | ₹3,040 cr        | $366.3M            | 549           |
| 47  | WeWork                                    | NSE & BSE  | Mainboard | India     | Real estate & construction     | 2025   | 2025-10-10     | ₹3,000 cr        | $361.4M            | 644.85        |
| 48  | Aadhar Housing Finance                    | NSE & BSE  | Mainboard | India     | Banking & financial services   | 2024   | 2024-05-10     | ₹3,000 cr        | $361.4M            | 315           |
| 49  | Ather Energy                              | NSE & BSE  | Mainboard | India     | Automotive & EV                | 2025   | 2025-05-06     | ₹2,981 cr        | $359.2M            | 321           |
| 50  | Emmvee                                    | NSE & BSE  | Mainboard | India     | Energy & utilities             | 2025   | 2025-11-18     | ₹2,900 cr        | $349.4M            | 217           |

### India SME vs mainboard IPOs by year

Board is known for Indian IPOs whose reports name the exchange or the SME segment; others are counted in the country tables only.

| Year      | SME IPOs   | SME completed   | NSE Emerge   | BSE SME   | Median SME issue   | Mainboard IPOs   | Mainboard completed   | Median mainboard issue   | Mainboard raised (completed, verified)   |
|:----------|:-----------|:----------------|:-------------|:----------|:-------------------|:-----------------|:----------------------|:-------------------------|:-----------------------------------------|
| 2019      | 31         | 0               | 10           | 20        | ₹11 cr             | 36               | 12                    | ₹562 cr                  | ₹3,711 cr                                |
| 2020      | 17         | 3               | 6            | 11        | ₹9 cr              | 45               | 19                    | ₹518 cr                  | ₹19,747 cr                               |
| 2021      | 44         | 4               | 18           | 24        | ₹18 cr             | 140              | 77                    | ₹963 cr                  | ₹128,485 cr                              |
| 2022      | 85         | 6               | 37           | 45        | ₹16 cr             | 104              | 44                    | ₹740 cr                  | ₹58,063 cr                               |
| 2023      | 164        | 64              | 103          | 57        | ₹23 cr             | 126              | 74                    | ₹500 cr                  | ₹45,486 cr                               |
| 2024      | 276        | 148             | 196          | 73        | ₹32 cr             | 206              | 99                    | ₹577 cr                  | ₹151,182 cr                              |
| 2025      | 268        | 98              | 108          | 154       | ₹38 cr             | 236              | 115                   | ₹720 cr                  | ₹172,293 cr                              |
| 2026 (H1) | 56         | 16              | 21           | 31        | ₹40 cr             | 62               | 26                    | ₹440 cr                  | ₹22,050 cr                               |

### Largest Indian SME IPOs (top 30)

Verified SME issue sizes, any status (most SME issues are reported at subscription rather than at listing).

| #   | Company                              | Exchange                        | Board   | Country   | Sector                       | Year   | Listing date   | Issue size (₹)   | Issue size (US$)   | Issue price   |
|:----|:-------------------------------------|:--------------------------------|:--------|:----------|:-----------------------------|:-------|:---------------|:-----------------|:-------------------|:--------------|
| 1   | Rosmerta Digital Services Limited    | BSE SME                         | SME     | India     | Automotive & EV              | 2024   |                | ₹206 cr          | $24.9M             | 140–147       |
| 2   | AVPL International                   | NSE Emerge (SME)                | SME     | India     | Agriculture                  | 2023   |                | ₹200 cr          | $24.1M             |               |
| 3   | Danish Power                         | NSE Emerge (SME)                | SME     | India     | Industrials & manufacturing  | 2024   | 2024-10-24     | ₹198 cr          | $23.9M             | 380           |
| 4   | Ishue                                | India SME (exchange not stated) | SME     | India     |                              | 2024   |                | ₹198 cr          | $23.9M             | 360–380       |
| 5   | Sahasra                              | NSE Emerge (SME)                | SME     | India     | Semiconductors & electronics | 2024   |                | ₹186 cr          | $22.4M             | 269–283       |
| 6   | Sahasra Electronic Solutions Limited | NSE Emerge (SME)                | SME     | India     | Semiconductors & electronics | 2024   |                | ₹186 cr          | $22.4M             | 283           |
| 7   | Capital Numbers                      | BSE SME                         | SME     | India     | Software & IT                | 2025   | 2025-01-27     | ₹169 cr          | $20.4M             | 263           |
| 8   | Archit Nuwood                        | BSE SME                         | SME     | India     | Industrials & manufacturing  | 2024   |                | ₹168 cr          | $20.3M             | 257–270       |
| 9   | Monika Alcobev                       | BSE SME                         | SME     | India     | Retail & consumer goods      | 2025   |                | ₹166 cr          | $20.0M             | 286           |
| 10  | Rajesh Power                         | BSE SME                         | SME     | India     | Energy & utilities           | 2025   |                | ₹160 cr          | $19.3M             | 335           |
| 11  | Vinyas Innovative Technologies       | NSE Emerge (SME)                | SME     | India     | Semiconductors & electronics | 2023   |                | ₹152 cr          | $18.3M             | 165           |
| 12  | Vivid Electromech                    | NSE Emerge (SME)                | SME     | India     | Industrials & manufacturing  | 2026   |                | ₹131 cr          | $15.7M             | 555           |
| 13  | True Colors                          | BSE SME                         | SME     | India     | Software & IT                | 2025   |                | ₹128 cr          | $15.4M             | 191           |
| 14  | Ganesh Green Bharat                  | NSE Emerge (SME)                | SME     | India     | Energy & utilities           | 2024   |                | ₹125 cr          | $15.1M             | 190           |
| 15  | Shreeref                             | BSE SME                         | SME     | India     | Industrials & manufacturing  | 2025   | 2025-08-01     | ₹117 cr          | $14.1M             | 119–125       |
| 16  | Tunwal                               | NSE Emerge (SME)                | SME     | India     | Automotive & EV              | 2024   |                | ₹116 cr          | $13.9M             | 59            |
| 17  | Nisus Finance Services               | BSE SME                         | SME     | India     | Banking & financial services | 2024   |                | ₹114 cr          | $13.8M             | 180           |
| 18  | Yash Highvoltage                     | BSE SME                         | SME     | India     | Industrials & manufacturing  | 2024   |                | ₹110 cr          | $13.3M             | 146           |
| 19  | Chandan                              | NSE Emerge (SME)                | SME     | India     | Healthcare                   | 2025   |                | ₹107 cr          | $12.9M             | 159           |
| 20  | Solar 91                             | BSE SME                         | SME     | India     | Energy & utilities           | 2024   |                | ₹106 cr          | $12.8M             | 195           |
| 21  | Spectrum Talent Management           | NSE Emerge (SME)                | SME     | India     | Other                        | 2023   |                | ₹105 cr          | $12.7M             |               |
| 22  | FlySBS Aviation Limited              | NSE Emerge (SME)                | SME     | India     | Hospitality & travel         | 2025   |                | ₹103 cr          | $12.4M             | 210–225       |
| 23  | Aashka Hospital                      | BSE SME                         | SME     | India     | Healthcare                   | 2021   |                | ₹102 cr          | $12.2M             | 121           |
| 24  | Shiv Texchem                         | BSE SME                         | SME     | India     | Chemicals & materials        | 2024   |                | ₹101 cr          | $12.2M             | 158–166       |
| 25  | Goel Construction Pvt Ltd            | BSE SME                         | SME     | India     | Real estate & construction   | 2025   |                | ₹100 cr          | $12.0M             | 263           |
| 26  | C2C Advanced Systems                 | NSE Emerge (SME)                | SME     | India     | Semiconductors & electronics | 2024   |                | ₹99 cr           | $11.9M             | 226           |
| 27  | Pushpa Jewellers                     | NSE Emerge (SME)                | SME     | India     | Retail & consumer goods      | 2025   |                | ₹99 cr           | $11.9M             | 143–147       |
| 28  | Usha Financial                       | NSE Emerge (SME)                | SME     | India     | Banking & financial services | 2024   |                | ₹98 cr           | $11.9M             | 168           |
| 29  | ABS Marine Services                  | NSE Emerge (SME)                | SME     | India     | Other                        | 2024   |                | ₹96 cr           | $11.6M             | 147           |
| 30  | Jd Cables                            | BSE SME                         | SME     | India     | Energy & utilities           | 2025   |                | ₹96 cr           | $11.6M             | 144–152       |

### IPOs by exchange (top 40)

Exchange as reported; dual listings count under the exchange named most often. Companies list on foreign exchanges too (Chinese companies on NYSE, for example).

| #   | Exchange                                   | Most common company country   | IPOs   | Completed   | Busiest year   | Median completed IPO (US$)   | Raised, completed (US$)   | Largest completed IPO               |
|:----|:-------------------------------------------|:------------------------------|:-------|:------------|:---------------|:-----------------------------|:--------------------------|:------------------------------------|
| 1   | Nasdaq                                     | United States                 | 2,567  | 898         | 2021           | $200.0M                      | $205.1B                   | SpaceX                              |
| 2   | NYSE                                       | United States                 | 902    | 312         | 2021           | $420.0M                      | $97.5B                    | Uber                                |
| 3   | NSE & BSE                                  | India                         | 649    | 368         | 2025           | $77.1M                       | $56.5B                    | Hyundai Motor Company               |
| 4   | Hong Kong Stock Exchange                   | China                         | 540    | 90          | 2025           | $484.9M                      | $33.9B                    | Contemporary Amperex Technology     |
| 5   | NSE Emerge (SME)                           | India                         | 499    | 196         | 2024           | $4.3M                        | $715.2M                   | Danish Power                        |
| 6   | ASX                                        | Australia                     | 420    | 84          | 2021           | $10.9M                       | $5.0B                     | Tyro                                |
| 7   | BSE SME                                    | India                         | 418    | 141         | 2025           | $3.4M                        | $418.8M                   | Capital Numbers                     |
| 8   | TSX Venture                                | Canada                        | 309    | 50          | 2021           | $2.0M                        | $218.1M                   | Pivotree                            |
| 9   | London Stock Exchange                      | United Kingdom                | 280    | 44          | 2021           | $474.9M                      | $14.2B                    | The Hut Group                       |
| 10  | NSE                                        | India                         | 162    | 42          | 2025           | $98.8M                       | $4.8B                     | LG Electronics India Ltd            |
| 11  | B3 (Brazil)                                | Brazil                        | 149    | 25          | 2021           | $168.7M                      | $1.2B                     | Hidrovias                           |
| 12  | BSE                                        | India                         | 145    | 56          | 2021           | $151.2M                      | $11.1B                    | Life Insurance Corporation Of India |
| 13  | TSX                                        | Canada                        | 129    | 32          | 2021           | $92.6M                       | $4.2B                     | Nuvei                               |
| 14  | Frankfurt Stock Exchange                   | Germany                       | 123    | 26          | 2024           | $2.1B                        | $11.4B                    | Porsche                             |
| 15  | Singapore Exchange (SGX)                   | Singapore                     | 116    | 21          | 2025           | $4.8M                        | $986.0M                   | Digital Core REIT                   |
| 16  | Shanghai Stock Exchange                    | China                         | 111    | 21          | 2021           | $1.5B                        | $19.0B                    | China Mobile                        |
| 17  | London AIM                                 | United Kingdom                | 108    | 9           | 2021           | $29.8M                       | $148.1M                   | AOTI Inc                            |
| 18  | OTC Markets (US)                           | Canada                        | 107    | 24          | 2025           | $3.0M                        | $3.0M                     | Pinnacle Minerals                   |
| 19  | Euronext Growth / BME Growth               | France                        | 107    | 11          | 2021           | $91.4M                       | $91.4M                    | Hydrogen Refueling Solutions        |
| 20  | Saudi Exchange (Tadawul)                   | Saudi Arabia                  | 94     | 25          | 2025           | $314.0M                      | $37.7B                    | Saudi Aramco                        |
| 21  | Euronext                                   | France                        | 92     | 17          | 2021           | $1.3B                        | $5.2B                     | Lottomatica                         |
| 22  | NYSE American                              | United States                 | 92     | 33          | 2024           | $15.0M                       | $742.0M                   | Berenson Acquisition I              |
| 23  | Canadian Securities Exchange / Cboe Canada | Canada                        | 84     | 21          | 2022           | $5.9M                        | $140.6M                   | Ceres                               |
| 24  | Nasdaq Nordic                              | Sweden                        | 70     | 12          | 2021           | $3.7B                        | $3.7B                     | Verisure                            |
| 25  | KOSDAQ                                     | South Korea                   | 63     | 7           | 2023           | $288.0M                      | $288.0M                   | Kakao Games                         |
| 26  | Pakistan Stock Exchange                    | Pakistan                      | 60     | 10          | 2021           | $1.7M                        | $1.7M                     | Supernet                            |
| 27  | Bursa Malaysia                             | Malaysia                      | 59     | 24          | 2025           | $519.2M                      | $519.2M                   | 99 Speed Mart Retail Holdings       |
| 28  | Nigerian Exchange (NGX)                    | Nigeria                       | 59     | 15          | 2024           |                              |                           |                                     |
| 29  | Bursa Malaysia ACE Market                  | Malaysia                      | 57     | 16          | 2024           |                              |                           |                                     |
| 30  | Tokyo Stock Exchange                       | Japan                         | 54     | 11          | 2023           | $750.0M                      | $8.2B                     | JX Advanced Metals Corp             |
| 31  | SIX Swiss Exchange                         | Switzerland                   | 51     | 9           | 2022           | $190.5M                      | $1.3B                     | SMG Swiss Marketplace Group         |
| 32  | Indonesia Stock Exchange                   | Indonesia                     | 47     | 8           | 2023           | $640.0M                      | $4.7B                     | Bukalapak                           |
| 33  | Philippine Stock Exchange                  | Philippines                   | 45     | 7           | 2021           | $617.4M                      | $1.5B                     | Monde Nissin                        |
| 34  | Korea Exchange (KOSPI)                     | South Korea                   | 41     | 14          | 2021           | $820.0M                      | $10.4B                    | Krafton                             |
| 35  | Abu Dhabi Securities Exchange              | United Arab Emirates          | 39     | 17          | 2023           | $857.3M                      | $9.5B                     | ADNOC Gas                           |
| 36  | Shenzhen Stock Exchange                    | China                         | 38     | 0           | 2022           |                              |                           |                                     |
| 37  | Jamaica Stock Exchange                     | Jamaica                       | 33     | 5           | 2019           |                              |                           |                                     |
| 38  | Colombo Stock Exchange                     | Sri Lanka                     | 32     | 15          | 2021           |                              |                           |                                     |
| 39  | Shanghai STAR Market                       | China                         | 31     | 4           | 2019           | $602.0M                      | $8.4B                     | SMIC                                |
| 40  | BME Spanish Exchanges                      | Spain                         | 29     | 4           | 2024           | $562.7M                      | $3.6B                     | Puig Brands SA                      |

### US IPOs by exchange and year

US-headquartered companies.

| Exchange                                   | 2019   | 2020   | 2021   | 2022   | 2023   | 2024   | 2025   | 2026 (H1)   | Total   |
|:-------------------------------------------|:-------|:-------|:-------|:-------|:-------|:-------|:-------|:------------|:--------|
| Nasdaq                                     | 146    | 261    | 606    | 196    | 158    | 163    | 217    | 125         | 1,872   |
| NYSE                                       | 41     | 88     | 260    | 65     | 59     | 71     | 74     | 30          | 688     |
| NYSE American                              | 2      | 5      | 7      | 8      | 13     | 13     | 9      | 3           | 60      |
| OTC Markets (US)                           | 1      | 5      | 8      | 4      | 6      | 8      | 4      | 7           | 43      |
| US (exchange not stated)                   | 1      | 1      | 4      | 3      | 4      | 3      | 3      | 3           | 22      |
| London Stock Exchange                      | 2      | 2      | 2      | 2      | 0      | 1      | 1      | 0           | 10      |
| TSX Venture                                | 1      | 1      | 0      | 2      | 4      | 0      | 0      | 0           | 8       |
| Frankfurt Stock Exchange                   | 0      | 1      | 0      | 1      | 0      | 0      | 2      | 0           | 4       |
| London AIM                                 | 0      | 0      | 1      | 0      | 0      | 0      | 2      | 0           | 3       |
| ASX                                        | 0      | 1      | 0      | 0      | 1      | 0      | 0      | 0           | 2       |
| BSE SME                                    | 0      | 0      | 1      | 0      | 0      | 0      | 1      | 0           | 2       |
| Canadian Securities Exchange / Cboe Canada | 0      | 0      | 1      | 0      | 1      | 0      | 0      | 0           | 2       |
| B3 (Brazil)                                | 0      | 0      | 0      | 0      | 0      | 0      | 1      | 0           | 1       |
| Euronext Growth / BME Growth               | 0      | 1      | 0      | 0      | 0      | 0      | 0      | 0           | 1       |
| Hong Kong Stock Exchange                   | 0      | 0      | 0      | 0      | 0      | 0      | 1      | 0           | 1       |
| KOSDAQ                                     | 0      | 0      | 0      | 0      | 1      | 0      | 0      | 0           | 1       |
| Korea Exchange (KOSPI)                     | 0      | 0      | 0      | 0      | 1      | 0      | 0      | 0           | 1       |
| Mexican Stock Exchange                     | 0      | 0      | 1      | 0      | 0      | 0      | 0      | 0           | 1       |
| Philippine Stock Exchange                  | 0      | 0      | 1      | 0      | 0      | 0      | 0      | 0           | 1       |

### UK IPOs by exchange and year

UK-headquartered companies (London Main Market, AIM and overseas listings).

| Exchange                     | 2019   | 2020   | 2021   | 2022   | 2023   | 2024   | 2025   | 2026 (H1)   | Total   |
|:-----------------------------|:-------|:-------|:-------|:-------|:-------|:-------|:-------|:------------|:--------|
| London Stock Exchange        | 18     | 18     | 66     | 32     | 22     | 26     | 26     | 6           | 214     |
| London AIM                   | 8      | 6      | 36     | 15     | 4      | 13     | 4      | 4           | 90      |
| Nasdaq                       | 3      | 3      | 15     | 3      | 3      | 1      | 7      | 0           | 35      |
| NYSE                         | 0      | 0      | 6      | 1      | 2      | 1      | 2      | 1           | 13      |
| TSX Venture                  | 0      | 0      | 1      | 0      | 1      | 0      | 0      | 1           | 3       |
| Euronext                     | 1      | 0      | 1      | 0      | 0      | 1      | 0      | 0           | 3       |
| ASX                          | 0      | 0      | 0      | 0      | 0      | 0      | 2      | 0           | 2       |
| OTC Markets (US)             | 0      | 0      | 1      | 0      | 0      | 0      | 1      | 0           | 2       |
| Hong Kong Stock Exchange     | 1      | 0      | 0      | 1      | 0      | 0      | 0      | 0           | 2       |
| Casablanca Stock Exchange    | 0      | 0      | 0      | 0      | 0      | 1      | 0      | 0           | 1       |
| Euronext Growth / BME Growth | 0      | 0      | 1      | 0      | 0      | 0      | 0      | 0           | 1       |
| Euronext Amsterdam           | 0      | 0      | 0      | 1      | 0      | 0      | 0      | 0           | 1       |
| NYSE American                | 0      | 0      | 0      | 0      | 0      | 1      | 0      | 0           | 1       |
| TSX                          | 0      | 0      | 0      | 1      | 0      | 0      | 0      | 0           | 1       |
| US (exchange not stated)     | 0      | 0      | 0      | 0      | 0      | 0      | 1      | 0           | 1       |

### Largest UK IPOs (top 26)

| #   | Company                         | Exchange              | Board               | Country        | Sector                         | Year   | Listing date   | Issue size (local)   | Issue size (US$)   | Issue price   |
|:----|:--------------------------------|:----------------------|:--------------------|:---------------|:-------------------------------|:-------|:---------------|:---------------------|:-------------------|:--------------|
| 1   | The Hut Group                   | London Stock Exchange | Main market         | United Kingdom | Consumer internet & e-commerce | 2020   |                | GBP 1,880.0M         | $2.4B              | 5             |
| 2   | Deliveroo                       | London Stock Exchange | Main market         | United Kingdom | Consumer internet & e-commerce | 2021   | 2021-03-31     | GBP 1,500.0M         | $1.9B              | 3.9           |
| 3   | Bridgepoint Capital             | London Stock Exchange | Main market         | United Kingdom | Other                          | 2021   |                | GBP 789.0M           | $1.0B              |               |
| 4   | Moonpig                         | London Stock Exchange | Main market         | United Kingdom | Retail & consumer goods        | 2021   |                |                      | $884.0M            | 350           |
| 5   | Admiral Acquisition             | London Stock Exchange | Main market         | United Kingdom | Banking & financial services   | 2023   |                |                      | $550.0M            |               |
| 6   | Pantheon Infrastructure         | London Stock Exchange | Main market         | United Kingdom | Real estate & construction     | 2021   |                | GBP 400.0M           | $508.0M            |               |
| 7   | Mayflower                       | London Stock Exchange | Main market         | United Kingdom |                                | 2025   |                |                      | $500.0M            |               |
| 8   | Cordiant Digital                | London Stock Exchange | Main market         | United Kingdom | Real estate & construction     | 2021   |                | GBP 370.0M           | $469.9M            | 100           |
| 9   | CAB Payments                    | London Stock Exchange | Main market         | United Kingdom | Fintech & payments             | 2023   |                | GBP 335.0M           | $425.4M            | 3.35          |
| 10  | Nanopore Technologies           | London Stock Exchange | Main market         | United Kingdom | Pharma & biotech               | 2021   |                | GBP 330.1M           | $419.2M            |               |
| 11  | Digital 9 Infrastructure        | London Stock Exchange | Main market         | United Kingdom | Real estate & construction     | 2021   |                | GBP 300.0M           | $381.0M            | 1             |
| 12  | Broadstone Acquisition          | NYSE                  | Main market         | United Kingdom | Banking & financial services   | 2021   |                |                      | $300.0M            |               |
| 13  | Seraphim Space Investment Trust | London Stock Exchange | Main market         | United Kingdom | Software & IT                  | 2023   |                |                      | $250.0M            |               |
| 14  | Raspberry Pi                    | London Stock Exchange | Main market         | United Kingdom | Software & IT                  | 2024   |                | GBP 178.9M           | $227.2M            |               |
| 15  | Axios                           | NYSE                  | Main market         | United Kingdom | Retail & consumer goods        | 2022   |                |                      | $150.0M            | 10            |
| 16  | Beauty Tech Group               | London Stock Exchange | Main market         | United Kingdom | Retail & consumer goods        | 2025   |                | GBP 107.0M           | $135.9M            | 271           |
| 17  | Argo Blockchain                 | Nasdaq                | Main market         | United Kingdom | Fintech & payments             | 2023   |                |                      | $112.0M            |               |
| 18  | AOTI Inc                        | London AIM            | Growth / SME market | United Kingdom | Healthcare                     | 2024   |                | GBP 35.1M            | $44.6M             |               |
| 19  | Essensys                        | London AIM            | Growth / SME market | United Kingdom | Software & IT                  | 2019   |                | GBP 28.0M            | $35.6M             |               |
| 20  | Inspecs                         | London AIM            | Growth / SME market | United Kingdom | Other                          | 2020   |                | GBP 23.5M            | $29.8M             |               |
| 21  | Calnex Solutions                | London AIM            | Growth / SME market | United Kingdom | Telecom & media                | 2020   |                | GBP 22.5M            | $28.6M             |               |
| 22  | Tc Biopharm                     | Nasdaq                | Main market         | United Kingdom | Pharma & biotech               | 2025   |                |                      | $17.5M             | 0.4           |
| 23  | Power Probe                     | London Stock Exchange | Main market         | United Kingdom | Automotive & EV                | 2026   |                |                      | $15.0M             |               |
| 24  | Selkirk                         | London Stock Exchange | Main market         | United Kingdom | Retail & consumer goods        | 2024   |                | GBP 7.5M             | $9.5M              | 2.4           |
| 25  | Helix Exploration               | London AIM            | Growth / SME market | United Kingdom | Other                          | 2024   |                | GBP 7.5M             | $9.5M              |               |
| 26  | Perfect Moment                  | NYSE American         | Main market         | United Kingdom | Retail & consumer goods        | 2024   |                |                      | $8.0M              | 6             |

### IPOs by sector

Sector is read from the IPO reports, else from the company database, and grouped into 20 broad sectors.

| Sector                         | IPOs   | Completed   | India   | United States   | China   | Median completed IPO (US$)   | Raised, completed (US$)   | Largest completed IPOs                                                      |
|:-------------------------------|:-------|:------------|:--------|:----------------|:--------|:-----------------------------|:--------------------------|:----------------------------------------------------------------------------|
| Retail & consumer goods        | 1,196  | 266         | 333     | 260             | 87      | $169.3M                      | $46.8B                    | Verisure, Puig Brands SA, Central Retail                                    |
| Software & IT                  | 1,062  | 323         | 198     | 355             | 76      | $150.0M                      | $48.4B                    | Snowflake, Bumble, Applovin                                                 |
| Pharma & biotech               | 1,046  | 274         | 94      | 610             | 72      | $121.5M                      | $22.7B                    | Royalty Pharma, Nahdi, Sotera Health                                        |
| Banking & financial services   | 974    | 264         | 171     | 331             | 23      | $128.8M                      | $34.7B                    | Lineage, KakaoBank, Tata Capital                                            |
| Other                          | 924    | 132         | 132     | 238             | 65      | $60.0M                       | $9.5B                     | JDE Peet's, Bridgepoint Capital, DiamondPeak Holdings                       |
| Energy & utilities             | 841    | 161         | 177     | 152             | 58      | $111.0M                      | $67.6B                    | Saudi Aramco, DEWA, Contemporary Amperex Technology                         |
| Healthcare                     | 765    | 209         | 136     | 287             | 50      | $136.2M                      | $26.4B                    | Medline, United-Imaging, Agilon Health                                      |
| Real estate & construction     | 634    | 153         | 219     | 110             | 31      | $72.3M                       | $16.8B                    | KE Holdings, Shimao, Janus Living, Inc                                      |
| Mining & metals                | 608    | 147         | 79      | 39              | 10      | $9.9M                        | $6.6B                     | JX Advanced Metals Corp, Chuangxin Industries Holdings, Amman Mineral       |
| Telecom & media                | 526    | 112         | 76      | 120             | 17      | $193.2M                      | $41.7B                    | China Mobile, China Telecom Global, Krafton                                 |
| Industrials & manufacturing    | 521    | 183         | 306     | 55              | 23      | $18.6M                       | $91.1B                    | SpaceX, Victory Giant, Madison Air                                          |
| Fintech & payments             | 392    | 105         | 59      | 119             | 18      | $240.0M                      | $31.5B                    | Nubank, Lufax, Nexi                                                         |
| Automotive & EV                | 385    | 117         | 110     | 81              | 62      | $190.0M                      | $58.5B                    | Rivian, Porsche, Uber                                                       |
| Consumer internet & e-commerce | 274    | 71          | 50      | 49              | 28      | $391.0M                      | $29.2B                    | Coupang, DoorDash, The Hut Group                                            |
| Hospitality & travel           | 248    | 68          | 83      | 53              | 5       | $158.0M                      | $7.3B                     | Navan, Virgin Australia, Aer Lingus                                         |
| Semiconductors & electronics   | 229    | 49          | 57      | 41              | 63      | $101.2M                      | $17.4B                    | SMIC, GLOBALFOUNDRIES, LG Electronics India Ltd                             |
| Chemicals & materials          | 209    | 50          | 127     | 10              | 5       | $28.4M                       | $2.4B                     | Chemplast Sanmar, Clean Science and Technology, Archean Chemical Industries |
| Logistics & transport          | 207    | 54          | 84      | 16              | 17      | $48.1M                       | $9.6B                     | JD Logistics, Full Truck Alliance, Abu Dhabi Ports Group                    |
| Insurance                      | 181    | 37          | 36      | 51              | 13      | $364.0M                      | $14.0B                    | Life Insurance Corporation Of India, Corebridge Financial, Oscar            |
| Agriculture                    | 85     | 18          | 36      | 9               | 4       | $5.2M                        | $1.4B                     | Muyuan Food, Nova Agritech, Uma Exports                                     |
| Education                      | 66     | 16          | 19      | 14              | 7       | $170.0M                      | $3.1B                     | Soaring Eagle, KinderCare Learning, Alef Education                          |

### IPOs by sector and year

| Sector                         | 2019   | 2020   | 2021   | 2022   | 2023   | 2024   | 2025   | 2026 (H1)   | Total   |
|:-------------------------------|:-------|:-------|:-------|:-------|:-------|:-------|:-------|:------------|:--------|
| Retail & consumer goods        | 100    | 98     | 258    | 154    | 143    | 181    | 195    | 67          | 1,196   |
| Software & IT                  | 58     | 112    | 270    | 118    | 110    | 137    | 188    | 69          | 1,062   |
| Pharma & biotech               | 107    | 194    | 251    | 84     | 101    | 99     | 169    | 41          | 1,046   |
| Banking & financial services   | 65     | 104    | 244    | 121    | 109    | 150    | 140    | 41          | 974     |
| Other                          | 75     | 103    | 183    | 108    | 124    | 124    | 143    | 64          | 924     |
| Energy & utilities             | 51     | 52     | 155    | 120    | 107    | 155    | 133    | 68          | 841     |
| Healthcare                     | 67     | 98     | 201    | 77     | 84     | 93     | 113    | 32          | 765     |
| Real estate & construction     | 42     | 62     | 100    | 55     | 76     | 118    | 140    | 41          | 634     |
| Mining & metals                | 29     | 55     | 126    | 111    | 75     | 67     | 93     | 52          | 608     |
| Telecom & media                | 44     | 56     | 139    | 67     | 64     | 71     | 63     | 22          | 526     |
| Industrials & manufacturing    | 28     | 21     | 51     | 53     | 69     | 118    | 139    | 42          | 521     |
| Fintech & payments             | 28     | 37     | 102    | 56     | 38     | 40     | 61     | 30          | 392     |
| Automotive & EV                | 8      | 24     | 89     | 55     | 52     | 75     | 56     | 26          | 385     |
| Consumer internet & e-commerce | 20     | 28     | 96     | 35     | 30     | 24     | 32     | 9           | 274     |
| Hospitality & travel           | 22     | 26     | 39     | 19     | 32     | 54     | 45     | 11          | 248     |
| Semiconductors & electronics   | 9      | 14     | 24     | 39     | 37     | 42     | 40     | 24          | 229     |
| Chemicals & materials          | 9      | 14     | 36     | 37     | 20     | 35     | 43     | 15          | 209     |
| Logistics & transport          | 10     | 14     | 32     | 35     | 32     | 36     | 40     | 8           | 207     |
| Insurance                      | 13     | 27     | 34     | 20     | 23     | 24     | 30     | 10          | 181     |
| Agriculture                    | 6      | 7      | 11     | 9      | 12     | 15     | 12     | 13          | 85      |
| Education                      | 8      | 9      | 8      | 10     | 3      | 11     | 14     | 3           | 66      |

## Method

1. **Extraction.** Radar's pipeline reads each business-news article, classifies IPO sentences and extracts the company, exchange, currency, issue size, price band, issue price, listing date and IPO type. Follow-on offerings, offers for sale on their own, QIPs and rights issues are excluded.
2. **One row per company IPO.** Reports are grouped by the company's website; reports with only a name join the website their name maps to. Name variants are then merged in four passes: one name's words start the other's or the names are 90%+ similar (same year, compatible country); a short and long name on the same exchange and year (Uber / Uber Technologies); the same verified US$200M+ amount in the same year under related names (ADNOC / ADNOC Gas); a name-only report whose words contain a linked company's full name. Series numbers keep SPACs apart (Acquisition II vs III). A handful of merges were made by hand after reading the largest rows.
3. **Names.** Descriptions are stripped ("Saudi Arabia's state-owned oil giant Aramco" → Aramco); placeholders, exchanges, people and descriptions ("Zomato-backed startup") are dropped.
4. **Status.** `Completed` needs a report sentence that names the company and says the shares listed, debuted or began trading, the issue was priced or oversubscribed, or the IPO raised money, with no plan language (will, expected, plans, filed, draft) unless the sentence also says the stock debuted or traded. `Withdrawn / postponed` is a company with a quarter or more of its reports about a suspension, withdrawal, postponement or cancellation and no trading report.
5. **Dates and year.** The listing date is taken from completion reports and must fall within 120 days before to 30 days after the article. The IPO year is the listing year, else the year most completion reports were written, else the year of the first report. IPOs listed before 2019 (recalled in later articles) are dropped, as are companies known only from roundup articles that name six or more IPOs. Reports from archive back-fill days (dates carrying five times the usual volume, old articles stamped with an ingest date; 7,023 reports) are dropped.
6. **Issue size.** A figure stands when (a) its currency is written in the sentence, (b) it matches a money figure in the sentence (0.6–1.7×), (c) it does not sit next to a valuation, deal-value, revenue or subscription-demand word, and (d) the sentence reports a completed IPO or concrete offer terms (price band, fresh issue, offer for sale, lot size) without target or valuation language. For a completed IPO the completion reports are used. The figure most distinct sentences agree on wins. Amounts above US$80B are dropped (the largest in the data is US$75B). Indian SME amounts above US$60M are dropped. SPAC-merger "sizes" (deal values) are blanked.
7. **Hand checks.** The largest rows were read against their sentences: a rights issue, a follow-on offering and preferred-stock deals were removed, and amounts that were another figure were blanked (listed in the spec).
8. **Exchange and board.** About 2,600 exchange spellings are mapped to 80 exchanges. Indian issues are Mainboard (NSE, BSE) or SME (NSE Emerge, BSE SME, or an SME issue whose exchange is not stated).
9. **Company fields.** Country is the reports' company country, else the company database, else the exchange's country. Sector is read from the reports, else from the company database, and grouped into 20 broad sectors.
10. **News columns.** The excerpt is the earliest clean report sentence, preferring one whose article can be retrieved at release time.

11. **Sample.** Each company key is ranked by `sha1(key)`. Keys are taken in rank order until the file holds max(25%, 5,000) rows (capped at 100,000).

12. **Profile links.** Links are built from Fliar's company index and checked against it. A row whose company has no public profile has an empty link.

## Columns

| Column              | Description                                                                                                                                      |
|:--------------------|:-------------------------------------------------------------------------------------------------------------------------------------------------|
| `ipo_id`            | stable 12-character ID of the company IPO                                                                                                        |
| `company_name`      | company name                                                                                                                                     |
| `company_domain`    | company website domain when known (the join key for the API), else blank                                                                         |
| `ticker`            | ticker symbol, when a report states it                                                                                                           |
| `exchange`          | listing exchange or market (normalised; India: NSE, BSE, NSE & BSE, NSE Emerge (SME), BSE SME)                                                   |
| `board`             | India: Mainboard or SME. Elsewhere: Main market or Growth / SME market (AIM, TSX Venture, KOSDAQ, STAR, Catalist, ACE, Nomu ...)                 |
| `country`           | company country (normalised)                                                                                                                     |
| `sector`            | broad sector (20 groups)                                                                                                                         |
| `ipo_type`          | IPO, SME IPO, SPAC IPO (a blank-check company listing), SPAC merger (an operating company going public by merging with a SPAC) or Direct listing |
| `listing_status`    | `Completed` (a report says the shares listed, debuted, were priced or the IPO raised money), `Withdrawn / postponed`, or `Announced / filed`     |
| `listing_date`      | listing date stated in a completion report (YYYY-MM-DD), else blank                                                                              |
| `first_report_date` | date of the first news report of the IPO (YYYY-MM-DD)                                                                                            |
| `year`              | IPO year: listing year, else the year of the completion reports, else the year of the first report                                               |
| `issue_size_local`  | issue size in `currency` as reported                                                                                                             |
| `currency`          | currency of `issue_size_local` (ISO 4217)                                                                                                        |
| `issue_size_usd`    | issue size in US$ (reported US$ figure, else converted at a fixed average rate)                                                                  |
| `amount_status`     | `verified` (matches a money figure in the report sentence), `unchecked`, `failed_check` (an extracted figure was rejected) or `not_disclosed`    |
| `price_band_low`    | lower end of the price band, in `currency` per share                                                                                             |
| `price_band_high`   | upper end of the price band                                                                                                                      |
| `issue_price`       | final issue / offer price per share                                                                                                              |
| `news_reports`      | number of deduplicated news reports about this IPO                                                                                               |
| `news_source`       | publisher of the article quoted in `news_excerpt` (website domain)                                                                               |
| `news_url`          | link to that article                                                                                                                             |
| `news_excerpt`      | the report sentence (up to 300 characters)                                                                                                       |
| `fliar_profile_url` | full company profile on Fliar (financials, funding, team, news)                                                                                  |

**Available only through the [Radar API](https://github.com/fliarbi/radar-api-mcp):** lead managers / underwriters and anchor investors; subscription multiples by investor category; valuation, shares offered and greenshoe; use of proceeds; listing-day and later share-price performance; every article that reported each IPO; follow-on offerings, offers for sale, QIPs and rights issues; the rest of the companies; company profile, financials, team and contacts.

## Limitations

- Derived from news: IPOs that were never reported are missing, and coverage favours English-language reporting. Year-to-year counts also reflect how much news was ingested; the 2025 jump in announced IPOs is partly wider news coverage.
- Most rows are announcements or filings without a completion report (`Announced / filed`); many of those did list, others never happened. Use `listing_status == "Completed"` for listings.
- Issue sizes are as reported in the news (some include the greenshoe, some do not) and only about one row in five has one; the US$ figure uses the reported dollar amount or a fixed average exchange rate.
- Company matching is automatic: some companies still appear twice under name variants, and a few rows are linked to the wrong website (a parent or a namesake).
- The full ₹ issue size is shown for Indian rows; US$-only figures are converted at ₹83 = US$1 in the India tables.
- 2026 covers January to June only.
- `news_source` and `news_url` are blank when the article could not be retrieved at release time (some article stores were offline).

## Citation

Fliar Research (2026). *IPO Data 2019-2026: India, US, UK & Global IPOs* (sample release). Data: Radar API, https://github.com/fliarbi/radar-api-mcp. Licence CC BY-NC 4.0.
