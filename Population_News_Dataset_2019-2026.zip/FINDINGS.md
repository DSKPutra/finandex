# Population in the news, 2019–2026: findings stated for citation

Each finding is one self-contained sentence in encyclopedic register, with its number, window and
comparison, plus the Wikipedia article and section it is written for (section names checked against
the live article on 2026-10-17). Grades: **A** exact count from the records; **B** depends on a keyword
rule (precision measured by hand at 95% for the news match); **C** sensitive to which outlets the index
collects. Source for all findings: Fliar BI, *Population in the News 2019–2026* (dataset and working
paper), built with the [Prism News API](https://github.com/fliarbi/prism-news-api).

"Population news" here means articles whose opening uses the vocabulary of human population change:
population growth or decline, ageing, fertility and birth rates, depopulation, censuses and population
policy.

### F1
**Grade:** B
**Sentence:** In a global news index covering January 2019 to July 2026, January (11.48%) and July (11.45%) were the two busiest months for news about population change, together holding on average 22.93% of a year's coverage between 2019 and 2025, against one-sixth for an even spread.
**Wikipedia:** [[World Population Day]] § (new section)
**Basis:** Within-year month shares of 42,392 matched articles, averaged over the complete years 2019–2025.
**Limit:** The July peak coincides with World Population Day (11 July) and the January peak with annual statistical releases; the index does not record why an article was written.

### F2
**Grade:** B
**Sentence:** Population change took a 38.2% smaller share of news coverage in 2020, the first year of the COVID-19 pandemic, than in 2019 (1.73 against 2.8 articles per 10,000 news articles), the lowest annual share between 2019 and 2025, and its share in 2024 (3.42 per 10,000) was 1.98 times the 2020 level.
**Wikipedia:** [[Media coverage of the COVID-19 pandemic]] § Level and nature of coverage
**Basis:** Annual matched articles divided by all articles in the index for the same year.
**Limit:** The share measures attention, not demographic change; no causal link to pandemic coverage is tested.

### F3
**Grade:** B
**Sentence:** July 2021 was the month in which population change took its largest share of global news between January 2019 and July 2026, at 5.58 articles per 10,000; it was the month of World Population Day and of a draft population control bill in the Indian state of Uttar Pradesh.
**Wikipedia:** [[Birth rate]] § In politics
**Basis:** Monthly matched articles per 10,000 news articles, every month from January 2019 to July 2026.
**Limit:** Attribution of the peak to these events is by coincidence of timing only.

### F4
**Grade:** B
**Sentence:** January 2023, the month in which China reported its first population decline in six decades, gave population change its second-largest monthly share of global news between January 2019 and July 2026, at 5.27 articles per 10,000 news articles.
**Wikipedia:** [[Demographics of China]] § Population
**Basis:** Monthly matched articles per 10,000 articles in the index; only July 2021 (5.58) was higher.
**Limit:** Timing coincidence; other population stories ran in the same month.

### F5
**Grade:** C
**Sentence:** Between January 2023 and July 2026, South Korea (6.65 times), Japan (4.87 times) and China (3.89 times) were the most over-represented countries in news about population change relative to their share of all located news, while the United States (0.61 times), France (0.63 times) and the United Kingdom (0.64 times) were under-represented.
**Wikipedia:** [[Population decline]] § East Asia
**Basis:** Primary country of 13,487 located articles; lift = topic share ÷ share of all located news.
**Limit:** Lift is a coverage measure, not a ranking of demographic change.

### F6
**Grade:** C
**Sentence:** By continent, news about population change between January 2023 and July 2026 was most over-represented in Oceania (2.16 times its share of located news) and Asia (1.72 times), and least in North America (0.62 times) and South America (0.4 times).
**Wikipedia:** [[Population ageing]] § Around the world
**Basis:** Continent of the article's primary location; lift against all located news.
**Limit:** South America is thinly covered in the index (95 located articles), so its lift is uncertain.

### F7
**Grade:** B
**Sentence:** Of articles about population change carrying a tone label between January 2023 and July 2026, 47.4% were negative in tone, 1.41 times the 33.6% negative share across all news, and 71.2% were rated critical priority against 42.6% of all news.
**Wikipedia:** [[Population decline]] § Possible negative effects
**Basis:** Top sentiment label and top priority label of each article; critical = priority 7 or higher on a 1–9 scale.
**Limit:** Tone and priority are machine labels from the article opening.

### F8
**Grade:** B
**Sentence:** Migration patterns and immigration rates appeared in 3.16% of themed articles about population change between January 2023 and July 2026, 601 times their frequency in all themed news.
**Wikipedia:** [[Human population projections]] § Migration
**Basis:** Theme labels assigned to each article; lift against all themed news.
**Limit:** Themes are machine-assigned and one article can carry several.

### F9
**Grade:** A
**Sentence:** Research papers with population growth, decline, ageing or fertility-rate terms in the title rose from 1.35 to 2.14 per 10,000 published papers between 2015 and 2025, a 1.6-fold increase in the topic's share of the scientific literature.
**Wikipedia:** [[Demography]] § Science of population
**Basis:** 11,216 de-duplicated articles and reviews 2015–2025, repository deposits and clinical or animal senses excluded; denominators are all articles and reviews per year.
**Limit:** Title matching misses papers that use the terms only in the abstract, and some ecological papers on species decline remain.

### F10
**Grade:** C
**Sentence:** Between January 2023 and July 2026, news about population change located in India was most concentrated, relative to each state's share of Indian news, in Andhra Pradesh (3.17 times), Bihar (2.37 times) and Tamil Nadu (1.77 times), while Uttar Pradesh (0.67 times) and Maharashtra (0.71 times) were under-represented.
**Wikipedia:** [[Demographics of India]] § Regional growth
**Basis:** Primary state of 1,051 located Indian articles; lift against all located Indian news; states with at least 50 articles.
**Limit:** State counts are small (76 to 119 articles for the states named), so lifts can move with a few stories.

### F11
**Grade:** C
**Sentence:** Among US states with at least 50 articles, Indiana (2.01 times), Michigan (1.72 times) and Ohio (1.54 times) had the most over-represented coverage of population change relative to their share of American news between January 2023 and July 2026, while New Jersey (0.13 times) and Pennsylvania (0.59 times) had the least.
**Wikipedia:** [[Demographics of the United States]] § Growth rate
**Basis:** Primary state of 2,892 located US articles; lift against all located US news.
**Limit:** States with a large local-news presence in the index (New Jersey) have low lifts partly because their baseline is large.

### F12
**Grade:** C
**Sentence:** Measured per 10,000 of each country's located news, coverage of population change in China fell from 23.73 in 2023 to 8.37 in 2025 (a 64.7% fall), and in Japan from 20.84 to 12.99, while among the eight countries with the most located articles it rose only in the United States (1.73 to 2.35), the United Kingdom (1.81 to 2.22) and India (3.14 to 3.51).
**Wikipedia:** [[Demographics of China]] § Population
**Basis:** Matched articles per country divided by all located articles from that country, per year.
**Limit:** 2023 was a high year for China after its reported population decline; the fall is from that peak.

### F13
**Grade:** C
**Sentence:** Relative to each country's news overall, coverage of population change between January 2023 and July 2026 was most negative in China (74.8% negative against 27.2%), South Korea (67.1% against 25.0%) and Japan (63.8% against 23.3%), but no more negative than the national baseline in India (40.6% against 41.2%) and less negative in Nigeria (34.0% against 44.4%).
**Wikipedia:** [[Demographics of South Korea]] § Fertility
**Basis:** Negative share of labelled articles per country against the negative share of all labelled news from that country.
**Limit:** Tone is machine-labelled; it reflects how a story is framed, not the demographic facts.

## Rejected

- **Exclusion share as a finding.** Exclusion patterns removed 10,090 of 52,482 raw term matches (19.2%), aimed at wildlife, livestock and pet populations, clinical fertility, journal abstracts and market reports. Not every removed item is a wrong sense (an article about people that mentions forests or crops is also removed), and the hand check found research abstracts still in the matched set; the share is a property of this method and is reported in the paper, not as a finding.
- **"Population coverage is rising."** Raw counts rose from 3,301 (2019) to 8,416 (2025), but the index grew; as a share of all news, 2025 (3.12 per 10,000) is 1.11 times 2019 (2.8). Stated only as F2, against the 2020 low.
- **City-level coverage.** The city field tags ordinary words as places; tags derived from ordinary words are now treated as unlocated (15.3% of city-tagged articles), but no city finding is stated.
- **Missouri, Arizona and Oregon among the leading US states.** An earlier version named Missouri as the second most over-represented US state, and Arizona and Oregon also passed the 50-article threshold. Part of their count came from place tags derived from ordinary words. With those tags treated as unlocated, Missouri has 46 located articles, Arizona 37 and Oregon 47, all below the threshold; F11 now names Ohio instead.
- **Rajasthan among the Indian states.** It passed the 50-article threshold before the ordinary-word place tags were removed; it now has 49 articles and is not named.
- **"The United States dominates population news."** True in raw share (29.39% of located articles), but its lift is 0.61; stated as F5.
- **Organisations most named.** The US Census Bureau (395 articles), the OECD (369) and the UN Population Fund (326) rank high, but the list also contains tagging errors (a publisher name, and a hacker group in place of a health agency's abbreviation); not stated.
- **Small Indian states.** Sikkim (8.07) and Lakshadweep (4.45) have the highest lifts but fewer than 10 articles each; ignored.
- **Patent families.** 116 families (2015–2024) match population-statistics terms in the title, mostly generic data-processing inventions; too few and too broad for a finding.
- **Indonesia among the over-represented countries.** Its lift (3.36) and its 2025 attention jump (7.08 to 24.29 per 10,000 of its news) come mostly from copies of one March 2025 market report on vegetable oils that names population growth as a demand driver (30 of 37 sampled Indonesian articles since 2023); not stated.
- **2026 trend.** The index thins after May 2026; 2026 values (January–July) are partial and excluded from comparisons.
