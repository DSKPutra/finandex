# Housing in the news, 2019–2026: findings stated for citation

Each finding is one self-contained sentence in encyclopedic register, with its number, window and
comparison, plus the Wikipedia article and section it is written for (section names checked against
the live article on 2026-10-18). Grades: **A** exact count from the records; **B** depends on a keyword
rule (precision measured by hand at 82.5% for the news match); **C** sensitive to which outlets the index
collects. Source for all findings: Fliar BI, *Housing in the News 2019–2026* (dataset and working paper),
built with the [Prism News API](https://github.com/fliarbi/prism-news-api).

### F1
**Grade:** B
**Sentence:** In a global news index, housing took a 24.6% smaller share of news coverage in 2020 than in 2019 (13.82 against 18.32 articles per 10,000 news articles), and its lowest monthly shares between January 2019 and July 2026 came in April and May 2020, at about 11.1 articles per 10,000.
**Wikipedia:** [[Housing inequality]] § COVID-19 pandemic
**Basis:** Annual and monthly housing articles divided by all articles in the index for the same period; 248,239 matched articles in total.
**Limit:** The share measures attention, not housing conditions; the link to pandemic coverage is a coincidence of timing and is not tested.

### F2
**Grade:** B
**Sentence:** The phrase "affordable housing" appeared in the opening text of 42,158 of 248,239 housing news articles published between January 2019 and July 2026 (16.98%), more than any other housing term in the index.
**Wikipedia:** [[Affordable housing]] § Definition and measurement
**Basis:** Per-term counts of the 33 reviewed housing phrases within the matched set; an article can use several phrases.
**Limit:** The count reflects how outlets phrase housing stories, not how many affordable homes exist or are planned.

### F3
**Grade:** C
**Sentence:** Between January 2023 and July 2026, the United States accounted for 48.31% of located housing news, matching its share of all located news (lift 1.0), while India accounted for 11.49% (0.87 times its overall share) and the United Kingdom for 10.27% (1.76 times).
**Wikipedia:** [[Housing crisis]] § National
**Basis:** Primary country of 80,060 located articles; lift = topic share ÷ share of all located news. Place tags derived from ordinary words are treated as unlocated.
**Limit:** Country is the article's primary location as tagged by the index, not the outlet's country.

### F4
**Grade:** C
**Sentence:** Among the 20 countries with at least 217 located housing articles between January 2023 and July 2026 (Iceland left out, see Rejected), housing was most over-represented relative to each country's share of all news in Australia (3.17 times), New Zealand (2.5 times), Ireland (2.32 times) and Kenya (2.25 times), followed by Scotland (2.15 times) and Canada (2.05 times).
**Wikipedia:** [[Housing crisis]] § Global
**Basis:** Lift of the countries with the most located housing articles (each with at least 217 articles). Iceland is left out because most of its sampled articles are US regional housing reports tagged with regions such as South and West.
**Limit:** Lift is a coverage measure; it does not rank countries by housing affordability.

### F5
**Grade:** C
**Sentence:** By continent, housing news between January 2023 and July 2026 was most over-represented in Oceania (3.15 times its share of all located news) and most under-represented in South America (0.29 times) and Asia (0.71 times); Australia alone had a lift of 3.17.
**Wikipedia:** [[Housing crisis]] § Australia
**Basis:** Primary continent of located housing articles, with Australia folded into Oceania; lift against all located news.
**Limit:** The index holds mostly English-language and translated outlets; South American coverage is thin in the baseline as well as the topic.

### F6
**Grade:** B
**Sentence:** Of housing articles carrying a tone label between January 2023 and July 2026, 43.6% were negative in tone, 1.3 times the 33.6% negative share across all news in the same index, while 54.6% were positive.
**Wikipedia:** [[Housing crisis]] § Impacts
**Basis:** Top sentiment label of each article, grouped into negative, neutral and positive; 99.8% of sampled articles carry a label.
**Limit:** Tone is machine-labelled from the article opening; market reports on rising prices can be labelled positive.

### F7
**Grade:** B
**Sentence:** Editors' priority ratings placed 59.8% of housing articles at critical priority (7 or higher on a 1–9 scale) between January 2023 and July 2026, 1.4 times the 42.6% share for all news.
**Wikipedia:** [[Affordable housing]] § Public policy
**Basis:** Top priority label per article; critical = priority ≥ 7.
**Limit:** Priority is a model rating of editorial urgency, not a policy measure.

### F8
**Grade:** B
**Sentence:** Zoning and land-use regulation appeared as a theme in 1.44% of themed housing articles between January 2023 and July 2026, 353.47 times its frequency in all themed news, and affordable-housing initiatives in 7.02%, 339.49 times their frequency.
**Wikipedia:** [[Affordable housing]] § Government restrictions
**Basis:** Theme labels assigned to each article; lift against all themed news.
**Limit:** Themes are machine-assigned; one article can carry several themes.

### F9
**Grade:** B
**Sentence:** The United States Department of Housing and Urban Development was the organisation named most often in housing news between January 2023 and July 2026, in 5,252 articles (3.66% of the topic), ahead of the Federal Reserve (3,466) and Freddie Mac (2,972).
**Wikipedia:** [[Housing in the United States]] § Public housing
**Basis:** Organisations extracted from each article; counted once per article.
**Limit:** "Department of housing" is one of the match phrases, which raises the department's count.

### F10
**Grade:** A
**Sentence:** Research papers on housing markets, prices, affordability and housing policy rose from 0.96 per 10,000 published papers in 2000 to 2.16 in 2015, and between 2015 and 2025 their share stayed between 1.89 and 2.47 per 10,000, ending at 2.42 in 2025 (1.12 times the 2015 share).
**Wikipedia:** [[Real estate economics]] § (new section)
**Basis:** 16,408 de-duplicated articles and reviews 2015–2025 with a housing-economics phrase in the title, repository deposits and animal-housing senses excluded.
**Limit:** Title matching misses papers that name the topic only in the abstract.

### F11
**Grade:** A
**Sentence:** China's patent office accounted for 74.9% of patent families on prefabricated, modular and residential buildings published between 2015 and 2024, and the number published each year peaked at 1,488 in 2021, 4.35 times the 342 of 2015.
**Wikipedia:** [[Modular building]] § Research and development
**Basis:** 8,075 patent families 2015–2024 with prefabricated or modular house, residential building or dwelling in the title, counted once per filing office.
**Limit:** Chinese utility-model filings are numerous and narrow; office shares measure filing activity, not invention value.

### F12
**Grade:** C
**Sentence:** Between January 2023 and July 2026, Maharashtra accounted for 27.06% of located Indian housing news, 1.7 times its share of Indian news overall, while among states with at least 50 housing articles Kerala (0.38 times), Jammu and Kashmir (0.38 times) and Bihar (0.49 times) were the most under-represented.
**Wikipedia:** [[Housing crisis]] § India
**Basis:** Primary state of 7,329 located Indian housing articles; lift against all located Indian news (states with fewer than 50 housing articles are left out).
**Limit:** State tagging follows the article's primary place; national stories filed from Delhi count for Delhi.

### F13
**Grade:** C
**Sentence:** Among US states, Rhode Island (3.18 times), Arizona (2.09 times), Oregon (2.08 times), New Hampshire (2.05 times) and Hawaii (2.01 times) had the most over-represented housing coverage relative to their share of American news between January 2023 and July 2026, while among states with at least 50 housing articles New Jersey (0.18 times), South Dakota (0.41 times) and Pennsylvania (0.44 times) had the least.
**Wikipedia:** [[Housing crisis in the United States]] § (new section)
**Basis:** Primary state of 34,006 located US housing articles; lift against all located US news. Ordinary words that name places (such as Mesa, Chandler or Surprise in Arizona) are treated as unlocated.
**Limit:** States with a large local-news presence in the index (New Jersey) have low lifts partly because their baseline is large.

### F14
**Grade:** C
**Sentence:** Housing coverage as a share of Spain's news rose from 6.92 to 25.23 articles per 10,000 between 2023 and 2025 (3.65 times), the largest rise among the 25 countries with the most housing coverage, while Ireland's fell from 78.0 to 23.92 (0.31 times).
**Wikipedia:** [[Housing crisis]] § Global
**Basis:** Housing articles divided by all located articles of the same country per year.
**Limit:** Country baselines depend on which outlets the index collects in each year.

### F15
**Grade:** C
**Sentence:** Between January 2023 and July 2026, 68.7% of tone-labelled housing articles located in China were negative, against 27.2% of all Chinese news in the index, the widest gap among the leading countries, while housing news located in India was less negative (23.1%) than Indian news overall (41.2%).
**Wikipedia:** [[Chinese real estate crisis (2020–present)]] § Impact
**Basis:** Negative share of housing articles per country against that country's negative share in all news (countries with at least 200 labelled housing articles).
**Limit:** Tone is machine-labelled; the gap measures the framing of coverage, not market outcomes.

## Rejected

- **"Housing coverage is rising."** Raw article counts nearly doubled, from 21,625 (2019) to 42,809 (2025), but the index itself grew; as a share of all news the 2025 level (15.86 per 10,000) is 13.4% below 2019 (18.32). Killed: growth from raw counts.
- **"June 2026 was the peak month."** June 2026 shows 31.98 articles per 10,000, but the index thins after May 2026 and held only 457,172 articles that month; the highest share in a full year was September 2019 (24.03). Not stated as a peak.
- **Seasonality.** The busiest month (September, 9.31% of a year's coverage) is close to an even spread; no seasonal finding is stated.
- **"Massachusetts and Hawaii follow Rhode Island and Oregon as the most over-represented US states."** An earlier build ranked Rhode Island, Oregon, Hawaii and Massachusetts first and left Arizona out of the leading states. Ordinary words that are also Arizona place names (Mesa, Chandler, Surprise, Buckeye, Globe) had tagged unrelated news as Arizona and inflated its baseline. With those tags treated as unlocated, Arizona (2.09) and New Hampshire (2.05) rank above Hawaii (2.01), and Massachusetts (1.86) falls to seventh. Killed: ranking distorted by place tags from ordinary words.
- **City-level coverage.** The city field tags common words as places; ordinary-word tags (15.3% of city-tagged articles) are now treated as unlocated, but no city finding is stated.
- **Organisations other than agencies.** Lists of named organisations include tagging errors ("sales (band)", "financial planning"), so only the leading agency is stated (F9).
- **2026 trend.** The index thins after May 2026; 2026 values cover January–July only, are partial and are excluded from comparisons.
- **"Iceland is the most over-represented country (lift 4.78)."** Iceland's 451 located housing articles give the highest country lift, but most of its sampled articles are US regional housing reports tagged with regions such as South and West, not Iceland. Its rise in attention from 2023 to 2025 rests on the same tags. Killed: location from a mis-tagged place.
