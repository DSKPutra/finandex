# VC Co-Investment Network: 303k Investor Pairs: findings, method and data card

*Fliar Research · released October 2026 · licence CC BY-NC 4.0*

**How this dataset was acquired.** Every row is derived from the [Radar API](https://github.com/fliarbi/radar-api-mcp), Fliar's company-data API and MCP server.
Radar reads business news continuously and extracts each startup funding announcement into structured fields, including every
named investor. Those rounds are cleaned (repeated reports merged, recaps dropped), people and generic phrases are removed from the
investor lists, and every pair of investor organisations that appeared in the same round becomes one edge here, weighted by the
number of rounds they shared between January 2019 and June 2026. Each investor's profile and portfolio are available through
`POST /v1/investors/page` ([reference](https://github.com/fliarbi/radar-api-mcp/blob/main/docs/reference/get_investor_page.md)) or the `get_investor_page` MCP tool.

> **This file is a 25% sample: 75,855 of 303,421 investor pairs.** It keeps every record for a fixed subset of pairs.
> The subset is chosen by a hash, so it stays the same from one release to the next. The findings and tables below were computed
> on the **full** data. For the rest, the withheld fields and monthly updates, [get a Radar API key](https://fliarbi.com/radar-api/developer) ([docs](https://github.com/fliarbi/radar-api-mcp)).
> Each row's `fliar_profile_url` opens the company's full profile on Fliar.

## Key findings

1. **303,421 investor pairs co-invested at least once** across 42,182 rounds with two or more named organisation investors (65% of rounds with any), January 2019 to June 2026. 50,836 pairs (17%) did so two or more times and 829 ten or more times.
2. **The strongest pair is Sequoia Capital and Tiger Global**, with 87 shared rounds; next are Soma Capital and Y Combinator (84) and Lightspeed Venture Partners and Sequoia Capital (72).
3. **Y Combinator has the widest network**: it shared a round with 1,738 different investors. Tiger Global (1,480) and Gaingels (1,404) follow.
4. **Syndicates grew in the 2021 boom.** The average number of named organisation investors per round was 2.72 in 2019, 3.21 in 2021, 2.93 in 2023, 3.13 in 2025.
5. **Like backs like.** 64% of pairs join two investors of the same type; VC–VC pairs are 60% of all pairs, VC–CVC 8% and VC–PE 9%.

![Co-investment network of the most connected investors](figures/network_top30.png)

![Strongest co-investor pairs](figures/top_pairs.png)

![Investors per round by year](figures/syndicate_size.png)

### Strongest co-investor pairs worldwide (top 50)

Rounds both investors joined, January 2019 to June 2026, full data.

| #   | Investor A                  | Type A   | Investor B                  | Type B      | Shared rounds   | Years     | Top sector                           | Top country   |
|:----|:----------------------------|:---------|:----------------------------|:------------|:----------------|:----------|:-------------------------------------|:--------------|
| 1   | Sequoia Capital             | VC       | Tiger Global                | PE          | 87              | 2019–2026 | Fintech                              | United States |
| 2   | Soma Capital                | VC       | Y Combinator                | accelerator | 84              | 2019–2025 | Fintech                              | United States |
| 3   | Lightspeed Venture Partners | VC       | Sequoia Capital             | VC          | 72              | 2019–2026 | Enterprise Infrastructure            | United States |
| 4   | Accel                       | VC       | Tiger Global                | PE          | 71              | 2019–2025 | Enterprise Applications              | United States |
| 5   | Accel                       | VC       | Sequoia Capital             | VC          | 68              | 2019–2026 | Enterprise Infrastructure            | United States |
| 6   | Andreessen Horowitz         | VC       | Sequoia Capital             | VC          | 67              | 2019–2026 | High Tech                            | United States |
| 7   | Coatue                      | PE       | Sequoia Capital             | VC          | 63              | 2019–2026 | Enterprise Applications              | United States |
| 8   | Coatue                      | PE       | Tiger Global                | PE          | 63              | 2019–2026 | Fintech                              | United States |
| 9   | Index Ventures              | VC       | Sequoia Capital             | VC          | 54              | 2019–2026 | Enterprise Applications              | United States |
| 10  | Peak XV Partners            | VC       | Tiger Global                | PE          | 54              | 2019–2025 | Fintech                              | India         |
| 11  | Insight Partners            | PE       | Tiger Global                | PE          | 53              | 2019–2023 | Fintech                              | United States |
| 12  | 9Unicorns                   | VC       | Venture Catalysts           | VC          | 52              | 2020–2025 | Retail                               | India         |
| 13  | Accel                       | VC       | Lightspeed Venture Partners | VC          | 49              | 2019–2026 | Enterprise Infrastructure            | United States |
| 14  | Dragoneer Investment Group  | PE       | Tiger Global                | PE          | 46              | 2019–2026 | Fintech                              | United States |
| 15  | Andreessen Horowitz         | VC       | Tiger Global                | PE          | 44              | 2019–2026 | High Tech                            | United States |
| 16  | Coatue                      | PE       | Lightspeed Venture Partners | VC          | 44              | 2019–2026 | Enterprise Infrastructure            | United States |
| 17  | Pioneer Fund                | VC       | Y Combinator                | accelerator | 43              | 2019–2026 | Fintech                              | United States |
| 18  | Accel                       | VC       | Coatue                      | PE          | 42              | 2019–2026 | Enterprise Infrastructure            | United States |
| 19  | Accel                       | VC       | Insight Partners            | PE          | 42              | 2019–2026 | Enterprise Infrastructure            | United States |
| 20  | Accel                       | VC       | Y Combinator                | accelerator | 42              | 2019–2026 | Enterprise Applications              | United States |
| 21  | Andreessen Horowitz         | VC       | Y Combinator                | accelerator | 42              | 2019–2026 | Fintech                              | United States |
| 22  | Coatue                      | PE       | Dragoneer Investment Group  | PE          | 42              | 2019–2026 | Fintech                              | United States |
| 23  | Founders Fund               | VC       | Khosla Ventures             | VC          | 41              | 2019–2026 | Enterprise Applications              | United States |
| 24  | Andreessen Horowitz         | VC       | Founders Fund               | VC          | 40              | 2019–2026 | Enterprise Applications              | United States |
| 25  | Global Founders Capital     | VC       | Y Combinator                | accelerator | 40              | 2019–2025 | Fintech                              | United States |
| 26  | Goodwater Capital           | VC       | Y Combinator                | accelerator | 39              | 2019–2026 | Fintech                              | United States |
| 27  | Sequoia Capital             | VC       | Y Combinator                | accelerator | 38              | 2019–2025 | Fintech                              | United States |
| 28  | Founders Fund               | VC       | Lux Capital                 | VC          | 37              | 2020–2026 | Aerospace, Maritime and Defense Tech | United States |
| 29  | Kleiner Perkins             | VC       | Sequoia Capital             | VC          | 36              | 2019–2026 | Enterprise Applications              | United States |
| 30  | Accel                       | VC       | Peak XV Partners            | VC          | 34              | 2019–2026 | Consumer                             | India         |
| 31  | Altimeter Capital           | PE       | Coatue                      | PE          | 34              | 2019–2026 | High Tech                            | United States |
| 32  | Andreessen Horowitz         | VC       | Thrive Capital              | VC          | 33              | 2019–2026 | High Tech                            | United States |
| 33  | Founders Fund               | VC       | Thrive Capital              | VC          | 33              | 2019–2026 | Fintech                              | United States |
| 34  | Index Ventures              | VC       | Tiger Global                | PE          | 33              | 2019–2025 | Enterprise Infrastructure            | United States |
| 35  | Ribbit Capital              | VC       | Sequoia Capital             | VC          | 33              | 2019–2026 | Fintech                              | India         |
| 36  | Andreessen Horowitz         | VC       | Index Ventures              | VC          | 32              | 2019–2026 | High Tech                            | United States |
| 37  | DST Global                  | VC       | Tiger Global                | PE          | 32              | 2019–2026 | Fintech                              | United States |
| 38  | Eight Roads Ventures        | VC       | F-Prime Capital             | VC          | 32              | 2019–2024 | Healthtech                           | United States |
| 39  | Founders Fund               | VC       | Sequoia Capital             | VC          | 32              | 2019–2026 | Fintech                              | United States |
| 40  | Orbimed                     | VC       | Ra Capital Management       | VC          | 32              | 2019–2026 | Life Sciences                        | United States |
| 41  | Rebel Fund                  | VC       | Y Combinator                | accelerator | 32              | 2020–2025 | Fintech                              | United States |
| 42  | Accel                       | VC       | Salesforce Ventures         | CVC         | 31              | 2019–2026 | Enterprise Infrastructure            | United States |
| 43  | Atreides Management         | PE       | Valor Equity Partners       | PE          | 31              | 2019–2026 | High Tech                            | United States |
| 44  | Coatue                      | PE       | Index Ventures              | VC          | 31              | 2019–2026 | Enterprise Infrastructure            | United States |
| 45  | Coatue                      | PE       | Thrive Capital              | VC          | 31              | 2019–2026 | Fintech                              | United States |
| 46  | DST Global                  | VC       | Sequoia Capital             | VC          | 31              | 2019–2026 | Fintech                              | United States |
| 47  | Dragoneer Investment Group  | PE       | Sequoia Capital             | VC          | 31              | 2019–2026 | Fintech                              | United States |
| 48  | Salesforce Ventures         | CVC      | Tiger Global                | PE          | 31              | 2019–2024 | Enterprise Infrastructure            | United States |
| 49  | 8VC                         | VC       | Founders Fund               | VC          | 30              | 2019–2026 | Enterprise Applications              | United States |
| 50  | Andreessen Horowitz         | VC       | Coatue                      | PE          | 30              | 2019–2026 | High Tech                            | United States |

### Most connected investors (top 50 by number of co-investors)

Co-investors = distinct investors it shared at least one round with.

| #   | Investor                    | Type        | HQ             | Co-investors   | Pair-rounds (sum of shared rounds)   | Rounds joined   | Most frequent partner          | Rounds with that partner   |
|:----|:----------------------------|:------------|:---------------|:---------------|:-------------------------------------|:----------------|:-------------------------------|:---------------------------|
| 1   | Y Combinator                | accelerator | United States  | 1,738          | 3,855                                | 1,090           | Soma Capital                   | 84                         |
| 2   | Tiger Global                | PE          | United States  | 1,480          | 4,132                                | 897             | Sequoia Capital                | 87                         |
| 3   | Gaingels                    | other       | United States  | 1,404          | 2,136                                | 336             | Alumni Ventures                | 24                         |
| 4   | Accel                       | VC          | United States  | 1,245          | 3,272                                | 865             | Tiger Global                   | 71                         |
| 5   | Sequoia Capital             | VC          | United States  | 1,237          | 3,497                                | 827             | Tiger Global                   | 87                         |
| 6   | Alumni Ventures             | VC          | United States  | 1,222          | 1,745                                | 293             | Gaingels                       | 24                         |
| 7   | Lightspeed Venture Partners | VC          | United States  | 1,213          | 2,869                                | 683             | Sequoia Capital                | 72                         |
| 8   | Andreessen Horowitz         | VC          | United States  | 1,198          | 3,023                                | 719             | Sequoia Capital                | 67                         |
| 9   | Insight Partners            | PE          | United States  | 1,176          | 2,580                                | 737             | Tiger Global                   | 53                         |
| 10  | Temasek                     | government  | Singapore      | 1,032          | 1,834                                | 336             | Tiger Global                   | 22                         |
| 11  | Techstars                   | accelerator | United States  | 976            | 1,278                                | 369             | Matchstick Ventures            | 10                         |
| 12  | FJ Labs                     | VC          | United States  | 953            | 1,486                                | 307             | Gaingels                       | 10                         |
| 13  | Khosla Ventures             | VC          | United States  | 938            | 1,812                                | 433             | Founders Fund                  | 41                         |
| 14  | Bessemer Venture Partners   | VC          | United States  | 922            | 1,897                                | 486             | Insight Partners               | 29                         |
| 15  | Goldman Sachs               | PE          | United States  | 909            | 1,632                                | 362             | JP Morgan                      | 29                         |
| 16  | Salesforce Ventures         | CVC         | United States  | 802            | 1,611                                | 340             | Tiger Global                   | 31                         |
| 17  | Global Founders Capital     | VC          | Germany        | 801            | 1,378                                | 342             | Y Combinator                   | 40                         |
| 18  | Peak XV Partners            | VC          | India          | 775            | 1,745                                | 506             | Tiger Global                   | 54                         |
| 19  | Softbank                    | CVC         | Japan          | 775            | 1,341                                | 357             | Tiger Global                   | 27                         |
| 20  | Blackrock                   | PE          | United States  | 758            | 1,442                                | 245             | Tiger Global                   | 21                         |
| 21  | Founders Fund               | VC          | United States  | 757            | 1,743                                | 355             | Khosla Ventures                | 41                         |
| 22  | Citi Ventures               | CVC         | United States  | 751            | 1,422                                | 271             | Goldman Sachs                  | 26                         |
| 23  | Coatue                      | PE          | United States  | 736            | 2,238                                | 384             | Sequoia Capital                | 63                         |
| 24  | 8VC                         | VC          | United States  | 735            | 1,297                                | 271             | Founders Fund                  | 30                         |
| 25  | Bain Capital Ventures       | VC          | United States  | 728            | 1,386                                | 329             | Accel                          | 27                         |
| 26  | Index Ventures              | VC          | United Kingdom | 658            | 1,646                                | 421             | Sequoia Capital                | 54                         |
| 27  | Norwest Venture Partners    | VC          | United States  | 653            | 1,166                                | 286             | Accel                          | 17                         |
| 28  | Tencent                     | CVC         | China          | 649            | 1,159                                | 262             | Tiger Global                   | 26                         |
| 29  | SoftBank Vision Fund 2      | CVC         | –              | 646            | 1,057                                | 187             | Tiger Global                   | 17                         |
| 30  | Greycroft                   | VC          | United States  | 644            | 1,003                                | 248             | Gaingels                       | 15                         |
| 31  | Bpifrance                   | government  | France         | 643            | 1,100                                | 354             | Eurazeo                        | 28                         |
| 32  | Lux Capital                 | VC          | United States  | 623            | 1,226                                | 226             | Founders Fund                  | 37                         |
| 33  | Silicon Valley Bank         | bank-debt   | United States  | 617            | 861                                  | 226             | Trinity Capital                | 10                         |
| 34  | NEA                         | VC          | United States  | 614            | 942                                  | 206             | Andreessen Horowitz            | 15                         |
| 35  | Intel Capital               | CVC         | United States  | 607            | 1,046                                | 264             | Nvidia                         | 12                         |
| 36  | Google                      | CVC         | United States  | 596            | 923                                  | 213             | Microsoft                      | 16                         |
| 37  | Soma Capital                | VC          | United States  | 582            | 1,022                                | 199             | Y Combinator                   | 84                         |
| 38  | Coinbase Ventures           | VC          | United States  | 575            | 959                                  | 154             | Pantera Capital                | 19                         |
| 39  | Wellington Management       | PE          | United States  | 572            | 1,175                                | 186             | Tiger Global                   | 20                         |
| 40  | Mirae Asset                 | VC          | Indonesia      | 567            | 828                                  | 127             | Alexandria Venture Investments | 8                          |
| 41  | Menlo Ventures              | VC          | United States  | 551            | 1,125                                | 226             | Andreessen Horowitz            | 18                         |
| 42  | Google Ventures             | CVC         | United States  | 547            | 878                                  | 184             | Sequoia Capital                | 13                         |
| 43  | Goodwater Capital           | VC          | United States  | 547            | 830                                  | 188             | Y Combinator                   | 39                         |
| 44  | Microsoft                   | CVC         | United States  | 540            | 928                                  | 154             | Nvidia                         | 21                         |
| 45  | Sosv                        | VC          | United States  | 540            | 697                                  | 189             | Artesian                       | 15                         |
| 46  | Speedinvest                 | VC          | Austria        | 539            | 870                                  | 243             | Seedcamp                       | 16                         |
| 47  | Spark Capital               | VC          | United States  | 535            | 1,098                                | 231             | Sequoia Capital                | 30                         |
| 48  | Blume Ventures              | VC          | India          | 530            | 1,082                                | 279             | Nexus Venture Partners         | 28                         |
| 49  | DST Global                  | VC          | United Kingdom | 524            | 1,102                                | 183             | Tiger Global                   | 32                         |
| 50  | GGV Capital                 | VC          | United States  | 516            | 876                                  | 191             | Tiger Global                   | 22                         |

### Strongest co-investor pairs in US startups (top 30)

Rounds raised by companies based in United States.

| #   | Investor A                  | Investor B                  | Shared rounds in United States   | Total shared rounds   | Type A   | Type B      |
|:----|:----------------------------|:----------------------------|:---------------------------------|:----------------------|:---------|:------------|
| 1   | Andreessen Horowitz         | Sequoia Capital             | 56                               | 67                    | VC       | VC          |
| 2   | Sequoia Capital             | Tiger Global                | 45                               | 87                    | VC       | PE          |
| 3   | Coatue                      | Sequoia Capital             | 43                               | 63                    | PE       | VC          |
| 4   | Lightspeed Venture Partners | Sequoia Capital             | 40                               | 72                    | VC       | VC          |
| 5   | Soma Capital                | Y Combinator                | 38                               | 84                    | VC       | accelerator |
| 6   | Coatue                      | Tiger Global                | 38                               | 63                    | PE       | PE          |
| 7   | Accel                       | Sequoia Capital             | 35                               | 68                    | VC       | VC          |
| 8   | Andreessen Horowitz         | Y Combinator                | 35                               | 42                    | VC       | accelerator |
| 9   | Andreessen Horowitz         | Tiger Global                | 35                               | 44                    | VC       | PE          |
| 10  | Index Ventures              | Sequoia Capital             | 34                               | 54                    | VC       | VC          |
| 11  | Andreessen Horowitz         | Founders Fund               | 34                               | 40                    | VC       | VC          |
| 12  | Insight Partners            | Tiger Global                | 33                               | 53                    | PE       | PE          |
| 13  | Founders Fund               | Khosla Ventures             | 33                               | 41                    | VC       | VC          |
| 14  | Coatue                      | Lightspeed Venture Partners | 32                               | 44                    | PE       | VC          |
| 15  | Accel                       | Tiger Global                | 31                               | 71                    | VC       | PE          |
| 16  | Altimeter Capital           | Coatue                      | 30                               | 34                    | PE       | PE          |
| 17  | Kleiner Perkins             | Sequoia Capital             | 29                               | 36                    | VC       | VC          |
| 18  | Coatue                      | Dragoneer Investment Group  | 29                               | 42                    | PE       | PE          |
| 19  | Founders Fund               | Lux Capital                 | 28                               | 37                    | VC       | VC          |
| 20  | Dragoneer Investment Group  | Tiger Global                | 28                               | 46                    | PE       | PE          |
| 21  | Andreessen Horowitz         | Thrive Capital              | 28                               | 33                    | VC       | VC          |
| 22  | Orbimed                     | Ra Capital Management       | 27                               | 32                    | VC       | VC          |
| 23  | Andreessen Horowitz         | Coatue                      | 26                               | 30                    | VC       | PE          |
| 24  | 8VC                         | Founders Fund               | 26                               | 30                    | VC       | VC          |
| 25  | Insight Partners            | Lightspeed Venture Partners | 26                               | 30                    | PE       | VC          |
| 26  | Janus Henderson Investors   | Ra Capital Management       | 25                               | 26                    | VC       | VC          |
| 27  | Janus Henderson Investors   | Logos Capital               | 25                               | 26                    | VC       | VC          |
| 28  | Atreides Management         | Valor Equity Partners       | 25                               | 31                    | PE       | PE          |
| 29  | Accel                       | Y Combinator                | 25                               | 42                    | VC       | accelerator |
| 30  | Salesforce Ventures         | Tiger Global                | 24                               | 31                    | CVC      | PE          |

### Strongest co-investor pairs in UK startups (top 30)

Rounds raised by companies based in United Kingdom.

| #   | Investor A                               | Investor B                          | Shared rounds in United Kingdom   | Total shared rounds   | Type A      | Type B      |
|:----|:-----------------------------------------|:------------------------------------|:----------------------------------|:----------------------|:------------|:------------|
| 1   | North East Innovation Fund               | Northstar Ventures                  | 17                                | 17                    | VC          | VC          |
| 2   | European Regional Development Fund       | North East Venture Fund             | 16                                | 17                    | government  | VC          |
| 3   | European Regional Development Fund       | Mercia Ventures                     | 15                                | 16                    | government  | VC          |
| 4   | Mercia Ventures                          | North East Venture Fund             | 15                                | 18                    | VC          | VC          |
| 5   | European Regional Development Fund       | Northstar Ventures                  | 11                                | 11                    | government  | VC          |
| 6   | Localglobe                               | Seedcamp                            | 10                                | 13                    | VC          | accelerator |
| 7   | European Regional Development Fund       | North East Innovation Fund          | 10                                | 10                    | government  | VC          |
| 8   | BGF                                      | Parkwalk Advisors                   | 9                                 | 12                    | other       | VC          |
| 9   | IP Group                                 | Parkwalk Advisors                   | 8                                 | 8                     | VC          | VC          |
| 10  | MMC Ventures                             | Seedcamp                            | 8                                 | 10                    | VC          | accelerator |
| 11  | BGF                                      | Octopus Ventures                    | 7                                 | 11                    | other       | VC          |
| 12  | Equity Gap                               | Old College Capital                 | 7                                 | 7                     | VC          | VC          |
| 13  | Outward VC                               | Seedcamp                            | 7                                 | 7                     | VC          | accelerator |
| 14  | Mercia Ventures                          | Midlands Engine Investment Fund     | 7                                 | 7                     | VC          | VC          |
| 15  | Seedcamp                                 | Speedinvest                         | 7                                 | 16                    | accelerator | VC          |
| 16  | MMC Ventures                             | Octopus Ventures                    | 7                                 | 7                     | VC          | VC          |
| 17  | MEIF Proof of Concept & Early Stage Fund | Mercia Ventures                     | 7                                 | 7                     | VC          | VC          |
| 18  | BGF                                      | Business Growth Fund                | 7                                 | 9                     | other       | VC          |
| 19  | Scottish Investment Bank                 | Sis Ventures                        | 7                                 | 7                     | bank-debt   | VC          |
| 20  | Amadeus Capital Partners                 | Octopus Ventures                    | 7                                 | 7                     | VC          | VC          |
| 21  | Equity Gap                               | Scottish Investment Bank            | 7                                 | 7                     | VC          | bank-debt   |
| 22  | Barclays                                 | Citi Ventures                       | 6                                 | 18                    | bank-debt   | CVC         |
| 23  | Cambridge Innovation Capital             | Parkwalk Advisors                   | 6                                 | 7                     | VC          | VC          |
| 24  | Cambridge Innovation Capital             | Tencent                             | 6                                 | 7                     | VC          | CVC         |
| 25  | Citi Ventures                            | HSBC                                | 6                                 | 16                    | CVC         | bank-debt   |
| 26  | Blume Ventures                           | DSG Consumer Partners               | 6                                 | 8                     | VC          | VC          |
| 27  | Blackfinch Ventures                      | Praetura Ventures                   | 6                                 | 6                     | VC          | VC          |
| 28  | Localglobe                               | Octopus Ventures                    | 6                                 | 8                     | VC          | VC          |
| 29  | MEIF Proof of Concept & Early Stage Fund | Mercia’s EIS funds                  | 6                                 | 6                     | VC          | VC          |
| 30  | Mercia Ventures                          | Northern Powerhouse Investment Fund | 6                                 | 6                     | VC          | government  |

### Strongest co-investor pairs in Indian startups (top 30)

Rounds raised by companies based in India.

| #   | Investor A                  | Investor B                | Shared rounds in India   | Total shared rounds   | Type A    | Type B      |
|:----|:----------------------------|:--------------------------|:-------------------------|:----------------------|:----------|:------------|
| 1   | 9Unicorns                   | Venture Catalysts         | 45                       | 52                    | VC        | VC          |
| 2   | Peak XV Partners            | Tiger Global              | 30                       | 54                    | VC        | PE          |
| 3   | Sequoia Capital             | Tiger Global              | 28                       | 87                    | VC        | PE          |
| 4   | Accel                       | Tiger Global              | 24                       | 71                    | VC        | PE          |
| 5   | Venture Catalysts           | Letsventure               | 23                       | 25                    | VC        | other       |
| 6   | Matrix Partners             | Sequoia Capital           | 23                       | 23                    | VC        | VC          |
| 7   | Matrix Partners India       | Peak XV Partners          | 23                       | 25                    | VC        | VC          |
| 8   | Accel                       | Chiratae Ventures         | 22                       | 27                    | VC        | VC          |
| 9   | Accel                       | Elevation Capital         | 21                       | 27                    | VC        | VC          |
| 10  | Venture Catalysts           | Inflection Point Ventures | 21                       | 23                    | VC        | VC          |
| 11  | Alteria Capital             | Innoven Capital           | 20                       | 23                    | bank-debt | bank-debt   |
| 12  | Accel                       | Sequoia Capital           | 20                       | 68                    | VC        | VC          |
| 13  | Elevation Capital           | Peak XV Partners          | 19                       | 20                    | VC        | VC          |
| 14  | Soma Capital                | Y Combinator              | 19                       | 84                    | VC        | accelerator |
| 15  | Ribbit Capital              | Sequoia Capital           | 19                       | 33                    | VC        | VC          |
| 16  | Elevation Capital           | Matrix Partners India     | 18                       | 19                    | VC        | VC          |
| 17  | DSG Consumer Partners       | Saama Capital             | 18                       | 22                    | VC        | VC          |
| 18  | Accel                       | Alteria Capital           | 18                       | 21                    | VC        | bank-debt   |
| 19  | Blume Ventures              | Nexus Venture Partners    | 18                       | 28                    | VC        | VC          |
| 20  | IAN Fund                    | Indian Angel Network      | 18                       | 21                    | VC        | other       |
| 21  | Accel                       | Peak XV Partners          | 18                       | 34                    | VC        | VC          |
| 22  | Matrix Partners             | Peak XV Partners          | 17                       | 17                    | VC        | VC          |
| 23  | Alteria Capital             | Stride Ventures           | 17                       | 19                    | bank-debt | bank-debt   |
| 24  | Steadview Capital           | Tiger Global              | 17                       | 28                    | PE        | PE          |
| 25  | Inflection Point Ventures   | IPV                       | 17                       | 19                    | VC        | VC          |
| 26  | Blume Ventures              | Peak XV Partners          | 17                       | 21                    | VC        | VC          |
| 27  | Alteria Capital             | Trifecta Capital          | 17                       | 17                    | bank-debt | bank-debt   |
| 28  | Ribbit Capital              | Tiger Global              | 16                       | 22                    | VC        | PE          |
| 29  | Inflection Point Ventures   | Letsventure               | 16                       | 18                    | VC        | other       |
| 30  | Lightspeed Venture Partners | Peak XV Partners          | 16                       | 20                    | VC        | VC          |

### Co-investment by investor headquarters country pair (top 30)

Only pairs where both investors have a known headquarters.

| #   | HQ country A         | HQ country B   | Investor pairs   | Pair-rounds   | Pairs with 5+ shared rounds   | Strongest pair                                 |
|:----|:---------------------|:---------------|:-----------------|:--------------|:------------------------------|:-----------------------------------------------|
| 1   | United States        | United States  | 64,627           | 97,329        | 1,843                         | Sequoia Capital + Tiger Global (87)            |
| 2   | United Kingdom       | United States  | 9,390            | 13,541        | 224                           | Index Ventures + Sequoia Capital (54)          |
| 3   | India                | United States  | 4,993            | 7,565         | 153                           | Peak XV Partners + Tiger Global (54)           |
| 4   | Canada               | United States  | 4,626            | 6,102         | 64                            | Shopify + Stripe (18)                          |
| 5   | India                | India          | 3,821            | 5,878         | 124                           | 9Unicorns + Venture Catalysts (52)             |
| 6   | Singapore            | United States  | 3,276            | 4,827         | 94                            | GIC + Tiger Global (25)                        |
| 7   | China                | United States  | 3,521            | 4,626         | 46                            | Tencent + Tiger Global (26)                    |
| 8   | Germany              | United States  | 3,391            | 4,538         | 45                            | Global Founders Capital + Y Combinator (40)    |
| 9   | France               | United States  | 2,611            | 3,459         | 37                            | Kima Ventures + Y Combinator (14)              |
| 10  | United Kingdom       | United Kingdom | 2,190            | 3,184         | 54                            | Localglobe + Seedcamp (13)                     |
| 11  | Japan                | United States  | 2,340            | 3,119         | 41                            | Softbank + Tiger Global (27)                   |
| 12  | Israel               | United States  | 2,350            | 3,089         | 24                            | Madrona Venture Group + Vulcan Capital (10)    |
| 13  | Australia            | United States  | 2,333            | 2,883         | 14                            | Artesian + Sosv (15)                           |
| 14  | Brazil               | United States  | 1,672            | 2,346         | 28                            | Monashees + Tiger Global (22)                  |
| 15  | Switzerland          | United States  | 1,566            | 2,279         | 37                            | Altimeter Capital + Benchmark (17)             |
| 16  | Netherlands          | United States  | 1,385            | 1,789         | 15                            | Accel + Prosus Ventures (26)                   |
| 17  | South Korea          | United States  | 1,312            | 1,621         | 19                            | 500 Startups + Y Combinator (10)               |
| 18  | United Arab Emirates | United States  | 1,207            | 1,598         | 20                            | Mubadala + Sequoia Capital (9)                 |
| 19  | China                | China          | 1,189            | 1,595         | 21                            | Hillhouse Capital + Sequoia Capital China (16) |
| 20  | France               | France         | 939              | 1,475         | 38                            | Bpifrance + Eurazeo (28)                       |
| 21  | Canada               | Canada         | 980              | 1,418         | 23                            | Golden Ventures + Inovia Capital (14)          |
| 22  | Spain                | United States  | 1,110            | 1,369         | 8                             | Caixabank + Global Payments (9)                |
| 23  | Germany              | United Kingdom | 964              | 1,303         | 13                            | Cherry Ventures + Seedcamp (10)                |
| 24  | Sweden               | United States  | 888              | 1,255         | 17                            | HM Capital + Stripe (13)                       |
| 25  | Germany              | Germany        | 828              | 1,120         | 18                            | Global Founders Capital + Picus Capital (9)    |
| 26  | India                | Singapore      | 689              | 1,086         | 23                            | Beenext + Peak XV Partners (19)                |
| 27  | France               | United Kingdom | 676              | 981           | 13                            | Kima Ventures + Seedcamp (13)                  |
| 28  | India                | United Kingdom | 650              | 880           | 11                            | Barclays + HSBC (15)                           |
| 29  | Italy                | United States  | 710              | 844           | 2                             | GSR Ventures + Spartan Group (5)               |
| 30  | Denmark              | United States  | 584              | 802           | 11                            | Novo Holdings + Orbimed (13)                   |

### Co-investment by sector (top 25 sectors)

Share syndicated = rounds with two or more named organisation investors.

| Sector                               | Rounds   | Share syndicated   | Investors per round   | Investor pairs   | Pairs with 3+ shared rounds   | Strongest pair                                                 |
|:-------------------------------------|:---------|:-------------------|:----------------------|:-----------------|:------------------------------|:---------------------------------------------------------------|
| Fintech                              | 8,598    | 69.6%              | 3.33                  | 52,814           | 1,756                         | Soma Capital + Y Combinator (28)                               |
| Enterprise Applications              | 8,485    | 68.2%              | 3.00                  | 37,790           | 1,298                         | Index Ventures + Sequoia Capital (20)                          |
| Consumer                             | 5,008    | 63.4%              | 2.91                  | 22,834           | 610                           | Matrix Partners + Sequoia Capital (10)                         |
| High Tech                            | 4,626    | 70.7%              | 3.48                  | 32,786           | 984                           | Andreessen Horowitz + Sequoia Capital (22)                     |
| Healthtech                           | 4,221    | 69.3%              | 3.20                  | 23,035           | 578                           | Eight Roads Ventures + F-Prime Capital (9)                     |
| Enterprise Infrastructure            | 3,339    | 74.7%              | 3.37                  | 18,412           | 870                           | Coatue + Lightspeed Venture Partners (20)                      |
| Retail                               | 3,320    | 63.9%              | 2.89                  | 14,847           | 359                           | 9Unicorns + Venture Catalysts (11)                             |
| Life Sciences                        | 3,265    | 72.8%              | 3.84                  | 25,285           | 1,634                         | Orbimed + Ra Capital Management (32)                           |
| Food and Agriculture Tech            | 3,250    | 64.7%              | 3.03                  | 16,610           | 415                           | Ankur Capital + Matrix Partners India (9)                      |
| Business Services                    | 2,200    | 49.1%              | 2.37                  | 7,676            | 124                           | Coatue + Index Ventures (4)                                    |
| Energy Tech                          | 2,063    | 64.0%              | 2.97                  | 10,491           | 223                           | Blume Ventures + British International Investment (8)          |
| Healthcare                           | 1,419    | 55.7%              | 2.64                  | 5,731            | 91                            | Insight Partners + Sequoia Capital (5)                         |
| Food and Agriculture                 | 1,322    | 52.4%              | 2.32                  | 4,033            | 61                            | Avaana Capital + NABVENTURES (6)                               |
| Edtech                               | 1,312    | 63.7%              | 2.81                  | 6,031            | 123                           | Elevation Capital + Lightspeed Venture Partners (9)            |
| Real Estate and Construction Tech    | 1,180    | 65.8%              | 2.91                  | 5,554            | 72                            | Accel + Foundamental (5)                                       |
| Energy                               | 1,131    | 52.3%              | 2.50                  | 4,479            | 56                            | Rockefeller Foundation + US African Development Foundation (5) |
| Environment Tech                     | 951      | 64.7%              | 3.02                  | 5,121            | 37                            | Shopify + Stripe (9)                                           |
| Financial Services                   | 920      | 50.2%              | 2.41                  | 3,212            | 58                            | Capitalg + Maj Invest (5)                                      |
| Consumer Goods                       | 781      | 51.3%              | 2.39                  | 2,581            | 22                            | Venture Catalysts + Inflection Point Ventures (5)              |
| Media & Entertainment                | 708      | 58.6%              | 2.63                  | 2,843            | 27                            | Nexus Venture Partners + Shunwei Capital (4)                   |
| Aerospace, Maritime and Defense Tech | 625      | 67.2%              | 3.78                  | 5,276            | 129                           | Founders Fund + Lux Capital (8)                                |
| Semiconductors                       | 556      | 73.4%              | 3.57                  | 3,809            | 104                           | Iag Capital Partners + Nvidia (6)                              |
| Real Estate and Construction         | 444      | 51.4%              | 2.27                  | 1,337            | 6                             | Acrew Capital + NFX (4)                                        |
| Telecom                              | 427      | 56.9%              | 2.57                  | 1,759            | 5                             | Omidyar Network India + YourNest Venture Capital (3)           |
| Auto Tech                            | 345      | 71.3%              | 3.62                  | 2,577            | 68                            | Alphabet + Andreessen Horowitz (7)                             |

### Co-investment by investor type pair

| Type A      | Type B      | Investor pairs   | Share of pairs   | Pair-rounds   | Shared rounds per pair   |
|:------------|:------------|:-----------------|:-----------------|:--------------|:-------------------------|
| VC          | VC          | 182,075          | 60.0%            | 233,246       | 1.28                     |
| PE          | VC          | 26,795           | 8.8%             | 38,608        | 1.44                     |
| CVC         | VC          | 22,993           | 7.6%             | 30,605        | 1.33                     |
| VC          | other       | 21,582           | 7.1%             | 24,659        | 1.14                     |
| VC          | bank-debt   | 9,643            | 3.2%             | 11,536        | 1.20                     |
| VC          | government  | 6,403            | 2.1%             | 8,389         | 1.31                     |
| VC          | accelerator | 6,104            | 2.0%             | 9,032         | 1.48                     |
| PE          | PE          | 5,170            | 1.7%             | 8,496         | 1.64                     |
| CVC         | PE          | 3,602            | 1.2%             | 5,655         | 1.57                     |
| bank-debt   | bank-debt   | 2,631            | 0.9%             | 3,427         | 1.30                     |
| other       | other       | 2,430            | 0.8%             | 2,853         | 1.17                     |
| CVC         | CVC         | 1,868            | 0.6%             | 3,061         | 1.64                     |
| PE          | bank-debt   | 1,737            | 0.6%             | 2,331         | 1.34                     |
| PE          | other       | 1,544            | 0.5%             | 1,845         | 1.19                     |
| CVC         | other       | 1,467            | 0.5%             | 1,764         | 1.20                     |
| bank-debt   | other       | 1,253            | 0.4%             | 1,442         | 1.15                     |
| PE          | government  | 1,158            | 0.4%             | 1,945         | 1.68                     |
| CVC         | bank-debt   | 1,141            | 0.4%             | 1,609         | 1.41                     |
| government  | other       | 769              | 0.3%             | 936           | 1.22                     |
| bank-debt   | government  | 755              | 0.2%             | 913           | 1.21                     |
| CVC         | government  | 699              | 0.2%             | 1,045         | 1.49                     |
| accelerator | other       | 388              | 0.1%             | 461           | 1.19                     |
| government  | government  | 385              | 0.1%             | 624           | 1.62                     |
| CVC         | accelerator | 288              | 0.1%             | 467           | 1.62                     |
| PE          | accelerator | 226              | 0.1%             | 396           | 1.75                     |
| accelerator | bank-debt   | 149              | 0.0%             | 183           | 1.23                     |
| accelerator | accelerator | 89               | 0.0%             | 137           | 1.54                     |
| accelerator | government  | 77               | 0.0%             | 96            | 1.25                     |

### Syndication by year

| Year           | Rounds with a named investor   | Syndicated rounds   | Share syndicated   | Investors per round   | Rounds with 5+ investors   | New pairs that year   |
|:---------------|:-------------------------------|:--------------------|:-------------------|:----------------------|:---------------------------|:----------------------|
| 2019           | 6,250                          | 3,914               | 62.6%              | 2.72                  | 1,050                      | 24,448                |
| 2020           | 7,580                          | 4,770               | 62.9%              | 2.83                  | 1,425                      | 31,193                |
| 2021           | 11,984                         | 8,031               | 67.0%              | 3.21                  | 2,812                      | 63,979                |
| 2022           | 11,193                         | 7,520               | 67.2%              | 3.20                  | 2,641                      | 58,876                |
| 2023           | 9,404                          | 5,940               | 63.2%              | 2.93                  | 1,875                      | 39,483                |
| 2024           | 9,145                          | 5,922               | 64.8%              | 3.06                  | 1,977                      | 41,722                |
| 2025           | 6,896                          | 4,535               | 65.8%              | 3.13                  | 1,585                      | 30,917                |
| 2026 (Jan–Jun) | 2,347                          | 1,550               | 66.0%              | 3.32                  | 579                        | 12,803                |

## Method

1. **Rounds and investors.** The same cleaned rounds and the same organisation-only investor list as the VC investor directory release: January 2019 to June 2026, people, generic phrases ("angel investors", "existing investors") and data providers removed, aliases merged (a16z = Andreessen Horowitz). Two archive back-fill days (2024-04-22 and 2025-02-13) are excluded.
2. **Same family.** Pairs of a firm and its own regional arm or fund vehicle (Sequoia Capital + Sequoia Capital India, Softbank + SoftBank Vision Fund 2, Goldman Sachs + Goldman Sachs Alternatives) are removed: news often names both for one cheque.
3. **Edges.** Every unordered pair of distinct investor organisations named in the same round is an edge; `shared_deals` counts the rounds. The pair is written in alphabetical order of the names, so each pair appears once.
4. **Sector and country.** `top_shared_sector` and `top_shared_country` are the most frequent sector and company country across the shared rounds.
5. **Types.** The investor types come from the directory release (rule-based: VC, CVC, PE, accelerator, bank-debt, government, other).
6. **Sample.** Pairs are sampled whole by a hash of the pair; an investor's edges are therefore spread across the sample, not kept together. Degree and other network measures in the report are computed on the full edge list.

7. **Sample.** Each pair key is ranked by `sha1(key)`. Keys are taken in rank order until the file holds max(25%, 5,000) rows (capped at 100,000).

8. **Profile links.** Links are built from Fliar's company index and checked against it. A row whose company has no public profile has an empty link.

## Columns

| Column               | Description                                                                       |
|:---------------------|:----------------------------------------------------------------------------------|
| `pair_id`            | stable 12-character ID of the investor pair                                       |
| `investor_a`         | first investor organisation of the pair (alphabetical)                            |
| `investor_a_slug`    | URL-style slug of investor_a (key for the Radar investor-profile endpoint)        |
| `investor_a_type`    | type of investor_a (VC / CVC / PE / accelerator / bank-debt / government / other) |
| `investor_a_domain`  | website domain of investor_a when known                                           |
| `investor_b`         | second investor organisation of the pair (alphabetical)                           |
| `investor_b_type`    | type of investor_b                                                                |
| `investor_b_domain`  | website domain of investor_b when known                                           |
| `shared_deals`       | funding rounds both investors joined, January 2019 to June 2026                   |
| `first_year`         | year of their first shared round                                                  |
| `last_year`          | year of their latest shared round                                                 |
| `top_shared_sector`  | most frequent sector of the shared rounds                                         |
| `top_shared_country` | most frequent company country of the shared rounds                                |
| `fliar_profile_url`  | full company profile on Fliar (financials, funding, team, news)                   |

**Available only through the [Radar API](https://github.com/fliarbi/radar-api-mcp):** the shared rounds themselves (company, date, stage, amount, lead); each investor's full portfolio; partner and contact details; the remaining pairs and the monthly refresh.

## Limitations

- Built from news: rounds that were never reported are missing, and reports often name only some of the investors, so weak ties are under-counted.
- An edge means the two investors were named in the same round, not that they negotiated together.
- Investor names come from article text; a few aliases stay split, which splits their edges too.
- Because the sample is a random 25% of edges, network measures computed on the sample (degree, centrality) are lower than on the full graph.
- 2026 covers January to June only.

## Citation

Fliar Research (2026). *VC Co-Investment Network: 303k Investor Pairs* (sample release). Data: Radar API, https://github.com/fliarbi/radar-api-mcp. Licence CC BY-NC 4.0.
