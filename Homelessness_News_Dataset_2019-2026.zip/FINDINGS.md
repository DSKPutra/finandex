# Homelessness in the news, 2019–2026: findings stated for citation

Each finding is one self-contained sentence in encyclopedic register, with its number, window and
comparison, plus the Wikipedia article and section it is written for (section names checked against
the live article on 2026-10-17). Grades: **A** exact count from the records; **B** depends on a keyword
rule (precision measured by hand at 85% for the news match); **C** sensitive to which outlets the index
collects. All findings measure news coverage, not the number of people experiencing homelessness. No
finding names or locates an individual case. Source for all findings: Fliar BI, *Homelessness in the
News 2019–2026* (dataset and working paper), built with the
[Prism News API](https://github.com/fliarbi/prism-news-api).

### F1
**Grade:** B
**Sentence:** In a global news index covering January 2019 to July 2026, homelessness took a 36.5% smaller share of news coverage in 2025 than in 2019, falling from 11.01 to 6.99 articles per 10,000 news articles.
**Wikipedia:** [[Homelessness]] § 2020s
**Basis:** Annual homelessness articles divided by all articles in the index for the same year, complete years 2019–2025.
**Limit:** The share is a measure of attention, not of the size of the homeless population; it also depends on how the outlet mix of the index changed.

### F2
**Grade:** B
**Sentence:** December 2019 was the month in which homelessness took its largest share of global news between January 2019 and July 2026, at 17.27 articles per 10,000, 1.57 times the 2019 annual share; April 2020 was second, at 15.35.
**Wikipedia:** [[Homelessness]] § (new section)
**Basis:** Monthly homelessness articles per 10,000 news articles, every month from January 2019 to July 2026.
**Limit:** The two peaks are reported by month only; no cause is tested.

### F3
**Grade:** B
**Sentence:** Between 2019 and 2025, an average of 19.58% of each year's homelessness news appeared in December and January, against 16.67% if coverage were spread evenly, while June was the quietest month at 7.08%.
**Wikipedia:** [[Homelessness]] § (new section)
**Basis:** Within-year month shares of matched articles, averaged over the complete years 2019–2025.
**Limit:** The index over-represents Northern Hemisphere outlets, so the winter peak is a northern winter.

### F4
**Grade:** C
**Sentence:** Between January 2023 and July 2026, the United States accounted for 67.5% of located homelessness news, 1.39 times its share of all located news, while India accounted for 2.82%, only 0.21 times its overall share.
**Wikipedia:** [[Homelessness]] § Homelessness by continent
**Basis:** Primary country of 40,290 located articles, with place tags derived from ordinary words counted as unlocated; lift = topic share ÷ share of all located news.
**Limit:** Country is the article's primary location as tagged by the index, not the outlet's country; English vocabulary ("homeless", "rough sleeping") may under-match translated coverage.

### F5
**Grade:** C
**Sentence:** Relative to their share of all news, Ireland (2.43 times), New Zealand (2.12 times) and Canada (1.68 times) were the most over-represented countries in homelessness news between January 2023 and July 2026, ahead of the United Kingdom (1.48 times) and the United States (1.39 times).
**Wikipedia:** [[Homelessness]] § Ireland
**Basis:** Lift of the 16 countries with at least 100 located homelessness articles.
**Limit:** Lift is a coverage measure; it does not rank countries by rates of homelessness.

### F6
**Grade:** B
**Sentence:** Of US-located homelessness news articles carrying a tone label between January 2023 and July 2026, 66.4% were negative in tone, 2.01 times the 33.1% negative share of all US-located news in the same index; across all countries the figures were 65.3% and 33.6%.
**Wikipedia:** [[Homelessness in the United States]] § Public attitudes
**Basis:** Top sentiment label of each article, grouped into negative, neutral and positive; 27,026 labelled US-located articles; 99.4% of sampled articles carry a label.
**Limit:** Tone is machine-labelled from the article opening and describes the article, not attitudes toward homeless people.

### F7
**Grade:** B
**Sentence:** In a global news index, a machine-assigned priority rating placed 78.2% of homelessness articles at critical priority (7 or higher on a 1–9 scale) between January 2023 and July 2026, 1.84 times the 42.6% share for all news.
**Wikipedia:** [[Homelessness]] § (new section)
**Basis:** Top priority label per article; critical = priority ≥ 7.
**Limit:** Priority is a model rating of editorial urgency.

### F8
**Grade:** B
**Sentence:** Emergency shelter programmes appeared in 18.18% of themed homelessness articles between January 2023 and July 2026, 927.93 times their frequency in all themed news, and homelessness prevention programmes in 29.79%.
**Wikipedia:** [[Homelessness]] § Refuges and alternative accommodation
**Basis:** Theme labels assigned to each article; lift against all themed news.
**Limit:** Themes are machine-assigned; one article can carry several themes.

### F9
**Grade:** B
**Sentence:** Eviction prevention services appeared in 3.02% of themed homelessness articles between January 2023 and July 2026, 645.67 times their frequency in all themed news.
**Wikipedia:** [[Homelessness]] § Rent and eviction
**Basis:** Theme labels assigned to each article; lift against all themed news.
**Limit:** Themes are machine-assigned and describe the article opening.

### F10
**Grade:** B
**Sentence:** Veteran housing support appeared in 1.94% of themed homelessness articles between January 2023 and July 2026, 697.8 times its frequency in all themed news.
**Wikipedia:** [[Homelessness in the United States]] § Homeless veterans
**Basis:** Theme labels assigned to each article; lift against all themed news.
**Limit:** The theme is not restricted to the United States, although most located articles are American.

### F11
**Grade:** A
**Sentence:** Of 131,844 news items in the index that used homelessness vocabulary between January 2019 and July 2026, 3,983 (3.0%) were removed from a count of homelessness coverage by exclusion rules aimed mainly at people left without shelter by floods, earthquakes or armed conflict, and at homeless animals; in a hand check of 40 remaining matches, 2 still described displacement by disaster or war.
**Wikipedia:** [[Homelessness]] § Human and natural disasters
**Basis:** Term matches with and without the release's exclusion patterns; precision check of 40 random matched openings.
**Limit:** Exclusion patterns are tuned on samples; some displacement reports with unusual wording remain.

### F12
**Grade:** A
**Sentence:** Research papers with homelessness in the title rose from 1.62 to 2.19 per 10,000 published papers between 2015 and 2021, a 1.35-fold increase in the topic's share of the scientific literature, before falling back to 1.73 in 2025.
**Wikipedia:** [[Homelessness]] § (new section)
**Basis:** 13,671 de-duplicated articles and reviews 2015–2025 with homeless, homelessness, unhoused or rough sleeping in the title, repository deposits excluded; denominators are all de-duplicated articles and reviews per year.
**Limit:** Title matching misses papers that name homelessness only in the abstract.

### F13
**Grade:** A
**Sentence:** The three most-cited research papers on homelessness published since 2010 all appeared in Lancet journals and concern health: a review of the health of homeless people in high-income countries by Seena Fazel et al. (2014, 1,601 citations), a meta-analysis of morbidity and mortality by Robert W Aldridge et al. (2017, 896) and a paper on COVID-19 risk by Jack Tsai et al. (2020, 725).
**Wikipedia:** [[Homelessness]] § Healthcare
**Basis:** Citation counts of papers with homelessness terms in the title, published 2010 or later.
**Limit:** Citation counts favour older papers and medical journals, which cite more densely.

### F14
**Grade:** C
**Sentence:** Among US states, Oregon (4.63 times), California (2.9 times) and Arizona (2.62 times) had the most over-represented homelessness coverage relative to their share of American news between January 2023 and July 2026, while New Jersey (0.11 times) and Pennsylvania (0.47 times) had the least; California alone accounted for 28.91% of located US homelessness articles.
**Wikipedia:** [[Homelessness in the United States]] § Situations in cities and states
**Basis:** Primary state of 25,577 located US homelessness articles; lift against all located US news (states with at least 50 articles).
**Limit:** Lift compares coverage shares, not rates of homelessness; a state with a large share of all US news in the index has a large baseline and so a lower lift.

### F15
**Grade:** C
**Sentence:** Between January 2023 and July 2026, Delhi accounted for 22.98% of located Indian homelessness news, 1.77 times its share of Indian news, while Uttarakhand (2.1 times) and Tamil Nadu (1.13 times) were also over-represented and Maharashtra (0.61 times) and Uttar Pradesh (0.82 times) were under-represented.
**Wikipedia:** [[Homelessness in India]] § A growing concern
**Basis:** Primary state of 1,062 located Indian homelessness articles; lift against all located Indian news (states with at least 50 articles).
**Limit:** The Indian base is small, and national stories filed from Delhi count for Delhi.

### F16
**Grade:** C
**Sentence:** Homelessness coverage as a share of New Zealand's news rose from 16.6 to 30.38 articles per 10,000 between 2023 and 2025, the largest rise among the 16 countries with the most homelessness coverage, while Ireland's fell from 43.64 to 10.47.
**Wikipedia:** [[Homelessness]] § New Zealand
**Basis:** Homelessness articles divided by all located articles of the same country per year.
**Limit:** Country baselines for New Zealand and Ireland are small, so the ratios are sensitive to which outlets the index collects.

## Rejected

- **"Homelessness coverage is rising."** Raw article counts rose from 12,997 (2019) to 18,879 (2025), but the index itself grew; as a share of all news the 2025 level (6.99 per 10,000) is below 2019 (11.01). Killed: growth from raw counts.
- **City-level coverage.** The city field tagged common words as places ("winter", "congress", "earth"). Tags derived from 714 such words are now treated as unlocated in every location field (15.3% of city-tagged articles), but the city field still tags state names as cities; no city finding is stated.
- **"Wyoming is among the most over-represented US states."** An earlier build ranked Wyoming fourth among US states by homelessness lift. With place tags derived from ordinary words treated as unlocated, Wyoming keeps only 38 located articles, below the 50-article threshold. Killed: ordinary-word place tags counted as Wyoming.
- **"Jammu and Kashmir is among the most over-represented Indian states."** An earlier build listed it second by lift. With place tags derived from ordinary words treated as unlocated, it has 49 located articles, below the 50-article threshold, so it is not stated. Killed: ordinary-word place tags that had lifted it over the threshold.
- **States of India below 50 articles.** Manipur (7.02) and Tripura (6.92) have the highest lifts, but on 42 and 17 articles; not stated.
- **Organisations most named.** The US Department of Housing and Urban Development leads (2,111 articles), but wire services and social platforms also rank high, so the list measures sourcing habits; not stated as a finding.
- **Turkey 2023.** Turkey's share rose to 31.07 per 10,000 in 2023 and fell to 3.2 in 2025; part of the 2023 value may be earthquake displacement that the exclusions did not remove, so it is not stated.
- **Patents.** Only 19 patent families with homelessness terms in the title were published from 2015 to 2024; too few for a finding.
- **2026 trend.** The index thins after May 2026; 2026 values are partial and excluded from comparisons.
