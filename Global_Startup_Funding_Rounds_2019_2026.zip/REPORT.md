# Global Startup Funding Rounds 2019–2026: findings, method and data card

*Fliar Research · released October 2026 · licence CC BY-NC 4.0*

**How this dataset was acquired.** Every row comes from the [Radar API](https://github.com/fliarbi/radar-api-mcp), Fliar's company-data API and MCP server. Radar reads
business news continuously and extracts each funding announcement into structured fields: company, stage, amount, currency, investors
and date. It then links the company to its record in a database of five million companies. This release covers startups worldwide, January 2019 to June 2026. It runs that
output through a reproducible cleaning pipeline: repeated reports of one deal are merged, recaps of past rounds are dropped, and every
amount is checked against the sentence it was read from. Each row names the article it was read from (`news_source`, `news_url`) and
quotes the sentence (`news_excerpt`). The full, continuously updated data is available through `POST /v1/companies/funding`
([reference](https://github.com/fliarbi/radar-api-mcp/blob/main/docs/reference/get_company_funding.md)) or the `get_company_funding` MCP tool.

> **This file is a 25% sample: 20,227 of 80,911 funding rounds.** It keeps every record for a fixed subset of companies.
> The subset is chosen by a hash, so it stays the same from one release to the next. The findings and tables below were computed
> on the **full** data. For the rest, the withheld fields and monthly updates, [get a Radar API key](https://fliarbi.com/radar-api/developer) ([docs](https://github.com/fliarbi/radar-api-mcp)).
> Each row's `fliar_profile_url` opens the company's full profile on Fliar.

## Key findings

1. **47,428 companies raised 80,911 rounds between 2019 and mid-2026.** 66,936 rounds disclosed an amount, totalling $2.3T.
2. **2021 was the busiest year**, with 14,562 rounds. Disclosed funding in 2025 was $298.4B, 1.5× the 2019 level ($200.2B).
3. **Mega-rounds dominate the dollars.** Rounds of US$100M or more are 10% of rounds with a disclosed amount, but 61% of disclosed dollars.
4. **Early rounds got bigger.** The median Seed round went from $2.1M in 2019 to $4.0M in 2025; the median Series A from $8.9M to $14.0M.
5. **Funding is concentrated.** The top three countries (United States, India, United Kingdom) hold 67% of disclosed dollars.
6. **The fastest-rising sectors** (share of rounds, 2019–2020 vs 2024–2025): Energy Tech (2.3% → 4.1%), Business Services (2.7% → 4.3%), Energy (1.4% → 2.7%).

![Rounds and funding by year](figures/by_year.png)

![Median round size by stage](figures/median_by_stage.png)

![Top 10 by country](figures/top_country.png)

### Funding by year

Full data. 2026 covers January to June.

| Year           | Rounds   | Companies   | With amount   | Disclosed $   | Median round   | Rounds ≥ $100M   | Share of $ in ≥ $100M rounds   |
|:---------------|:---------|:------------|:--------------|:--------------|:---------------|:-----------------|:-------------------------------|
| 2019           | 7,791    | 6,777       | 6,551         | $200.2B       | $8.0M          | 540              | 56.2%                          |
| 2020           | 9,535    | 8,328       | 7,772         | $237.3B       | $7.3M          | 657              | 57.5%                          |
| 2021           | 14,562   | 12,368      | 12,081        | $489.7B       | $10.0M         | 1,502            | 65.0%                          |
| 2022           | 13,849   | 12,249      | 11,675        | $374.6B       | $8.8M          | 1,063            | 57.4%                          |
| 2023           | 12,055   | 10,682      | 9,888         | $278.3B       | $6.9M          | 764              | 56.8%                          |
| 2024           | 11,573   | 10,174      | 9,565         | $294.0B       | $7.9M          | 854              | 58.6%                          |
| 2025           | 8,645    | 7,570       | 7,065         | $298.4B       | $11.2M         | 842              | 64.5%                          |
| 2026 (Jan–Jun) | 2,901    | 2,750       | 2,339         | $132.3B       | $13.7M         | 388              | 72.8%                          |

### Round size by stage

| Stage            | Rounds   | Disclosed $   | 25th pct   | Median   | 75th pct   | Median 2019   | Median 2025   |
|:-----------------|:---------|:--------------|:-----------|:---------|:-----------|:--------------|:--------------|
| Seed             | 13,357   | $52.7B        | $1.6M      | $3.1M    | $5.5M      | $2.1M         | $4.0M         |
| Series A         | 11,472   | $181.0B       | $7.0M      | $12.0M   | $20.0M     | $8.9M         | $14.0M        |
| Series B         | 6,391    | $265.5B       | $17.3M     | $30.0M   | $50.0M     | $20.6M        | $34.5M        |
| Pre-seed         | 3,180    | $4.1B         | $515.8K    | $1.1M    | $2.0M      | $500.0K       | $1.4M         |
| Series C         | 3,161    | $257.0B       | $30.5M     | $55.0M   | $100.0M    | $35.0M        | $61.2M        |
| Debt             | 2,259    | $100.6B       | $6.0M      | $20.5M   | $73.3M     | $17.0M        | $24.8M        |
| Pre-Series A     | 1,950    | $5.7B         | $1.1M      | $2.2M    | $4.1M      | $1.5M         | $2.8M         |
| Growth / PE      | 1,717    | $85.2B        | $10.8M     | $30.0M   | $74.9M     | $20.0M        | $40.0M        |
| Grant            | 1,617    | $8.7B         | $102.0K    | $771.0K  | $3.2M      | $257.0K       | $2.1M         |
| Series D         | 1,459    | $179.6B       | $50.0M     | $95.0M   | $155.0M    | $60.0M        | $93.0M        |
| Strategic        | 1,072    | $29.8B        | $5.0M      | $14.0M   | $50.0M     | $18.0M        | $11.9M        |
| Series E         | 670      | $117.4B       | $65.0M     | $125.0M  | $240.0M    | $100.0M       | $117.5M       |
| Angel            | 546      | $373.0M       | $219.0K    | $500.0K  | $1.2M      | $432.0K       | $619.0K       |
| Crowdfunding     | 372      | $738.7M       | $500.0K    | $1.1M    | $2.2M      | $1.4M         | $1.0M         |
| Convertible note | 352      | $11.0B        | $2.8M      | $8.6M    | $33.5M     | $4.0M         | $9.6M         |
| Bridge           | 347      | $3.1B         | $720.0K    | $2.0M    | $8.0M      | $1.7M         | $2.4M         |
| Series F         | 275      | $62.4B        | $85.0M     | $172.0M  | $275.8M    | $88.1M        | $177.5M       |
| Venture debt     | 239      | $3.8B         | $2.9M      | $8.6M    | $21.6M     | $3.8M         | $17.6M        |
| Pre-Series B     | 169      | $1.7B         | $4.6M      | $8.0M    | $13.8M     | $6.0M         | $8.6M         |
| Series G         | 100      | $30.9B        | $79.0M     | $172.5M  | $350.0M    | $287.5M       | $151.0M       |
| Series H         | 36       | $10.1B        | $96.2M     | $200.0M  | $410.0M    | $254.0M       | $146.0M       |
| Pre-Series C     | 28       | $546.1M       | $8.4M      | $13.0M   | $27.0M     | $47.0M        | $12.5M        |
| Pre-Series D     | 4        | $101.8M       | $30.0M     | $30.0M   | $35.9M     |               |               |
| Pre-Series E     | 1        | $90.0M        | $90.0M     | $90.0M   | $90.0M     |               |               |

### Most active investors (top 50)

Rounds each investor joined, full data. Organisations only; aliases such as "Accel" and "Accel Partners" are merged.

| #   | Investor                    | Rounds   | As lead / first named   | Companies   | Disclosed $ in rounds joined   | Median round   | Most common stage   | Top sector                | Active    |
|:----|:----------------------------|:---------|:------------------------|:------------|:-------------------------------|:---------------|:--------------------|:--------------------------|:----------|
| 1   | Sequoia Capital             | 1,130    | 426                     | 637         | $102.4B                        | $35.0M         | Series A            | Fintech                   | 2019–2026 |
| 2   | Y Combinator                | 1,087    | 293                     | 827         | $25.2B                         | $6.3M          | Seed                | Fintech                   | 2019–2026 |
| 3   | Accel                       | 920      | 400                     | 495         | $73.4B                         | $23.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 4   | Tiger Global                | 895      | 388                     | 558         | $118.1B                        | $67.0M         | Series B            | Fintech                   | 2019–2026 |
| 5   | Insight Partners            | 728      | 397                     | 489         | $68.4B                         | $50.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 6   | Lightspeed Venture Partners | 712      | 260                     | 399         | $72.1B                         | $35.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 7   | Andreessen Horowitz         | 608      | 251                     | 378         | $63.2B                         | $45.0M         | Series A            | High Tech                 | 2019–2026 |
| 8   | Bessemer Venture Partners   | 482      | 172                     | 300         | $36.2B                         | $34.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 9   | Khosla Ventures             | 433      | 147                     | 281         | $23.7B                         | $30.0M         | Series A            | Fintech                   | 2019–2026 |
| 10  | Index Ventures              | 421      | 154                     | 243         | $32.0B                         | $40.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 11  | Coatue                      | 384      | 107                     | 210         | $81.9B                         | $120.0M        | Series B            | Fintech                   | 2019–2026 |
| 12  | Techstars                   | 365      | 60                      | 320         | $2.0B                          | $2.9M          | Seed                | Enterprise Applications   | 2019–2026 |
| 13  | Bpifrance                   | 354      | 73                      | 301         | $14.8B                         | $11.9M         | Series A            | Enterprise Applications   | 2019–2026 |
| 14  | Goldman Sachs               | 353      | 122                     | 262         | $37.6B                         | $87.2M         | Debt                | Fintech                   | 2019–2026 |
| 15  | Softbank                    | 346      | 162                     | 229         | $57.9B                         | $148.0M        | Series C            | Consumer                  | 2019–2026 |
| 16  | Founders Fund               | 346      | 94                      | 213         | $43.4B                         | $40.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 17  | Business Angels             | 343      | 48                      | 331         | $1.9B                          | $2.2M          | Seed                | Enterprise Applications   | 2019–2026 |
| 18  | Global Founders Capital     | 343      | 72                      | 273         | $5.9B                          | $6.9M          | Seed                | Fintech                   | 2019–2026 |
| 19  | Google                      | 341      | 106                     | 270         | $31.7B                         | $36.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 20  | Salesforce Ventures         | 340      | 64                      | 232         | $36.1B                         | $50.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 21  | Gaingels                    | 333      | 14                      | 304         | $13.0B                         | $15.0M         | Seed                | Enterprise Applications   | 2019–2026 |
| 22  | Matrix Partners             | 326      | 111                     | 183         | $13.9B                         | $12.5M         | Series A            | Consumer                  | 2019–2026 |
| 23  | Bain Capital Ventures       | 317      | 105                     | 203         | $21.7B                         | $34.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 24  | Fj Labs                     | 307      | 9                       | 260         | $7.5B                          | $12.0M         | Series A            | Fintech                   | 2019–2026 |
| 25  | Temasek                     | 303      | 89                      | 193         | $40.7B                         | $100.0M        | Series C            | Food and Agriculture Tech | 2019–2026 |
| 26  | Alumni Ventures             | 291      | 13                      | 265         | $10.2B                         | $13.9M         | Seed                | High Tech                 | 2019–2026 |
| 27  | Norwest Venture Partners    | 286      | 92                      | 177         | $20.5B                         | $48.5M         | Series C            | Enterprise Applications   | 2019–2026 |
| 28  | Blume Ventures              | 279      | 68                      | 143         | $5.0B                          | $7.0M          | Series A            | Enterprise Applications   | 2019–2026 |
| 29  | 8Vc                         | 271      | 72                      | 182         | $20.7B                         | $30.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 30  | Citi Ventures               | 271      | 66                      | 202         | $18.7B                         | $44.0M         | Series B            | Fintech                   | 2019–2026 |
| 31  | Venture Catalysts           | 269      | 127                     | 179         | $694.6M                        | $1.5M          | Pre-Series A        | Fintech                   | 2019–2026 |
| 32  | Intel Capital               | 262      | 108                     | 178         | $17.8B                         | $32.0M         | Series B            | Enterprise Infrastructure | 2019–2026 |
| 33  | Kleiner Perkins             | 251      | 71                      | 154         | $19.7B                         | $51.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 34  | Inflection Point Ventures   | 250      | 185                     | 192         | $326.6M                        | $812.5K        | Pre-Series A        | Consumer                  | 2020–2026 |
| 35  | Greycroft                   | 248      | 81                      | 176         | $10.9B                         | $20.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 36  | Antler                      | 243      | 105                     | 204         | $1.2B                          | $1.9M          | Pre-seed            | Fintech                   | 2019–2026 |
| 37  | Speedinvest                 | 243      | 75                      | 160         | $5.1B                          | $8.6M          | Seed                | Fintech                   | 2019–2026 |
| 38  | Blackrock                   | 241      | 80                      | 171         | $49.0B                         | $125.5M        | Series C            | Fintech                   | 2019–2026 |
| 39  | Tencent                     | 239      | 82                      | 152         | $33.6B                         | $103.0M        | Series B            | Fintech                   | 2019–2026 |
| 40  | Spark Capital               | 231      | 79                      | 146         | $20.7B                         | $46.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 41  | Silicon Valley Bank         | 226      | 78                      | 189         | $13.2B                         | $31.0M         | Debt                | Enterprise Applications   | 2019–2026 |
| 42  | Menlo Ventures              | 226      | 74                      | 144         | $24.8B                         | $45.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 43  | Lux Capital                 | 226      | 52                      | 140         | $20.0B                         | $37.0M         | Series A            | High Tech                 | 2019–2026 |
| 44  | Nexus Venture Partners      | 220      | 71                      | 120         | $8.9B                          | $15.0M         | Series A            | Enterprise Applications   | 2019–2026 |
| 45  | General Atlantic            | 217      | 122                     | 140         | $31.9B                         | $115.5M        | Series C            | Enterprise Applications   | 2019–2026 |
| 46  | Seedcamp                    | 216      | 25                      | 145         | $3.6B                          | $5.4M          | Seed                | Enterprise Applications   | 2019–2026 |
| 47  | Battery Ventures            | 212      | 79                      | 148         | $16.1B                         | $48.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 48  | Better Capital              | 209      | 36                      | 154         | $1.3B                          | $3.0M          | Seed                | Fintech                   | 2019–2026 |
| 49  | Nea                         | 205      | 74                      | 155         | $15.4B                         | $43.0M         | Series B            | Enterprise Applications   | 2019–2026 |
| 50  | Thrive Capital              | 205      | 59                      | 109         | $29.2B                         | $75.0M         | Series B            | Fintech                   | 2019–2026 |

### Largest disclosed rounds (top 50)

| #   | Company               | Stage       | Date       | Amount   | Lead investor                                | Investors   | Sector                               | Location                     |
|:----|:----------------------|:------------|:-----------|:---------|:---------------------------------------------|:------------|:-------------------------------------|:-----------------------------|
| 1   | Anthropic             | Series G    | 2026-03-24 | $5.0B    | Amazon                                       | 45          | High Tech                            | San Francisco, United States |
| 2   | Anthropic             | Series F    | 2025-08-23 | $3.8B    | Lightspeed Venture Partners                  | 22          | High Tech                            | San Francisco, United States |
| 3   | Gojek                 | Series F    | 2020-02-24 | $2.5B    | Softbank                                     | 1           | Consumer                             | Jakarta, Indonesia           |
| 4   | Anduril               | Series G    | 2025-06-05 | $2.5B    | Founders Fund                                | 1           | High Tech                            | Costa Mesa, United States    |
| 5   | Anysphere             | Series D    | 2025-11-14 | $2.3B    | Accel                                        | 4           | High Tech                            | San Francisco, United States |
| 6   | Verkor                | Series C    | 2023-12-28 | $2.2B    |                                              | 0           | Auto                                 | Grenoble, France             |
| 7   | Mistral AI            | Series C    | 2025-08-04 | $2.2B    | Asml                                         | 19          | High Tech                            | Paris, France                |
| 8   | OpenAI                | Growth / PE | 2026-04-06 | $2.0B    | Robinhood Ventures Fund I                    | 36          | High Tech                            | San Francisco, United States |
| 9   | xAI                   | Series E    | 2026-01-05 | $2.0B    | Tesla                                        | 17          | High Tech                            | Memphis, United States       |
| 10  | Nscale                | Series C    | 2026-02-26 | $2.0B    | Nvidia                                       | 11          | Enterprise Infrastructure            | London, United Kingdom       |
| 11  | Nscale                | Series C    | 2023-06-22 | $2.0B    | 8090 Industries                              | 6           | Enterprise Infrastructure            | London, United Kingdom       |
| 12  | Saronic               | Series D    | 2026-04-03 | $1.8B    | Kleiner Perkins                              | 6           | Aerospace, Maritime and Defense Tech | Austin, United States        |
| 13  | Databricks            | Series H    | 2021-08-19 | $1.6B    | Morgan Stanley                               | 38          | Enterprise Infrastructure            | San Francisco, United States |
| 14  | Zuoyebang             | Series E    | 2020-12-27 | $1.6B    | Alibaba Group                                | 9           | Edtech                               | Beijing, China               |
| 15  | Anduril               | Series F    | 2024-08-07 | $1.5B    | Founders Fund                                | 13          | High Tech                            | Costa Mesa, United States    |
| 16  | Lambda Labs           | Series E    | 2025-11-18 | $1.5B    | TWG Global                                   | 5           | High Tech                            | San Jose, United States      |
| 17  | Anduril               | Series E    | 2022-12-01 | $1.5B    | Valor Equity Partners                        | 18          | High Tech                            | Irvine, United States        |
| 18  | Grab                  | Series H    | 2019-03-05 | $1.5B    | Softbank Vision Fund                         | 14          | Consumer                             | Singapore, United States     |
| 19  | Sierra Space          | Growth / PE | 2022-01-18 | $1.4B    |                                              | 0           | Aerospace, Maritime and Defense Tech | Louisville, United States    |
| 20  | Crusoe                | Series E    | 2025-04-29 | $1.4B    | Mubadala Capital                             | 7           | High Tech                            | Denver, United States        |
| 21  | Crusoe Energy Systems | Series E    | 2025-10-25 | $1.4B    | Valor Equity Partners                        | 5           | Enterprise Infrastructure            | Denver, United States        |
| 22  | Lacework              | Series D    | 2021-11-17 | $1.3B    | Sutter Hill Ventures                         | 15          | Enterprise Infrastructure            | San Jose, United States      |
| 23  | Cinch                 | Growth / PE | 2021-05-20 | $1.3B    | Constellation Automotive Group               | 7           | Consumer                             | Farnham, United Kingdom      |
| 24  | Yuanfudao             | Series G    | 2020-12-24 | $1.2B    | Yunfeng Capital                              | 2           | Edtech                               | Beijing, China               |
| 25  | Devoted Health        | Series D    | 2021-10-08 | $1.2B    |                                              | 0           | Financial Services                   | Waltham, United States       |
| 26  | Sitecore              | Growth / PE | 2021-01-19 | $1.2B    |                                              | 0           | Enterprise Applications              | San Francisco, United States |
| 27  | Wayve                 | Series D    | 2026-02-24 | $1.2B    | Microsoft                                    | 16          | Auto Tech                            | London, United Kingdom       |
| 28  | Cerebras Systems      | Series G    | 2025-09-29 | $1.1B    | Fidelity Management & Research Company       | 11          | Semiconductors                       | Sunnyvale, United States     |
| 29  | CoreWeave             | Series C    | 2024-03-25 | $1.1B    | Nvidia                                       | 7           | High Tech                            | Roseland, United States      |
| 30  | Neura Robotics        | Growth / PE | 2026-03-04 | $1.1B    | Tether Holdings                              | 9           | Enterprise Applications              | Metzingen, Germany           |
| 31  | EXUS                  | Growth / PE | 2023-10-04 | $1.1B    | Partners Group                               | 1           | Fintech                              | London, United Kingdom       |
| 32  | Thrasio               | Series C    | 2021-03-02 | $1.0B    | Oaktree                                      | 6           | Retail                               | Walpole, United States       |
| 33  | Kalshi                | Series E    | 2025-12-02 | $1.0B    | Paradigm                                     | 10          | Fintech                              | New York, United States      |
| 34  | Scale Ai              | Series F    | 2024-05-20 | $1.0B    | Amazon                                       | 27          | Business Services                    | San Francisco, Canada        |
| 35  | VAST Data             | Series F    | 2026-03-11 | $1.0B    | Nvidia                                       | 7           | Enterprise Infrastructure            | New York, United States      |
| 36  | Thrasio               | Series D    | 2021-09-14 | $1.0B    | Upper90                                      | 8           | Retail                               | Boston, United States        |
| 37  | SHEIN                 | Series F    | 2023-01-17 | $1.0B    | Mubadala                                     | 3           | Consumer                             | Nanjing, Singapore           |
| 38  | Yuanfudao             | Series G    | 2020-03-31 | $1.0B    | Hillhouse Capital                            | 4           | Edtech                               | Beijing, China               |
| 39  | Nxtra                 | Strategic   | 2026-03-30 | $1.0B    | Alpha Wave Global                            | 5           | Enterprise Infrastructure            | New Delhi, India             |
| 40  | Securonix             | Growth / PE | 2023-01-17 | $1.0B    | Vista Equity Partners                        | 3           | Enterprise Infrastructure            | San Mateo, United States     |
| 41  | Checkout.com          | Series D    | 2022-01-12 | $1.0B    | Altimeter                                    | 8           | Fintech                              | London, United Kingdom       |
| 42  | Redwood Materials     | Series D    | 2023-08-28 | $1.0B    | Goldman Sachs Asset Management               | 12          | Environment Tech                     | Carson City, United States   |
| 43  | Databricks            | Series G    | 2021-01-31 | $1.0B    | Canada Pension Plan Investment Board         | 35          | Enterprise Infrastructure            | San Francisco, United States |
| 44  | Paytm                 | Series G    | 2019-10-14 | $1.0B    | Ant Financial                                | 13          | Fintech                              | Mumbai, India                |
| 45  | Grammarly             | Growth / PE | 2025-05-29 | $1.0B    | General Catalyst’s Customer Value Fund (CVF) | 3           | High Tech                            | San Francisco, United States |
| 46  | Celonis               | Series D    | 2021-06-01 | $1.0B    | Durable Capital Partners                     | 7           | Enterprise Applications              | London, Germany              |
| 47  | Flipkart              | Series F    | 2023-12-20 | $1.0B    | Walmart                                      | 7           | Retail                               | Bengaluru, India             |
| 48  | PsiQuantum            | Series E    | 2025-09-10 | $1.0B    | Blackrock                                    | 19          | Semiconductors                       | Palo Alto, United States     |
| 49  | Gopuff                | Series H    | 2021-07-21 | $1.0B    | Guggenheim Investments                       | 8           | Food and Agriculture Tech            | Philadelphia, United States  |
| 50  | Figure                | Series C    | 2025-09-16 | $1.0B    | Parkway Venture Capital                      | 11          | High Tech                            | San Jose, United States      |

### Most funded companies (top 50)

Sum of disclosed round amounts, full data. Amounts that failed the source-sentence check are excluded, so totals for the very largest companies are understated.

| #   | Company                      | Disclosed total   | Rounds   | Latest stage     | Latest round   | Sector                               | Location                         |
|:----|:-----------------------------|:------------------|:---------|:-----------------|:---------------|:-------------------------------------|:---------------------------------|
| 1   | Anthropic                    | $10.8B            | 16       | Series H         | 2026-04        | High Tech                            | San Francisco, United States     |
| 2   | Anduril                      | $6.5B             | 8        | Series G         | 2026-02        | High Tech                            | Irvine, United States            |
| 3   | Nscale                       | $4.3B             | 6        | Series C         | 2026-02        | Enterprise Infrastructure            | London, United Kingdom           |
| 4   | Databricks                   | $4.1B             | 10       | Debt             | 2026-02        | Enterprise Infrastructure            | San Francisco, United States     |
| 5   | Gojek                        | $4.0B             | 7        | Strategic        | 2021-05        | Consumer                             | Jakarta, Indonesia               |
| 6   | Anysphere                    | $3.3B             | 7        | Growth / PE      | 2025-12        | High Tech                            | San Francisco, United States     |
| 7   | Lambda Labs                  | $3.3B             | 6        | Series E         | 2026-03        | High Tech                            | San Francisco, United States     |
| 8   | Flipkart                     | $3.2B             | 18       | Growth / PE      | 2025-04        | Retail                               | Bengaluru, India                 |
| 9   | Ramp                         | $3.0B             | 14       | Growth / PE      | 2025-11        | Fintech                              | Warsaw, Poland                   |
| 10  | Thrasio                      | $3.0B             | 8        | Series D         | 2024-02        | Retail                               | New York, United States          |
| 11  | Grab                         | $2.9B             | 6        | Debt             | 2021-10        | Consumer                             | Houston, United States           |
| 12  | OpenAI                       | $2.7B             | 21       | Growth / PE      | 2026-04        | High Tech                            | San Francisco, United States     |
| 13  | Rippling                     | $2.7B             | 9        | Series G         | 2025-07        | Enterprise Applications              | San Francisco, United States     |
| 14  | Redwood Materials            | $2.6B             | 7        | Series E         | 2026-01        | Environment Tech                     | Carson City, United States       |
| 15  | Revolut                      | $2.5B             | 10       | Crowdfunding     | 2025-09        | Fintech                              | London, United Kingdom           |
| 16  | Verkor                       | $2.5B             | 5        | Series C         | 2024-12        | Auto                                 | Grenoble, France                 |
| 17  | Saronic                      | $2.5B             | 4        | Series D         | 2026-04        | Aerospace, Maritime and Defense Tech | Austin, United States            |
| 18  | Getir                        | $2.5B             | 7        | Series E         | 2024-06        | Food and Agriculture Tech            | Istanbul, Turkey                 |
| 19  | Lenskart                     | $2.5B             | 16       | Growth / PE      | 2025-07        | Consumer                             | New Delhi, India                 |
| 20  | Shield AI                    | $2.5B             | 11       | Series G         | 2026-03        | High Tech                            | San Diego, United States         |
| 21  | N26                          | $2.5B             | 8        | Series E         | 2025-06        | Fintech                              | Frankfurt, Germany               |
| 22  | xAI                          | $2.4B             | 12       | Series E         | 2026-01        | High Tech                            | Palo Alto, United States         |
| 23  | Lightsource BP               | $2.4B             | 10       | Debt             | 2025-10        |                                      | Holborn, United Kingdom          |
| 24  | Nubank                       | $2.4B             | 8        | Series G         | 2021-08        | Fintech                              | São Paulo, Brazil                |
| 25  | Zepto                        | $2.4B             | 11       | Growth / PE      | 2025-10        | Fintech                              | Bengaluru, Australia             |
| 26  | Ola Electric                 | $2.4B             | 16       | Debt             | 2024-07        | Energy Tech                          | Nagpur, India                    |
| 27  | Zuoyebang                    | $2.4B             | 3        | Series E         | 2020-12        | Edtech                               | Beijing, China                   |
| 28  | Rivian                       | $2.4B             | 9        | Series B         | 2021-07        | Energy Tech                          | Plymouth Township, United States |
| 29  | Tenstorrent                  | $2.3B             | 8        | Series D         | 2025-11        | High Tech                            | Toronto, Canada                  |
| 30  | Bolt                         | $2.3B             | 14       | Series F         | 2024-11        | High Tech                            | Tallinn, India                   |
| 31  | Crusoe Energy Systems        | $2.3B             | 10       | Series E         | 2026-03        | Enterprise Infrastructure            | Denver, United States            |
| 32  | Airwallex                    | $2.3B             | 13       | Series G         | 2025-12        | Fintech                              | Melbourne, United States         |
| 33  | Sierra Space                 | $2.3B             | 4        | Series C         | 2026-03        | Aerospace, Maritime and Defense Tech | Louisville, United States        |
| 34  | Yuanfudao                    | $2.2B             | 3        | Series G         | 2020-12        | Edtech                               | Beijing, China                   |
| 35  | Wefox                        | $2.2B             | 12       | Convertible note | 2025-07        | Fintech                              | Berlin, Switzerland              |
| 36  | Swiggy                       | $2.2B             | 13       | Series D         | 2024-09        | Food and Agriculture Tech            | Bengaluru, India                 |
| 37  | Cohere                       | $2.2B             | 12       | Series E         | 2026-04        | Telecom                              | Toronto, United States           |
| 38  | Commercial Credit Group Inc. | $2.2B             | 5        | Undisclosed      | 2025-03        | Financial Services                   | Charlotte, United States         |
| 39  | Mistral AI                   | $2.2B             | 7        | Debt             | 2026-03        | High Tech                            | Paris, France                    |
| 40  | Udaan                        | $2.1B             | 16       | Series G         | 2025-06        | Retail                               | Bengaluru, India                 |
| 41  | PharmEasy                    | $2.1B             | 12       | Debt             | 2025-09        | Healthtech                           | Mumbai, India                    |
| 42  | Meesho                       | $2.1B             | 12       | Growth / PE      | 2025-10        | Retail                               | Bengaluru, India                 |
| 43  | Celonis                      | $2.1B             | 5        | Series D         | 2022-10        | Enterprise Applications              | Munich, Germany                  |
| 44  | Securonix                    | $2.0B             | 4        | Growth / PE      | 2023-01        | Enterprise Infrastructure            | San Mateo, United States         |
| 45  | Cyera                        | $2.0B             | 8        | Series F         | 2026-06        | Enterprise Infrastructure            | Tel Aviv, Israel                 |
| 46  | Wayve                        | $2.0B             | 7        | Series D         | 2026-04        | Auto Tech                            | Cambridge, United Kingdom        |
| 47  | Picnic                       | $2.0B             | 8        | Series D         | 2025-11        | Enterprise Applications              | London, United Kingdom           |
| 48  | Crusoe                       | $2.0B             | 2        | Series E         | 2025-04        | High Tech                            | San Francisco, United States     |
| 49  | OYO                          | $2.0B             | 18       | Series G         | 2025-01        | Consumer                             | Gurugram, India                  |
| 50  | Stripe                       | $2.0B             | 9        | Seed             | 2026-03        | Fintech                              | San Francisco, United States     |

### Top 30 countries by disclosed funding

| #   | Country              | Rounds   | Companies   | Disclosed $   | Share of $   | Median round   | Top sector                | Rounds 2024   | Rounds 2025   |
|:----|:---------------------|:---------|:------------|:--------------|:-------------|:---------------|:--------------------------|:--------------|:--------------|
| 1   | United States        | 31,418   | 18,376      | $1.2T         | 50.2%        | $14.0M         | Enterprise Applications   | 4314          | 3272          |
| 2   | India                | 10,709   | 5,048       | $211.6B       | 9.2%         | $4.0M          | Consumer                  | 1527          | 1132          |
| 3   | United Kingdom       | 7,383    | 4,458       | $184.0B       | 8.0%         | $6.0M          | Fintech                   | 1062          | 805           |
| 4   | Canada               | 3,113    | 1,845       | $71.4B        | 3.1%         | $6.0M          | Enterprise Applications   | 446           | 316           |
| 5   | Germany              | 2,535    | 1,549       | $69.5B        | 3.0%         | $10.2M         | Enterprise Applications   | 399           | 312           |
| 6   | China                | 1,162    | 796         | $64.5B        | 2.8%         | $32.4M         | High Tech                 | 101           | 87            |
| 7   | France               | 2,291    | 1,552       | $64.4B        | 2.8%         | $8.6M          | Enterprise Applications   | 354           | 262           |
| 8   | Israel               | 1,481    | 844         | $41.4B        | 1.8%         | $15.0M         | Enterprise Infrastructure | 158           | 126           |
| 9   | Singapore            | 1,409    | 854         | $39.1B        | 1.7%         | $7.4M          | Fintech                   | 194           | 124           |
| 10  | Australia            | 1,705    | 1,045       | $37.7B        | 1.6%         | $6.0M          | Enterprise Applications   | 263           | 188           |
| 11  | Netherlands          | 1,106    | 734         | $24.7B        | 1.1%         | $5.6M          | Enterprise Applications   | 181           | 148           |
| 12  | Brazil               | 1,218    | 803         | $23.9B        | 1.0%         | $9.0M          | Fintech                   | 167           | 118           |
| 13  | Spain                | 1,302    | 856         | $23.6B        | 1.0%         | $3.2M          | Consumer                  | 179           | 144           |
| 14  | Switzerland          | 886      | 555         | $23.1B        | 1.0%         | $9.3M          | Fintech                   | 143           | 130           |
| 15  | Sweden               | 728      | 442         | $18.0B        | 0.8%         | $7.0M          | Fintech                   | 132           | 85            |
| 16  | Indonesia            | 504      | 282         | $16.2B        | 0.7%         | $10.0M         | Fintech                   | 44            | 26            |
| 17  | Ireland              | 611      | 371         | $15.4B        | 0.7%         | $5.6M          | Life Sciences             | 76            | 55            |
| 18  | Mexico               | 359      | 191         | $14.4B        | 0.6%         | $12.0M         | Fintech                   | 47            | 34            |
| 19  | United Arab Emirates | 593      | 347         | $13.1B        | 0.6%         | $5.1M          | Fintech                   | 96            | 69            |
| 20  | Finland              | 446      | 282         | $11.4B        | 0.5%         | $5.9M          | High Tech                 | 93            | 61            |
| 21  | South Korea          | 417      | 293         | $10.4B        | 0.5%         | $10.9M         | Consumer                  | 78            | 44            |
| 22  | Italy                | 495      | 329         | $10.3B        | 0.4%         | $6.3M          | Fintech                   | 119           | 100           |
| 23  | Denmark              | 438      | 259         | $8.7B         | 0.4%         | $7.0M          | Enterprise Applications   | 79            | 50            |
| 24  | Japan                | 399      | 267         | $8.0B         | 0.3%         | $10.0M         | High Tech                 | 76            | 73            |
| 25  | Nigeria              | 688      | 347         | $7.9B         | 0.3%         | $1.5M          | Fintech                   | 77            | 56            |
| 26  | South Africa         | 430      | 255         | $7.5B         | 0.3%         | $2.5M          | Fintech                   | 55            | 41            |
| 27  | Belgium              | 355      | 240         | $7.3B         | 0.3%         | $6.7M          | Enterprise Applications   | 58            | 43            |
| 28  | Saudi Arabia         | 320      | 182         | $6.2B         | 0.3%         | $5.0M          | Fintech                   | 42            | 47            |
| 29  | Turkey               | 250      | 189         | $5.9B         | 0.3%         | $2.5M          | Retail                    | 42            | 18            |
| 30  | Poland               | 224      | 144         | $5.9B         | 0.3%         | $3.8M          | Enterprise Applications   | 64            | 28            |

### Sectors (top 40 by rounds)

| Sector                               | Rounds   | Companies   | Disclosed $   | Median round   | 2024 → 2025 rounds   | Most funded companies                                              |
|:-------------------------------------|:---------|:------------|:--------------|:---------------|:---------------------|:-------------------------------------------------------------------|
| Fintech                              | 10,481   | 5,345       | $332.3B       | $10.0M         | 1,345 → 1,118        | Ramp, Revolut, N26                                                 |
| Enterprise Applications              | 10,154   | 6,058       | $230.3B       | $7.0M          | 1,316 → 1,027        | Rippling, Celonis, Picnic                                          |
| Consumer                             | 6,387    | 3,520       | $161.5B       | $6.0M          | 783 → 546            | Gojek, Grab, Lenskart                                              |
| High Tech                            | 5,602    | 3,124       | $180.9B       | $10.0M         | 907 → 665            | Anthropic, Anduril, Anysphere                                      |
| Healthtech                           | 5,226    | 3,114       | $117.8B       | $8.0M          | 742 → 506            | PharmEasy, Zipline, API Holdings                                   |
| Food and Agriculture Tech            | 4,190    | 2,141       | $92.9B        | $6.0M          | 518 → 353            | Getir, Swiggy, Rappi                                               |
| Life Sciences                        | 4,138    | 2,735       | $145.7B       | $18.9M         | 583 → 463            | ElevateBio, Neuralink, CMR Surgical                                |
| Retail                               | 4,087    | 2,282       | $109.6B       | $6.9M          | 443 → 335            | Flipkart, Thrasio, Udaan                                           |
| Enterprise Infrastructure            | 3,835    | 2,103       | $164.2B       | $15.0M         | 542 → 429            | Nscale, Databricks, Crusoe Energy Systems                          |
| Business Services                    | 2,838    | 2,067       | $56.5B        | $6.0M          | 460 → 398            | Scale Ai, Polestar, Rain                                           |
| Energy Tech                          | 2,653    | 1,418       | $93.3B        | $11.9M         | 495 → 331            | Ola Electric, Rivian, XPENG                                        |
| Food and Agriculture                 | 1,853    | 1,198       | $27.7B        | $5.0M          | 290 → 205            | Impossible Foods, Sweetgreen, BrewDog                              |
| Healthcare                           | 1,849    | 1,308       | $42.6B        | $10.0M         | 323 → 223            | Cityblock, Island, IVC Evidensia                                   |
| Edtech                               | 1,612    | 980         | $31.2B        | $3.5M          | 191 → 90             | Zuoyebang, Yuanfudao, BYJU'S                                       |
| Energy                               | 1,517    | 931         | $92.2B        | $25.0M         | 304 → 245            | Ayana, Helion, Doral Renewables                                    |
| Real Estate and Construction Tech    | 1,476    | 896         | $26.9B        | $5.8M          | 227 → 165            | Chime, ICON, OfBusiness                                            |
| Financial Services                   | 1,208    | 763         | $51.4B        | $16.2M         | 211 → 128            | Commercial Credit Group Inc., Devoted Health, Hipgnosis Songs Fund |
| Environment Tech                     | 1,192    | 649         | $21.9B        | $6.0M          | 248 → 156            | Redwood Materials, Twelve, Infinium                                |
| Consumer Goods                       | 1,050    | 691         | $16.4B        | $5.0M          | 137 → 118            | Agel Enterprises, Skims, Lovable                                   |
| Media & Entertainment                | 889      | 586         | $22.4B        | $7.1M          | 118 → 91             | Canva, Polymarket, Insider                                         |
| Aerospace, Maritime and Defense Tech | 795      | 367         | $38.2B        | $14.0M         | 141 → 129            | Saronic, Sierra Space, Firefly Aerospace                           |
| Semiconductors                       | 698      | 421         | $23.6B        | $11.9M         | 120 → 93             | Cerebras Systems, PsiQuantum, Divergent Technologies               |
| Real Estate and Construction         | 564      | 425         | $16.2B        | $8.0M          | 101 → 60             | RMZ Corp, Eco Material Technologies, Tuhabi                        |
| Telecom                              | 532      | 336         | $24.6B        | $20.0M         | 82 → 68              | Cohere, OneWeb, Netomnia                                           |
| Environment                          | 428      | 309         | $10.0B        | $5.0M          | 76 → 59              | ReNew Solar Power Pvt. Ltd., Sedron Technologies, Chestnut         |
| Auto Tech                            | 410      | 200         | $19.1B        | $19.7M         | 57 → 33              | Wayve, Applied Intuition, Waabi                                    |
| AI-native                            | 387      | 142         | $20.1B        | $20.4M         | 63 → 50              | Nuro, AlphaSense, Pony.ai                                          |
| Gaming                               | 364      | 259         | $6.2B         | $6.2M          | 55 → 31              | Discord, MPL, Spirit AI                                            |
| Investment Industry                  | 361      | 282         | $14.9B        | $12.0M         | 64 → 56              | Africa Finance Corporation, Scalable Capital, Binghatti            |
| Industrial Goods and Manufacturing   | 350      | 261         | $5.7B         | $5.4M          | 76 → 45              | Infinitum, Harry's, Sidersa                                        |
| Auto                                 | 331      | 194         | $14.7B        | $12.6M         | 47 → 31              | Verkor, Lendbuzz, Vroom                                            |
| Travel and Hospitality Tech          | 280      | 184         | $5.0B         | $5.0M          | 45 → 32              | Hostaway, Mews, IBS Software                                       |
| Travel and Hospitality               | 250      | 171         | $8.8B         | $14.5M         | 38 → 20              | GoAir, Akasa Air, Weststar Aviation                                |
| Mobile                               | 245      | 165         | $4.2B         | $5.2M          | 36 → 36              | Scopely, Dream Games, Tilting Point                                |
| Education                            | 223      | 168         | $3.5B         | $4.3M          | 36 → 27              | Aakash Educational Services, Saga, K12 Techno Services             |
| Mining                               | 220      | 146         | $6.0B         | $6.0M          | 37 → 31              | Ironbark Zinc, Posco Argentina, Cornish Lithium                    |
| Transportation and Logistics         | 213      | 160         | $5.7B         | $10.0M         | 33 → 22              | Emergent Cold LatAm, CLI, SmartStop Self Storage                   |
| Chemicals and Materials              | 197      | 132         | $4.5B         | $6.0M          | 40 → 25              | H2 Green Steel, Amyris, Tees Valley Lithium                        |
| Chemicals and Materials Tech         | 182      | 112         | $3.3B         | $5.0M          | 42 → 21              | Boston Metal, Solugen, PASQAL                                      |
| Aerospace, Maritime and Defense      | 131      | 86          | $5.5B         | $17.9M         | 27 → 32              | Mach Industries, SkyRyse, Castelion                                |

## Method

1. **Extraction.** Radar's pipeline reads each funding article and extracts structured fields from it, including the source sentence.
2. **Back-fill days removed.** Two days on which archived articles were loaded with the load date as their publication date (2024-04-22 and 2025-02-13) are excluded, because those rounds carry no reliable date.
3. **Scope.** Venture-style instruments only (pre-seed to Series H, growth/PE, bridge, convertible notes, venture debt, grants, strategic). IPOs, QIPs, private placements, rights issues, bank loans, bonds and acquisitions are dropped. Companies founded in 2000 or later; rounds after a company's IPO and group subsidiaries of large conglomerates are excluded.
4. **Deduplication.** Reports about the same company and stage within 45 days are one round. A round repeating an earlier amount within 180 days is dropped, as are lettered stages below one already announced (recaps). One round filed under two domains of the same company is merged.
5. **Amount check.** Each amount is compared with the money figures parsed from its source sentence (tolerance 0.6–1.7×). `verified` matched; `unchecked` had no parseable figure; `failed_check` is blank because it did not match, exceeded a stage ceiling, or was a $500M+ figure reported by one article only; `not_disclosed` had no amount.
6. **Currency.** US dollars, converted at the time of extraction and rounded to three significant figures.
7. **News columns.** The excerpt is the earliest reporting sentence that does not name a data provider. Source and URL come from that article when it can be retrieved.

8. **Sample.** Each company key is ranked by `sha1(key)`. Keys are taken in rank order until the file holds max(25%, 5,000) rows (capped at 100,000).

9. **Profile links.** Links are built from Fliar's company index and checked against it. A row whose company has no public profile has an empty link.

## Columns

| Column              | Description                                                              |
|:--------------------|:-------------------------------------------------------------------------|
| `round_id`          | stable 12-character ID of the round                                      |
| `announced_date`    | date of the earliest report (YYYY-MM-DD)                                 |
| `year`              | announcement year                                                        |
| `company_name`      | company name                                                             |
| `company_domain`    | company website domain (the join key for the API)                        |
| `country`           | company country                                                          |
| `city`              | company city (normalised)                                                |
| `sector`            | Fliar sector label                                                       |
| `founded_year`      | year founded                                                             |
| `stage`             | normalised stage (Pre-seed … Series H, Growth / PE, Debt, Undisclosed …) |
| `amount_usd`        | round amount in US$ (blank when not disclosed or it failed the check)    |
| `amount_status`     | verified / unchecked / failed_check / not_disclosed                      |
| `lead_investor`     | lead investor (organisations only), or the first named one               |
| `investor_count`    | number of distinct investors named (the full list is in the API)         |
| `news_mentions`     | articles that reported the round                                         |
| `news_source`       | publisher of the article the round was read from (website domain)        |
| `news_url`          | link to that article                                                     |
| `news_excerpt`      | the sentence the round was extracted from (up to 300 characters)         |
| `fliar_profile_url` | full company profile on Fliar (financials, funding, team, news)          |

**Available only through the [Radar API](https://github.com/fliarbi/radar-api-mcp):** full investor list (names and websites of every participant); post-money valuation where reported; use of funds; every article that reported the round; the rest of the companies; rounds announced after June 2026 and the monthly refresh; company profile, financials, team and contacts.

## Limitations

- Derived from news: rounds that were never reported are missing, and coverage is stronger for larger and English-reported deals.
- Amounts are as reported; fixed-rate conversion to US dollars makes local-currency rounds drift slightly over time.
- Stage labels mean different things in different markets.
- 2026 covers January to June only.
- Sector labels come from a company classifier, so some companies are mislabelled.
- `news_source` and `news_url` are blank when the article could not be retrieved at release time (about 40% of rows).

## Citation

Fliar Research (2026). *Global Startup Funding Rounds 2019–2026* (sample release). Data: Radar API, https://github.com/fliarbi/radar-api-mcp. Licence CC BY-NC 4.0.
