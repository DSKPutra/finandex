# Global E-Commerce Giants 2015–2026

**A multi-source, ML-ready dataset of 43 public e-commerce, online-marketplace, and commerce-fintech companies across 13 countries — pre-joined, documented, and ready to model.**

> Most public e-commerce datasets on Kaggle are either (a) single-company transaction logs, or (b) US-centric stock price dumps with no fundamentals or context.
> This dataset stitches together stock prices, annual financials, company profiles, and country-level macro indicators into a single coherent panel, with a focus on **cross-region** coverage that includes 11 Indian listings rarely surfaced together.

## What's in the box

| File                       | Rows    | Description |
|---------------------------|---------|-------------|
| `companies.csv`           | 43      | Master table — one row per company, with ticker, exchange, country, segment, founders, HQ, employees, Wikipedia/Wikidata links. |
| `prices_daily.csv`        | 85,763  | Daily OHLCV in reporting currency, 2015-01-01 → 2026-05-13. Adjusted close included. |
| `financials_annual.csv`   | 175     | Annual income statement, balance sheet, and cash-flow line items. FY 2021–2026 (yfinance window). |
| `macro_indicators.csv`    | 1,416   | World Bank panel for 13 countries × 8 indicators × ~16 years. Internet penetration, GDP, FDI, etc. |
| `company_metrics.csv`     | 43      | **Derived** per-company features: CAGR, volatility, drawdown, 1y/90d return, margins, revenue CAGR. |
| `ecommerce_index.csv`     | 2,931   | **Derived** daily equal-weighted "Global E-Commerce Index" rebased to 100 on 2015-01-05. |
| `data_dictionary.csv`     | 83      | Every (table, column) pair with dtype and description. |

## Why this dataset

- **Cross-region by design.** US, Greater China, Korea, Japan, Singapore, Indonesia, Germany, UK, Poland, Argentina, Brazil, Canada, **and 11 Indian listings** (Nykaa, Zomato/Eternal, Paytm, IndiaMART, Info Edge, Honasa, Delhivery, FirstCry, CarTrade, ixigo, EaseMyTrip). Most peer datasets are US-only.
- **Pre-joined.** The companies / prices / financials / macro tables all share `company_id` and `country_code` keys. The included `company_metrics.csv` is a one-row-per-firm table that's directly clusterable / regressable.
- **Engineered features included.** CAGR, annualized volatility, max drawdown, all-time high date, 1-year / 90-day momentum, latest fiscal-year margins, revenue CAGR — so beginners can jump straight to modeling.
- **A ready-made benchmark.** The equal-weighted `ecommerce_index.csv` lets you compare any individual company against the sector composite from day one.

## Suggested tasks

1. **Sector momentum forecasting.** Predict next-month return of the equal-weighted index from past returns + macro signals.
2. **Cross-region peer clustering.** Cluster companies in `company_metrics.csv` and see whether segment/region cleave naturally apart.
3. **Margin vs. multiple analysis.** Relate operating margin / revenue CAGR to cumulative stock return.
4. **India-vs-world tilt.** Compare Indian e-commerce listings (post-IPO, mostly 2021+) to mature US/China peers on growth, drawdown, and break-even.
5. **Macro coupling.** Does country-level internet-user penetration explain in-country company returns or revenue growth?
6. **Survival / volatility prediction.** Use early-life price action + fundamentals to flag firms entering large drawdowns.

A starter notebook (`notebooks/starter.ipynb`) walks through EDA, the index construction, peer clustering, and a baseline return-forecasting model.

## Schema (high level)

```
companies (43)
   │   company_id (PK), name, ticker, exchange, reporting_currency,
   │   country_code, region, segment, founded_date, headquarters,
   │   founders, industry, employees, wikidata_qid, wiki_*
   │
   ├──< prices_daily (85,763)
   │       company_id (FK), ticker, date, open, high, low, close, adj_close, volume
   │
   ├──< financials_annual (175)
   │       company_id (FK), ticker, fiscal_year,
   │       total_revenue, gross_profit, operating_income, net_income, ebitda,
   │       research_dev, total_assets, total_liabilities, cash_and_equivalents,
   │       total_equity, operating_cash_flow, capex, free_cash_flow
   │
   └──< company_metrics (43) — derived
           company_id (FK), trading_days, cagr, annualized_volatility, max_drawdown,
           all_time_high, return_90d, return_1y, net_margin, operating_margin,
           revenue_cagr, …

macro_indicators (1,416)
       country_code (joins to companies.country_code), year,
       indicator_id, indicator_name, value

ecommerce_index (2,931)
       date, constituents, daily_return, index_level
```

See `data/data_dictionary.csv` for full column-level docs.

## Important caveats — read before modeling

- **Multi-currency.** Prices and financials are in each company's **reporting currency** (column `companies.reporting_currency`). `INR`, `JPY`, `IDR`, `CNY` (for HK-listed), and `USD` are all in here. For cross-firm financial comparisons, convert to a common currency yourself; for **returns**, use `adj_close` and pct-change, which is currency-agnostic.
- **Financial history is short.** `yfinance` exposes 4 fiscal years on average. Use `financials_annual.csv` for cross-section / panel work, not long-run time series.
- **Survivorship.** The 43-company list reflects firms still listed as of 2026-05-13. Notable absences include Boohoo (rebranded to Debenhams Group — kept) and About You (acquired by Zalando 2025 — dropped). No backfilling of delisted peers.
- **Some Wikidata fields are sparse.** Employee counts (`employees`) are present for ~14% of companies because the underlying Wikidata records vary.
- **Index methodology.** Equal-weighted, daily-rebalanced. Constituents are *all tickers that have a price that day*, with a minimum of 5 constituents required to publish a value. No survivor-bias correction.
- **Not investment advice.** Nothing here is a buy/sell recommendation.

## Data sources & license

| Source | Used for | License |
|---|---|---|
| [Yahoo Finance](https://finance.yahoo.com/) via [`yfinance`](https://github.com/ranaroussi/yfinance) | Prices, annual financials | Yahoo Finance Terms; redistribution is allowed for non-commercial / research uses |
| [Wikipedia REST API](https://en.wikipedia.org/api/rest_v1/) | Company summaries, thumbnails | CC BY-SA 4.0 |
| [Wikidata](https://www.wikidata.org/) | Founders, HQ, founding date, employees, website | CC0 |
| [World Bank Open Data](https://data.worldbank.org/) | Country macro indicators | CC BY 4.0 |

This compiled dataset is released under **CC BY 4.0** — share and adapt freely with attribution. The underlying source licenses (above) apply to their respective fields; please cite the originals if you redistribute.

## Reproducing the build

Everything here was built end-to-end from the public APIs above. The scripts in `scripts/` are idempotent and ordered:

```bash
pip install -r requirements.txt
python scripts/01_companies.py        # → data/companies.csv          (Wikipedia + Wikidata)
python scripts/02_prices.py           # → data/prices_daily.csv       (yfinance)
python scripts/03_financials.py       # → data/financials_annual.csv  (yfinance)
python scripts/04_macro.py            # → data/macro_indicators.csv   (World Bank)
python scripts/05_assemble.py         # → company_metrics + ecommerce_index + data_dictionary
```

## Changelog

- **v1 (2026-05-14)** — Initial release. 43 companies, 11.4 years of daily prices, FY 2021–2026 financials, 2010–2025 macro panel.

## Citation

If this dataset is useful in your work, please cite:

```
@misc{ecommerce_giants_2026,
  title  = {Global E-Commerce Giants 2015–2026: A Multi-Source ML Dataset},
  author = {Pratap, Param},
  year   = {2026},
  publisher = {Kaggle},
  howpublished = {\\url{https://www.kaggle.com/datasets/}}
}
```
