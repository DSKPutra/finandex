# VC Investor Directory 2026: 35k Startup Investors: findings, method and data card

*Fliar Research · released October 2026 · licence CC BY-NC 4.0*

**How this dataset was acquired.** Every row is aggregated from the [Radar API](https://github.com/fliarbi/radar-api-mcp), Fliar's company-data API and MCP server.
Radar reads business news continuously and extracts each startup funding announcement into structured fields: company, stage,
amount, date and every named investor. Those rounds are cleaned (repeated reports merged, recaps dropped, amounts checked against
the source sentence) and the investors are then aggregated here: one row per investor organisation, with its deal count, lead
count, stage mix, sectors and countries from January 2019 to June 2026. Individual angels and any name that reads as a person are
removed. The investor profile with the full portfolio is available through `POST /v1/investors/page`
([reference](https://github.com/fliarbi/radar-api-mcp/blob/main/docs/reference/get_investor_page.md)) or the `get_investor_page` MCP tool; `POST /v1/investors/search` finds investors by filters.

> **This file is a 25% sample: 8,827 of 35,310 investors.** It keeps every record for a fixed subset of investors.
> The subset is chosen by a hash, so it stays the same from one release to the next. The findings and tables below were computed
> on the **full** data. For the rest, the withheld fields and monthly updates, [get a Radar API key](https://fliarbi.com/radar-api/developer) ([docs](https://github.com/fliarbi/radar-api-mcp)).
> Each row's `fliar_profile_url` opens the company's full profile on Fliar.

## Key findings

1. **35,310 investor organisations joined 64,799 funding rounds between January 2019 and June 2026.** 16,168 of them (46%) appear in two or more rounds; 3,988 appear in ten or more.
2. **The ten most active investors joined 6,051 rounds** (9% of all rounds with a named organisation investor). Y Combinator leads with 1,090 rounds, followed by Tiger Global (897) and Accel (865).
3. **Venture firms are 69% of investors**, but the round sizes they join differ by type: the median round joined by a typical PE investor is $93.6M, against $8.6M for VC firms and $2.7M for accelerators.
4. **12,702 investors were active in 2022, the peak year.** In 2025, 9,038 were active and 2,577 made their first round in the data.
5. **Leading is concentrated.** Only 300 investors led 10 or more rounds. The most frequent leads were Y Combinator (116), Softbank (101), BGF (100).
6. **Where investors are based** (for the 16,930 with a known headquarters): United States 6,641, United Kingdom 1,270, India 1,228, China 596, Canada 563.

![Most active investors](figures/top_investors.png)

![Active and first-time investors by year](figures/active_by_year.png)

![Stage mix by investor type](figures/stage_mix_by_type.png)

### Most active investors worldwide (top 50)

Rounds joined, January 2019 to June 2026, full data. Stage mix is the share of staged rounds at seed, early (pre-A to B) and growth (C+).

| #   | Investor                    | Type        | HQ             | Rounds   | As lead   | Companies   | Seed / early / growth   | Median round   | Top sector                | Active    |
|:----|:----------------------------|:------------|:---------------|:---------|:----------|:------------|:------------------------|:---------------|:--------------------------|:----------|
| 1   | Y Combinator                | accelerator | United States  | 1,090    | 116       | 828         | 53% / 39% / 8%          | $6.2M          | Fintech                   | 2019–2026 |
| 2   | Tiger Global                | PE          | United States  | 897      | 95        | 559         | 5% / 43% / 51%          | $65.0M         | Fintech                   | 2019–2026 |
| 3   | Accel                       | VC          | United States  | 865      | 73        | 479         | 17% / 46% / 36%         | $28.0M         | Enterprise Applications   | 2019–2026 |
| 4   | Sequoia Capital             | VC          | United States  | 827      | 68        | 490         | 15% / 38% / 47%         | $45.0M         | Enterprise Applications   | 2019–2026 |
| 5   | Insight Partners            | PE          | United States  | 737      | 99        | 493         | 5% / 49% / 46%          | $50.0M         | Enterprise Applications   | 2019–2026 |
| 6   | Andreessen Horowitz         | VC          | United States  | 719      | 58        | 444         | 18% / 50% / 32%         | $40.0M         | High Tech                 | 2019–2026 |
| 7   | Lightspeed Venture Partners | VC          | United States  | 683      | 42        | 394         | 18% / 50% / 32%         | $39.5M         | Enterprise Infrastructure | 2019–2026 |
| 8   | Peak XV Partners            | VC          | India          | 506      | 69        | 316         | 23% / 51% / 26%         | $16.9M         | Fintech                   | 2019–2026 |
| 9   | Bessemer Venture Partners   | VC          | United States  | 486      | 25        | 304         | 13% / 47% / 39%         | $31.8M         | Enterprise Applications   | 2019–2026 |
| 10  | Khosla Ventures             | VC          | United States  | 433      | 25        | 281         | 20% / 52% / 29%         | $30.0M         | Fintech                   | 2019–2026 |
| 11  | Index Ventures              | VC          | United Kingdom | 421      | 10        | 243         | 19% / 48% / 34%         | $40.0M         | Enterprise Applications   | 2019–2026 |
| 12  | Coatue                      | PE          | United States  | 384      | 18        | 210         | 6% / 36% / 58%          | $110.0M        | Fintech                   | 2019–2026 |
| 13  | Techstars                   | accelerator | United States  | 369      | 32        | 322         | 72% / 26% / 2%          | $3.0M          | Enterprise Applications   | 2019–2026 |
| 14  | Goldman Sachs               | PE          | United States  | 362      | 63        | 268         | 5% / 28% / 67%          | $88.0M         | Fintech                   | 2019–2026 |
| 15  | Softbank                    | CVC         | Japan          | 357      | 101       | 239         | 7% / 27% / 65%          | $137.0M        | Consumer                  | 2019–2026 |
| 16  | Founders Fund               | VC          | United States  | 355      | 18        | 222         | 20% / 42% / 38%         | $40.0M         | Enterprise Applications   | 2019–2026 |
| 17  | Bpifrance                   | government  | France         | 354      | 17        | 301         | 26% / 51% / 23%         | $11.9M         | Enterprise Applications   | 2019–2026 |
| 18  | Global Founders Capital     | VC          | Germany        | 342      | 7         | 271         | 61% / 35% / 5%          | $6.8M          | Fintech                   | 2019–2026 |
| 19  | Salesforce Ventures         | CVC         | United States  | 340      | 21        | 232         | 9% / 42% / 49%          | $49.0M         | Enterprise Applications   | 2019–2026 |
| 20  | Gaingels                    | other       | United States  | 336      | 1         | 306         | 32% / 51% / 17%         | $15.0M         | Enterprise Applications   | 2019–2026 |
| 21  | Temasek                     | government  | Singapore      | 336      | 42        | 202         | 2% / 31% / 67%          | $100.0M        | Food and Agriculture Tech | 2019–2026 |
| 22  | Bain Capital Ventures       | VC          | United States  | 329      | 25        | 215         | 16% / 48% / 37%         | $32.0M         | Enterprise Applications   | 2019–2026 |
| 23  | FJ Labs                     | VC          | United States  | 307      | 1         | 260         | 35% / 60% / 5%          | $12.0M         | Fintech                   | 2019–2026 |
| 24  | Alumni Ventures             | VC          | United States  | 293      | 2         | 267         | 35% / 50% / 15%         | $13.8M         | High Tech                 | 2019–2026 |
| 25  | Norwest Venture Partners    | VC          | United States  | 286      | 26        | 177         | 7% / 37% / 57%          | $45.2M         | Enterprise Applications   | 2019–2026 |
| 26  | Blume Ventures              | VC          | India          | 279      | 33        | 143         | 23% / 60% / 17%         | $7.0M          | Enterprise Applications   | 2019–2026 |
| 27  | 8VC                         | VC          | United States  | 271      | 9         | 182         | 20% / 53% / 27%         | $30.0M         | Enterprise Applications   | 2019–2026 |
| 28  | Citi Ventures               | CVC         | United States  | 271      | 25        | 202         | 5% / 51% / 45%          | $43.5M         | Fintech                   | 2019–2026 |
| 29  | Venture Catalysts           | VC          | India          | 269      | 46        | 179         | 44% / 55% / 1%          | $1.5M          | Fintech                   | 2019–2026 |
| 30  | Intel Capital               | CVC         | United States  | 264      | 43        | 179         | 6% / 58% / 35%          | $30.0M         | Enterprise Infrastructure | 2019–2026 |
| 31  | Tencent                     | CVC         | China          | 262      | 46        | 164         | 5% / 40% / 54%          | $100.0M        | Fintech                   | 2019–2026 |
| 32  | Inflection Point Ventures   | VC          | –              | 256      | 95        | 196         | 43% / 57% / 0%          | $790.0K        | Consumer                  | 2019–2026 |
| 33  | Kleiner Perkins             | VC          | United States  | 254      | 9         | 157         | 14% / 42% / 44%         | $50.0M         | Enterprise Applications   | 2019–2026 |
| 34  | Greycroft                   | VC          | United States  | 248      | 9         | 176         | 24% / 56% / 20%         | $19.8M         | Enterprise Applications   | 2019–2026 |
| 35  | Blackrock                   | PE          | United States  | 245      | 30        | 175         | 1% / 23% / 76%          | $125.5M        | Fintech                   | 2019–2026 |
| 36  | Antler                      | accelerator | Singapore      | 244      | 73        | 205         | 83% / 17% / 0%          | $1.9M          | Fintech                   | 2019–2026 |
| 37  | Speedinvest                 | VC          | Austria        | 243      | 1         | 160         | 47% / 47% / 5%          | $8.5M          | Fintech                   | 2019–2026 |
| 38  | Matrix Partners             | VC          | United States  | 233      | 26        | 156         | 17% / 48% / 35%         | $16.9M         | Consumer                  | 2019–2026 |
| 39  | Spark Capital               | VC          | United States  | 231      | 8         | 146         | 10% / 48% / 42%         | $45.0M         | Enterprise Applications   | 2019–2026 |
| 40  | Lux Capital                 | VC          | United States  | 226      | 8         | 140         | 17% / 48% / 35%         | $38.5M         | High Tech                 | 2019–2026 |
| 41  | Menlo Ventures              | VC          | United States  | 226      | 4         | 144         | 10% / 52% / 37%         | $45.0M         | Enterprise Applications   | 2019–2026 |
| 42  | Silicon Valley Bank         | bank-debt   | United States  | 226      | 64        | 189         | 6% / 51% / 43%          | $31.0M         | Enterprise Applications   | 2019–2026 |
| 43  | Nexus Venture Partners      | VC          | United States  | 222      | 21        | 122         | 26% / 55% / 20%         | $13.5M         | Enterprise Applications   | 2019–2026 |
| 44  | General Atlantic            | PE          | United States  | 218      | 43        | 140         | 1% / 27% / 71%          | $115.5M        | Enterprise Applications   | 2019–2026 |
| 45  | Seedcamp                    | accelerator | United Kingdom | 216      | 1         | 145         | 64% / 34% / 2%          | $5.4M          | Enterprise Applications   | 2019–2026 |
| 46  | Battery Ventures            | VC          | United States  | 213      | 17        | 148         | 5% / 48% / 47%          | $46.0M         | Enterprise Applications   | 2019–2026 |
| 47  | Google                      | CVC         | United States  | 213      | 54        | 166         | 33% / 28% / 38%         | $27.8M         | High Tech                 | 2019–2026 |
| 48  | Better Capital              | VC          | Guernsey       | 209      | 8         | 154         | 68% / 29% / 3%          | $3.0M          | Fintech                   | 2019–2026 |
| 49  | Thrive Capital              | VC          | United States  | 207      | 14        | 111         | 13% / 40% / 47%         | $75.0M         | Fintech                   | 2019–2026 |
| 50  | NEA                         | VC          | United States  | 206      | 2         | 156         | 14% / 50% / 36%         | $42.0M         | Enterprise Applications   | 2019–2026 |

### Most active lead investors (top 50)

Ranked by rounds where a report named the investor as lead or it was the only investor named.

| #   | Investor                                  | Type        | HQ             | Rounds   | As lead   | Companies   | Seed / early / growth   | Median round   | Top sector                | Active    |
|:----|:------------------------------------------|:------------|:---------------|:---------|:----------|:------------|:------------------------|:---------------|:--------------------------|:----------|
| 1   | Y Combinator                              | accelerator | United States  | 1,090    | 116       | 828         | 53% / 39% / 8%          | $6.2M          | Fintech                   | 2019–2026 |
| 2   | Softbank                                  | CVC         | Japan          | 357      | 101       | 239         | 7% / 27% / 65%          | $137.0M        | Consumer                  | 2019–2026 |
| 3   | BGF                                       | other       | United Kingdom | 177      | 100       | 137         | 8% / 65% / 27%          | $11.4M         | Business Services         | 2019–2026 |
| 4   | Insight Partners                          | PE          | United States  | 737      | 99        | 493         | 5% / 49% / 46%          | $50.0M         | Enterprise Applications   | 2019–2026 |
| 5   | Tiger Global                              | PE          | United States  | 897      | 95        | 559         | 5% / 43% / 51%          | $65.0M         | Fintech                   | 2019–2026 |
| 6   | Inflection Point Ventures                 | VC          | –              | 256      | 95        | 196         | 43% / 57% / 0%          | $790.0K        | Consumer                  | 2019–2026 |
| 7   | European Investment Bank                  | government  | –              | 153      | 85        | 130         | 3% / 66% / 31%          | $27.0M         | High Tech                 | 2019–2026 |
| 8   | Accel                                     | VC          | United States  | 865      | 73        | 479         | 17% / 46% / 36%         | $28.0M         | Enterprise Applications   | 2019–2026 |
| 9   | Antler                                    | accelerator | Singapore      | 244      | 73        | 205         | 83% / 17% / 0%          | $1.9M          | Fintech                   | 2019–2026 |
| 10  | International Finance Corporation         | government  | United States  | 178      | 73        | 143         | 5% / 52% / 43%          | $34.0M         | Fintech                   | 2019–2026 |
| 11  | Peak XV Partners                          | VC          | India          | 506      | 69        | 316         | 23% / 51% / 26%         | $16.9M         | Fintech                   | 2019–2026 |
| 12  | Sequoia Capital                           | VC          | United States  | 827      | 68        | 490         | 15% / 38% / 47%         | $45.0M         | Enterprise Applications   | 2019–2026 |
| 13  | Cibc Innovation Banking                   | bank-debt   | –              | 91       | 66        | 82          | 2% / 16% / 82%          | $13.0M         | Enterprise Applications   | 2019–2026 |
| 14  | Silicon Valley Bank                       | bank-debt   | United States  | 226      | 64        | 189         | 6% / 51% / 43%          | $31.0M         | Enterprise Applications   | 2019–2026 |
| 15  | Goldman Sachs                             | PE          | United States  | 362      | 63        | 268         | 5% / 28% / 67%          | $88.0M         | Fintech                   | 2019–2026 |
| 16  | 100X.Vc                                   | VC          | India          | 101      | 60        | 78          | 90% / 10% / 0%          | $176.5K        | Consumer                  | 2020–2025 |
| 17  | Andreessen Horowitz                       | VC          | United States  | 719      | 58        | 444         | 18% / 50% / 32%         | $40.0M         | High Tech                 | 2019–2026 |
| 18  | Google                                    | CVC         | United States  | 213      | 54        | 166         | 33% / 28% / 38%         | $27.8M         | High Tech                 | 2019–2026 |
| 19  | Trifecta Capital                          | bank-debt   | United States  | 131      | 53        | 80          | 2% / 44% / 54%          | $13.0M         | Food and Agriculture Tech | 2019–2026 |
| 20  | KKR                                       | PE          | United States  | 158      | 51        | 117         | 5% / 15% / 80%          | $125.0M        | Fintech                   | 2019–2026 |
| 21  | InfoEdge Ventures                         | CVC         | India          | 152      | 49        | 75          | 29% / 65% / 7%          | $4.5M          | Consumer                  | 2019–2026 |
| 22  | Alteria Capital                           | bank-debt   | India          | 159      | 48        | 97          | 5% / 65% / 30%          | $12.1M         | Consumer                  | 2019–2026 |
| 23  | European Innovation Council               | government  | –              | 137      | 48        | 118         | 18% / 68% / 14%         | $10.8M         | Life Sciences             | 2019–2026 |
| 24  | Venture Catalysts                         | VC          | India          | 269      | 46        | 179         | 44% / 55% / 1%          | $1.5M          | Fintech                   | 2019–2026 |
| 25  | Tencent                                   | CVC         | China          | 262      | 46        | 164         | 5% / 40% / 54%          | $100.0M        | Fintech                   | 2019–2026 |
| 26  | Sustainable Development Technology Canada | other       | Canada         | 70       | 45        | 63          | 75% / 19% / 6%          | $3.9M          | Food and Agriculture Tech | 2019–2025 |
| 27  | Intel Capital                             | CVC         | United States  | 264      | 43        | 179         | 6% / 58% / 35%          | $30.0M         | Enterprise Infrastructure | 2019–2026 |
| 28  | General Atlantic                          | PE          | United States  | 218      | 43        | 140         | 1% / 27% / 71%          | $115.5M        | Enterprise Applications   | 2019–2026 |
| 29  | Innoven Capital                           | bank-debt   | India          | 113      | 43        | 66          | 11% / 51% / 38%         | $13.6M         | Retail                    | 2019–2026 |
| 30  | Crowdcube                                 | other       | United Kingdom | 65       | 43        | 58          | 44% / 56% / 0%          | $1.7M          | Fintech                   | 2019–2025 |
| 31  | Lightspeed Venture Partners               | VC          | United States  | 683      | 42        | 394         | 18% / 50% / 32%         | $39.5M         | Enterprise Infrastructure | 2019–2026 |
| 32  | Temasek                                   | government  | Singapore      | 336      | 42        | 202         | 2% / 31% / 67%          | $100.0M        | Food and Agriculture Tech | 2019–2026 |
| 33  | Decathlon Capital Partners                | VC          | United States  | 44       | 41        | 44          | 0% / 8% / 92%           | $13.0M         | Consumer                  | 2019–2026 |
| 34  | Elevation Capital                         | VC          | India          | 190      | 40        | 102         | 26% / 52% / 21%         | $12.0M         | Consumer                  | 2020–2026 |
| 35  | British International Investment          | government  | –              | 93       | 39        | 68          | 0% / 60% / 40%          | $25.0M         | Financial Services        | 2022–2026 |
| 36  | BlackSoil Capital                         | bank-debt   | India          | 79       | 39        | 59          | 4% / 42% / 54%          | $5.6M          | Consumer                  | 2019–2026 |
| 37  | Amazon                                    | CVC         | United States  | 127      | 37        | 92          | 30% / 25% / 44%         | $40.0M         | High Tech                 | 2019–2026 |
| 38  | Stride Ventures                           | bank-debt   | India          | 159      | 36        | 111         | 23% / 66% / 11%         | $10.0M         | Consumer                  | 2019–2026 |
| 39  | Accel India                               | VC          | India          | 82       | 36        | 60          | 41% / 38% / 21%         | $6.2M          | Consumer                  | 2019–2026 |
| 40  | Development Bank Of Wales                 | government  | –              | 70       | 35        | 53          | 67% / 33% / 0%          | $1.3M          | Life Sciences             | 2019–2026 |
| 41  | JP Morgan                                 | bank-debt   | United States  | 179      | 34        | 138         | 2% / 35% / 63%          | $100.0M        | Fintech                   | 2019–2026 |
| 42  | Trinity Capital                           | bank-debt   | United States  | 103      | 34        | 84          | 0% / 42% / 58%          | $33.0M         | Enterprise Applications   | 2019–2026 |
| 43  | Blume Ventures                            | VC          | India          | 279      | 33        | 143         | 23% / 60% / 17%         | $7.0M          | Enterprise Applications   | 2019–2026 |
| 44  | Techstars                                 | accelerator | United States  | 369      | 32        | 322         | 72% / 26% / 2%          | $3.0M          | Enterprise Applications   | 2019–2026 |
| 45  | Five Elms Capital                         | VC          | United States  | 47       | 32        | 40          | 0% / 68% / 32%          | $19.2M         | Enterprise Applications   | 2020–2026 |
| 46  | Klub                                      | other       | Kiribati       | 39       | 32        | 34          | 17% / 33% / 50%         | $1.2M          | Food and Agriculture      | 2021–2024 |
| 47  | Prosus Ventures                           | CVC         | Netherlands    | 187      | 31        | 108         | 7% / 54% / 38%          | $50.0M         | Fintech                   | 2019–2026 |
| 48  | Accenture Ventures                        | CVC         | United States  | 83       | 31        | 69          | 25% / 45% / 30%         | $25.0M         | Enterprise Applications   | 2019–2026 |
| 49  | Blackrock                                 | PE          | United States  | 245      | 30        | 175         | 1% / 23% / 76%          | $125.5M        | Fintech                   | 2019–2026 |
| 50  | Microsoft                                 | CVC         | United States  | 154      | 29        | 114         | 23% / 31% / 46%         | $38.8M         | High Tech                 | 2019–2026 |

### Most active investors in US startups (top 50)

Rounds raised by companies based in the United States.

| #   | Investor                               | Type        | HQ             | Rounds in United States   | As lead   | Companies   | Median round   | Top city      | Top sector                | Rounds 2025–26   |
|:----|:---------------------------------------|:------------|:---------------|:--------------------------|:----------|:------------|:---------------|:--------------|:--------------------------|:-----------------|
| 1   | Y Combinator                           | accelerator | United States  | 578                       | 28        | 451         | $10.0M         | San Francisco | Enterprise Applications   | 132              |
| 2   | Andreessen Horowitz                    | VC          | United States  | 569                       | 41        | 344         | $45.0M         | San Francisco | High Tech                 | 100              |
| 3   | Insight Partners                       | PE          | United States  | 453                       | 59        | 304         | $50.0M         | San Francisco | Enterprise Applications   | 59               |
| 4   | Sequoia Capital                        | VC          | United States  | 451                       | 26        | 256         | $55.0M         | San Francisco | Enterprise Applications   | 85               |
| 5   | Tiger Global                           | PE          | United States  | 441                       | 26        | 299         | $76.0M         | San Francisco | Enterprise Applications   | 29               |
| 6   | Lightspeed Venture Partners            | VC          | United States  | 398                       | 19        | 236         | $50.0M         | San Francisco | Enterprise Infrastructure | 83               |
| 7   | Accel                                  | VC          | United States  | 369                       | 14        | 222         | $35.0M         | San Francisco | Enterprise Applications   | 56               |
| 8   | Khosla Ventures                        | VC          | United States  | 324                       | 16        | 206         | $30.0M         | San Francisco | Fintech                   | 61               |
| 9   | Bessemer Venture Partners              | VC          | United States  | 280                       | 12        | 178         | $30.0M         | New York      | Enterprise Applications   | 47               |
| 10  | Gaingels                               | other       | United States  | 276                       | 0         | 249         | $16.5M         | New York      | Enterprise Applications   | 27               |
| 11  | Founders Fund                          | VC          | United States  | 275                       | 15        | 166         | $40.0M         | San Francisco | Enterprise Applications   | 49               |
| 12  | Bain Capital Ventures                  | VC          | United States  | 257                       | 17        | 166         | $35.5M         | San Francisco | Enterprise Applications   | 38               |
| 13  | Coatue                                 | PE          | United States  | 251                       | 11        | 144         | $135.0M        | San Francisco | Enterprise Applications   | 44               |
| 14  | 8VC                                    | VC          | United States  | 233                       | 6         | 151         | $30.0M         | San Francisco | Enterprise Applications   | 38               |
| 15  | Alumni Ventures                        | VC          | United States  | 232                       | 1         | 213         | $15.0M         | New York      | High Tech                 | 55               |
| 16  | Salesforce Ventures                    | CVC         | United States  | 227                       | 13        | 148         | $60.0M         | San Francisco | Enterprise Applications   | 29               |
| 17  | Index Ventures                         | VC          | United Kingdom | 219                       | 2         | 128         | $44.5M         | San Francisco | Enterprise Infrastructure | 34               |
| 18  | Kleiner Perkins                        | VC          | United States  | 217                       | 9         | 132         | $52.0M         | San Francisco | Enterprise Applications   | 35               |
| 19  | Norwest Venture Partners               | VC          | United States  | 205                       | 15        | 131         | $50.0M         | San Francisco | Enterprise Applications   | 28               |
| 20  | Menlo Ventures                         | VC          | United States  | 203                       | 4         | 128         | $41.0M         | San Francisco | Enterprise Applications   | 42               |
| 21  | Greycroft                              | VC          | United States  | 196                       | 7         | 139         | $20.0M         | New York      | Fintech                   | 16               |
| 22  | Lux Capital                            | VC          | United States  | 190                       | 4         | 118         | $40.0M         | San Francisco | High Tech                 | 36               |
| 23  | Intel Capital                          | CVC         | United States  | 181                       | 29        | 124         | $30.0M         | San Francisco | Enterprise Infrastructure | 22               |
| 24  | Techstars                              | accelerator | United States  | 178                       | 8         | 161         | $3.7M          | New York      | Enterprise Applications   | 20               |
| 25  | Goldman Sachs                          | PE          | United States  | 176                       | 19        | 135         | $75.0M         | New York      | Fintech                   | 19               |
| 26  | NEA                                    | VC          | United States  | 175                       | 2         | 129         | $43.5M         | San Francisco | Enterprise Applications   | 32               |
| 27  | Madrona Venture Group                  | VC          | United States  | 166                       | 8         | 100         | $21.0M         | Seattle       | Enterprise Applications   | 27               |
| 28  | Citi Ventures                          | CVC         | United States  | 165                       | 13        | 121         | $40.0M         | New York      | Fintech                   | 30               |
| 29  | Spark Capital                          | VC          | United States  | 159                       | 2         | 101         | $50.0M         | San Francisco | Enterprise Applications   | 21               |
| 30  | Thrive Capital                         | VC          | United States  | 158                       | 12        | 83          | $71.2M         | San Francisco | Fintech                   | 34               |
| 31  | Silicon Valley Bank                    | bank-debt   | United States  | 157                       | 43        | 131         | $40.0M         | San Francisco | Enterprise Applications   | 15               |
| 32  | Felicis Ventures                       | VC          | United States  | 156                       | 4         | 103         | $30.0M         | San Francisco | Enterprise Applications   | 24               |
| 33  | Blackrock                              | PE          | United States  | 149                       | 8         | 104         | $145.0M        | San Francisco | Enterprise Infrastructure | 18               |
| 34  | Craft Ventures                         | VC          | United States  | 148                       | 8         | 104         | $20.0M         | San Francisco | Enterprise Applications   | 19               |
| 35  | Redpoint Ventures                      | VC          | United States  | 143                       | 3         | 88          | $52.0M         | San Francisco | Enterprise Infrastructure | 22               |
| 36  | Softbank                               | CVC         | Japan          | 141                       | 41        | 100         | $130.0M        | San Francisco | High Tech                 | 26               |
| 37  | Battery Ventures                       | VC          | United States  | 140                       | 7         | 99          | $45.5M         | San Francisco | Enterprise Applications   | 26               |
| 38  | True Ventures                          | VC          | United States  | 136                       | 9         | 84          | $18.0M         | San Francisco | Enterprise Applications   | 14               |
| 39  | Greylock                               | VC          | United States  | 133                       | 6         | 80          | $40.0M         | San Francisco | Enterprise Infrastructure | 16               |
| 40  | Temasek                                | government  | Singapore      | 133                       | 6         | 89          | $121.5M        | San Francisco | Food and Agriculture Tech | 29               |
| 41  | Valor Equity Partners                  | PE          | United States  | 133                       | 3         | 89          | $56.5M         | San Francisco | High Tech                 | 37               |
| 42  | Ra Capital Management                  | VC          | United Kingdom | 131                       | 1         | 107         | $104.0M        | Boston        | Life Sciences             | 18               |
| 43  | Google Ventures                        | CVC         | United States  | 128                       | 5         | 106         | $64.5M         | San Francisco | Healthtech                | 23               |
| 44  | Sapphire Ventures                      | VC          | United States  | 128                       | 0         | 81          | $100.0M        | San Francisco | Enterprise Applications   | 16               |
| 45  | F-Prime Capital                        | VC          | United States  | 126                       | 4         | 94          | $29.0M         | Boston        | Life Sciences             | 7                |
| 46  | Gradient Ventures                      | CVC         | United States  | 123                       | 5         | 81          | $10.0M         | San Francisco | Enterprise Applications   | 15               |
| 47  | CRV                                    | VC          | –              | 123                       | 4         | 82          | $35.0M         | San Francisco | Enterprise Infrastructure | 11               |
| 48  | Alexandria Venture Investments         | VC          | –              | 123                       | 0         | 106         | $65.0M         | Cambridge     | Life Sciences             | 14               |
| 49  | Nvidia                                 | CVC         | United States  | 122                       | 17        | 69          | $120.0M        | San Francisco | High Tech                 | 49               |
| 50  | Fidelity Management & Research Company | PE          | –              | 122                       | 3         | 91          | $160.0M        | San Francisco | Life Sciences             | 25               |

### Most active investors in UK startups (top 50)

Rounds raised by companies based in the United Kingdom.

| #   | Investor                           | Type        | HQ             | Rounds in United Kingdom   | As lead   | Companies   | Median round   | Top city   | Top sector              | Rounds 2025–26   |
|:----|:-----------------------------------|:------------|:---------------|:---------------------------|:----------|:------------|:---------------|:-----------|:------------------------|:-----------------|
| 1   | BGF                                | other       | United Kingdom | 140                        | 82        | 113         | $12.0M         | London     | Business Services       | 25               |
| 2   | Octopus Ventures                   | VC          | United Kingdom | 128                        | 20        | 97          | $11.0M         | London     | Fintech                 | 10               |
| 3   | Seedcamp                           | accelerator | United Kingdom | 106                        | 1         | 64          | $6.3M          | London     | Fintech                 | 13               |
| 4   | Mercia Ventures                    | VC          | United Kingdom | 88                         | 6         | 75          | $2.7M          | London     | Enterprise Applications | 19               |
| 5   | MMC Ventures                       | VC          | United Kingdom | 82                         | 4         | 48          | $11.1M         | London     | Enterprise Applications | 11               |
| 6   | Localglobe                         | VC          | United Kingdom | 70                         | 2         | 48          | $9.9M          | London     | Fintech                 | 9                |
| 7   | Fuel Ventures                      | VC          | United Kingdom | 61                         | 13        | 44          | $3.0M          | London     | Enterprise Applications | 7                |
| 8   | Y Combinator                       | accelerator | United States  | 58                         | 4         | 45          | $8.0M          | London     | Enterprise Applications | 10               |
| 9   | Accel                              | VC          | United States  | 56                         | 7         | 35          | $31.8M         | London     | Fintech                 | 9                |
| 10  | Development Bank Of Wales          | government  | –              | 55                         | 27        | 42          | $1.3M          | Cardiff    | Life Sciences           | 3                |
| 11  | Maven Capital Partners             | VC          | United Kingdom | 55                         | 21        | 52          | $3.5M          | London     | Enterprise Applications | 9                |
| 12  | Parkwalk Advisors                  | VC          | United Kingdom | 55                         | 5         | 39          | $10.1M         | Cambridge  | Life Sciences           | 5                |
| 13  | Amadeus Capital Partners           | VC          | United Kingdom | 55                         | 1         | 31          | $9.0M          | London     | High Tech               | 7                |
| 14  | Index Ventures                     | VC          | United Kingdom | 55                         | 0         | 38          | $21.1M         | London     | Fintech                 | 2                |
| 15  | Albionvc                           | VC          | United Kingdom | 54                         | 3         | 40          | $9.6M          | London     | Enterprise Applications | 6                |
| 16  | IQ Capital                         | VC          | United Kingdom | 54                         | 2         | 34          | $8.7M          | London     | High Tech               | 5                |
| 17  | Insight Partners                   | PE          | United States  | 53                         | 7         | 34          | $50.0M         | London     | Fintech                 | 12               |
| 18  | Foresight Group                    | VC          | China          | 52                         | 18        | 40          | $5.7M          | London     | Enterprise Applications | 13               |
| 19  | Crowdcube                          | other       | United Kingdom | 47                         | 30        | 40          | $1.8M          | London     | Fintech                 | 3                |
| 20  | Praetura Ventures                  | VC          | United Kingdom | 45                         | 16        | 37          | $4.1M          | Manchester | Enterprise Applications | 0                |
| 21  | Natwest                            | bank-debt   | –              | 45                         | 14        | 32          | $82.5M         | London     | Fintech                 | 6                |
| 22  | SFC Capital                        | VC          | United Kingdom | 45                         | 5         | 39          | $738.0K        | London     | Enterprise Applications | 2                |
| 23  | Techstart Ventures                 | VC          | United Kingdom | 44                         | 6         | 34          | $2.4M          | Belfast    | Enterprise Applications | 3                |
| 24  | Ascension Ventures                 | VC          | United States  | 43                         | 1         | 36          | $3.0M          | London     | Fintech                 | 1                |
| 25  | Speedinvest                        | VC          | Austria        | 41                         | 0         | 27          | $6.0M          | London     | Fintech                 | 3                |
| 26  | Blackfinch Ventures                | VC          | United Kingdom | 40                         | 19        | 26          | $1.9M          | London     | Enterprise Applications | 5                |
| 27  | Citi Ventures                      | CVC         | United States  | 40                         | 3         | 29          | $62.0M         | London     | Fintech                 | 9                |
| 28  | Par Equity                         | VC          | United Kingdom | 40                         | 3         | 27          | $3.3M          | Edinburgh  | Energy Tech             | 6                |
| 29  | Episode 1                          | VC          | United Kingdom | 40                         | 0         | 24          | $3.6M          | London     | Enterprise Applications | 3                |
| 30  | Notion Capital                     | VC          | United Kingdom | 40                         | 0         | 28          | $15.0M         | London     | Fintech                 | 4                |
| 31  | Barclays                           | bank-debt   | India          | 39                         | 7         | 33          | $33.0M         | London     | Fintech                 | 5                |
| 32  | Seedrs                             | other       | Ireland        | 38                         | 13        | 34          | $1.9M          | London     | Consumer                | 0                |
| 33  | Google Ventures                    | CVC         | United States  | 38                         | 6         | 26          | $30.1M         | London     | Enterprise Applications | 11               |
| 34  | Passion Capital                    | VC          | United Kingdom | 38                         | 4         | 23          | $7.1M          | London     | Fintech                 | 1                |
| 35  | IP Group                           | VC          | Australia      | 37                         | 1         | 30          | $23.8M         | Oxford     | Life Sciences           | 11               |
| 36  | Gresham House Ventures             | VC          | United Kingdom | 36                         | 19        | 26          | $6.3M          | London     | Consumer                | 5                |
| 37  | HSBC                               | bank-debt   | United Kingdom | 36                         | 10        | 29          | $51.6M         | London     | Fintech                 | 8                |
| 38  | Techstars                          | accelerator | United States  | 36                         | 2         | 33          | $2.5M          | London     | Enterprise Applications | 6                |
| 39  | Scottish Investment Bank           | bank-debt   | United Kingdom | 36                         | 1         | 31          | $3.4M          | Edinburgh  | Life Sciences           | 0                |
| 40  | Atomico                            | VC          | United Kingdom | 35                         | 2         | 25          | $24.8M         | London     | Enterprise Applications | 10               |
| 41  | Balderton Capital                  | VC          | United Kingdom | 35                         | 2         | 24          | $35.0M         | London     | Fintech                 | 6                |
| 42  | YFM Equity Partners                | PE          | –              | 33                         | 17        | 26          | $6.3M          | London     | Enterprise Applications | 11               |
| 43  | British Business Bank              | government  | United Kingdom | 33                         | 12        | 30          | $5.1M          | London     | Life Sciences           | 16               |
| 44  | 24Haymarket                        | other       | United Kingdom | 33                         | 7         | 26          | $3.5M          | London     | Enterprise Applications | 2                |
| 45  | European Regional Development Fund | government  | –              | 33                         | 2         | 25          | $920.5K        | Newcastle  | Enterprise Applications | 4                |
| 46  | Npif – Mercia Equity Finance       | government  | –              | 32                         | 11        | 26          | $1.9M          | Sheffield  | Enterprise Applications | 2                |
| 47  | Cambridge Innovation Capital       | VC          | –              | 32                         | 1         | 23          | $32.0M         | Cambridge  | Life Sciences           | 4                |
| 48  | Playfair Capital                   | VC          | United Kingdom | 32                         | 1         | 17          | $6.2M          | London     | Enterprise Applications | 2                |
| 49  | Tiger Global                       | PE          | United States  | 32                         | 0         | 24          | $67.5M         | London     | Fintech                 | 4                |
| 50  | Goldman Sachs                      | PE          | United States  | 31                         | 8         | 23          | $96.5M         | London     | Fintech                 | 6                |

### Most active investors in Indian startups (top 50)

Rounds raised by companies based in India.

| #   | Investor                         | Type        | HQ            | Rounds in India   | As lead   | Companies   | Median round   | Top city   | Top sector                | Rounds 2025–26   |
|:----|:---------------------------------|:------------|:--------------|:------------------|:----------|:------------|:---------------|:-----------|:--------------------------|:-----------------|
| 1   | Peak XV Partners                 | VC          | India         | 263               | 43        | 149         | $15.0M         | Bengaluru  | Fintech                   | 32               |
| 2   | Accel                            | VC          | United States | 253               | 45        | 118         | $12.3M         | Bengaluru  | Retail                    | 39               |
| 3   | Inflection Point Ventures        | VC          | –             | 238               | 86        | 181         | $840.0K        | Bengaluru  | Consumer                  | 36               |
| 4   | Venture Catalysts                | VC          | India         | 234               | 38        | 150         | $1.5M          | New Delhi  | Fintech                   | 25               |
| 5   | Tiger Global                     | PE          | United States | 214               | 50        | 90          | $51.0M         | Bengaluru  | Fintech                   | 10               |
| 6   | Blume Ventures                   | VC          | India         | 209               | 28        | 102         | $7.0M          | Bengaluru  | Consumer                  | 34               |
| 7   | Sequoia Capital                  | VC          | United States | 193               | 27        | 112         | $23.5M         | Bengaluru  | Fintech                   | 2                |
| 8   | Alteria Capital                  | bank-debt   | India         | 146               | 45        | 86          | $12.5M         | Bengaluru  | Consumer                  | 15               |
| 9   | Letsventure                      | other       | India         | 146               | 3         | 117         | $1.4M          | Bengaluru  | Consumer                  | 9                |
| 10  | Elevation Capital                | VC          | India         | 140               | 28        | 65          | $13.0M         | Bengaluru  | Consumer                  | 19               |
| 11  | Lightspeed Venture Partners      | VC          | United States | 139               | 13        | 63          | $15.0M         | Bengaluru  | Retail                    | 19               |
| 12  | Better Capital                   | VC          | Guernsey      | 139               | 6         | 94          | $2.5M          | Bengaluru  | Edtech                    | 2                |
| 13  | InfoEdge Ventures                | CVC         | India         | 132               | 43        | 61          | $5.0M          | Gurugram   | Consumer                  | 28               |
| 14  | Chiratae Ventures                | VC          | India         | 130               | 16        | 65          | $7.5M          | Bengaluru  | Consumer                  | 11               |
| 15  | Titan Capital                    | VC          | India         | 128               | 8         | 90          | $1.5M          | Bengaluru  | Consumer                  | 13               |
| 16  | 3One4 Capital                    | VC          | India         | 124               | 11        | 59          | $8.4M          | Bengaluru  | Consumer                  | 24               |
| 17  | Matrix Partners India            | VC          | India         | 122               | 9         | 57          | $10.0M         | Bengaluru  | Food and Agriculture Tech | 1                |
| 18  | Trifecta Capital                 | bank-debt   | United States | 121               | 48        | 71          | $13.0M         | Bengaluru  | Food and Agriculture Tech | 13               |
| 19  | Beenext                          | VC          | Singapore     | 111               | 13        | 60          | $7.2M          | Bengaluru  | Fintech                   | 7                |
| 20  | Kalaari Capital                  | VC          | India         | 109               | 20        | 65          | $7.0M          | Bengaluru  | Consumer                  | 9                |
| 21  | Y Combinator                     | accelerator | United States | 107               | 11        | 75          | $3.0M          | Bengaluru  | Fintech                   | 10               |
| 22  | Matrix Partners                  | VC          | United States | 106               | 23        | 62          | $11.0M         | Bengaluru  | Consumer                  | 3                |
| 23  | Indian Angel Network             | other       | –             | 104               | 17        | 82          | $1.0M          | Bengaluru  | Consumer                  | 8                |
| 24  | Nexus Venture Partners           | VC          | United States | 103               | 14        | 51          | $9.0M          | Bengaluru  | Consumer                  | 15               |
| 25  | 9Unicorns                        | VC          | India         | 100               | 3         | 71          | $4.0M          | Bengaluru  | Fintech                   | 4                |
| 26  | Stride Ventures                  | bank-debt   | India         | 96                | 26        | 62          | $10.0M         | Bengaluru  | Retail                    | 7                |
| 27  | 100X.Vc                          | VC          | India         | 94                | 54        | 71          | $200.0K        | Mumbai     | High Tech                 | 13               |
| 28  | Omnivore                         | VC          | United States | 92                | 10        | 46          | $6.0M          | Bengaluru  | Food and Agriculture Tech | 5                |
| 29  | Fireside Ventures                | VC          | United States | 91                | 21        | 43          | $6.5M          | Bengaluru  | Consumer Goods            | 23               |
| 30  | Innoven Capital                  | bank-debt   | India         | 89                | 38        | 48          | $13.2M         | Bengaluru  | Retail                    | 6                |
| 31  | Temasek                          | government  | Singapore     | 84                | 28        | 34          | $100.0M        | Mumbai     | Food and Agriculture Tech | 7                |
| 32  | Mumbai Angels                    | other       | India         | 80                | 8         | 57          | $1.0M          | Bengaluru  | Enterprise Applications   | 3                |
| 33  | Anicut Capital                   | VC          | India         | 75                | 7         | 47          | $4.1M          | Bengaluru  | Retail                    | 23               |
| 34  | DSG Consumer Partners            | VC          | –             | 74                | 13        | 38          | $3.8M          | Mumbai     | Food and Agriculture Tech | 11               |
| 35  | BlackSoil Capital                | bank-debt   | India         | 72                | 36        | 52          | $5.6M          | Bengaluru  | Consumer                  | 4                |
| 36  | Omidyar Network India            | VC          | India         | 72                | 3         | 42          | $5.5M          | Bengaluru  | Edtech                    | 3                |
| 37  | Prosus Ventures                  | CVC         | Netherlands   | 70                | 21        | 31          | $75.0M         | Bengaluru  | Food and Agriculture Tech | 13               |
| 38  | Westbridge Capital               | VC          | Mauritius     | 68                | 18        | 36          | $30.2M         | Bengaluru  | Edtech                    | 10               |
| 39  | Orios Venture Partners           | VC          | India         | 67                | 11        | 33          | $7.1M          | Gurugram   | Fintech                   | 8                |
| 40  | IAN Fund                         | VC          | India         | 66                | 4         | 53          | $2.0M          | Bengaluru  | Consumer                  | 14               |
| 41  | Stellaris Venture Partners       | VC          | India         | 64                | 8         | 31          | $7.1M          | Bengaluru  | Consumer                  | 4                |
| 42  | Bessemer Venture Partners        | VC          | United States | 63                | 9         | 35          | $25.0M         | Bengaluru  | Retail                    | 12               |
| 43  | Rainmatter                       | VC          | India         | 62                | 20        | 53          | $2.5M          | Bengaluru  | Fintech                   | 20               |
| 44  | British International Investment | government  | –             | 60                | 22        | 37          | $24.2M         | Bengaluru  | Financial Services        | 16               |
| 45  | Unicorn India Ventures           | VC          | India         | 60                | 21        | 43          | $1.5M          | Bengaluru  | High Tech                 | 15               |
| 46  | Sixth Sense Ventures             | VC          | India         | 59                | 19        | 37          | $8.0M          | New Delhi  | Consumer Goods            | 3                |
| 47  | Premji Invest                    | PE          | India         | 57                | 10        | 28          | $55.0M         | Bengaluru  | Fintech                   | 11               |
| 48  | Softbank                         | CVC         | Japan         | 56                | 21        | 26          | $200.0M        | Bengaluru  | Consumer                  | 6                |
| 49  | Ivycap Ventures                  | VC          | India         | 56                | 18        | 38          | $6.5M          | Bengaluru  | Consumer                  | 15               |
| 50  | YourNest Venture Capital         | VC          | India         | 56                | 12        | 30          | $2.7M          | Bengaluru  | High Tech                 | 7                |

### Investors by headquarters country (top 30)

Only the 16,930 investors whose headquarters is known (48%).

| #   | HQ country           | Investors   | Rounds joined   | Led   | VC share   | Median of median round   | Most active                                            |
|:----|:---------------------|:------------|:----------------|:------|:-----------|:-------------------------|:-------------------------------------------------------|
| 1   | United States        | 6,641       | 77,083          | 6,557 | 79.7%      | $12.0M                   | Y Combinator, Tiger Global, Accel                      |
| 2   | United Kingdom       | 1,270       | 11,498          | 1,654 | 68.9%      | $8.4M                    | Index Ventures, Seedcamp, Octopus Ventures             |
| 3   | India                | 1,228       | 10,756          | 1,883 | 71.0%      | $4.7M                    | Peak XV Partners, Blume Ventures, Venture Catalysts    |
| 4   | China                | 596         | 3,316           | 277   | 72.3%      | $35.0M                   | Tencent, Sequoia Capital China, Horizons Ventures      |
| 5   | Canada               | 563         | 4,304           | 544   | 70.0%      | $7.4M                    | BDC Capital, Inovia Capital, Bond                      |
| 6   | Germany              | 530         | 4,404           | 293   | 73.0%      | $9.3M                    | Global Founders Capital, Picus Capital, HV Capital     |
| 7   | France               | 494         | 4,151           | 283   | 64.6%      | $9.4M                    | Bpifrance, Partech, Eurazeo                            |
| 8   | Singapore            | 424         | 3,623           | 470   | 77.6%      | $6.9M                    | Temasek, Antler, Beenext                               |
| 9   | Australia            | 385         | 2,445           | 293   | 71.4%      | $9.0M                    | Blackbird Ventures, Future Ventures, Owl Ventures      |
| 10  | Japan                | 361         | 2,433           | 327   | 72.0%      | $15.2M                   | Softbank, East Ventures, Sbi Investment                |
| 11  | Netherlands          | 308         | 2,056           | 271   | 72.1%      | $7.5M                    | Prosus Ventures, ING, FMO                              |
| 12  | Spain                | 277         | 1,877           | 190   | 67.1%      | $4.0M                    | Aleph, Mundi Ventures, Santander                       |
| 13  | Brazil               | 273         | 1,718           | 267   | 66.7%      | $7.0M                    | Monashees, Canary, Global Brain                        |
| 14  | Switzerland          | 271         | 1,683           | 157   | 68.3%      | $10.5M                   | Benchmark, Lakestar, Redalpine                         |
| 15  | South Korea          | 220         | 1,510           | 138   | 71.8%      | $14.8M                   | 500 Startups, Samsung Ventures, Softbank Ventures Asia |
| 16  | Israel               | 217         | 2,012           | 123   | 82.0%      | $13.0M                   | Ourcrowd, Viola Ventures, Vulcan Capital               |
| 17  | United Arab Emirates | 171         | 1,247           | 137   | 81.3%      | $7.5M                    | Mubadala, Global Ventures, Shorooq Partners            |
| 18  | Sweden               | 169         | 1,191           | 134   | 67.5%      | $9.0M                    | EQT Ventures, Creandum, Kinnevik                       |
| 19  | Italy                | 162         | 789             | 60    | 76.5%      | $7.8M                    | CDP Venture Capital, Spartan Group, Mango Capital      |
| 20  | Belgium              | 146         | 799             | 79    | 67.8%      | $6.7M                    | Sofina, Astanor Ventures, PMV                          |
| 21  | South Africa         | 101         | 450             | 119   | 66.3%      | $4.3M                    | PSG, Leapfrog Investments, Java Capital                |
| 22  | Saudi Arabia         | 98          | 731             | 91    | 79.6%      | $9.5M                    | Cornerstone VC, Wa’ed Ventures, Raed Ventures          |
| 23  | Denmark              | 95          | 632             | 58    | 76.8%      | $12.2M                   | Novo Holdings, Heartcore Capital, Byfounders           |
| 24  | Indonesia            | 95          | 530             | 40    | 82.1%      | $7.7M                    | Mirae Asset, Monk’S Hill Ventures, Alpha JWC Ventures  |
| 25  | Finland              | 93          | 514             | 56    | 71.0%      | $8.1M                    | Lifeline Ventures, Good Capital, Tesi                  |
| 26  | Ireland              | 87          | 498             | 84    | 59.8%      | $5.2M                    | Frontline Ventures, Act Venture Capital, Seedrs        |
| 27  | Mexico               | 78          | 312             | 28    | 80.8%      | $6.9M                    | Dila Capital, Cometa, Proeza Ventures                  |
| 28  | Norway               | 75          | 391             | 43    | 56.0%      | $10.7M                   | Equinor Ventures, Alliance Ventures, Verdane           |
| 29  | Nigeria              | 66          | 376             | 66    | 62.1%      | $3.0M                    | Ventures Platform, Plus VC, Microtraction              |
| 30  | Turkey               | 65          | 200             | 39    | 72.3%      | $2.2M                    | APY Ventures, Finberg, Esas Ventures                   |

### Investors by type

Types are assigned by rule from the name, the company record and the deal mix.

| Type        | Investors   | Rounds joined   | Led    | Rounds per investor   | Avg seed share   | Avg growth share   | Median round joined   | Most active                                                                                |
|:------------|:------------|:----------------|:-------|:----------------------|:-----------------|:-------------------|:----------------------|:-------------------------------------------------------------------------------------------|
| VC          | 24,377      | 146,114         | 12,649 | 6.0                   | 37.9%            | 11.8%              | $8.6M                 | Accel, Sequoia Capital, Andreessen Horowitz, Lightspeed Venture Partners, Peak XV Partners |
| other       | 5,137       | 12,751          | 3,177  | 2.5                   | 43.2%            | 11.6%              | $5.6M                 | Gaingels, BGF, Letsventure, Indian Angel Network, Mumbai Angels                            |
| PE          | 2,027       | 13,985          | 1,911  | 6.9                   | 3.3%             | 80.1%              | $93.6M                | Tiger Global, Insight Partners, Coatue, Goldman Sachs, Blackrock                           |
| bank-debt   | 1,817       | 6,673           | 1,583  | 3.7                   | 17.6%            | 31.4%              | $25.4M                | Silicon Valley Bank, JP Morgan, Alteria Capital, Stride Ventures, BDC Capital              |
| CVC         | 869         | 10,564          | 1,493  | 12.2                  | 22.6%            | 28.2%              | $24.3M                | Softbank, Salesforce Ventures, Citi Ventures, Intel Capital, Tencent                       |
| government  | 652         | 4,198           | 1,096  | 6.4                   | 27.5%            | 26.2%              | $10.0M                | Bpifrance, Temasek, International Finance Corporation, GIC, Mubadala                       |
| accelerator | 431         | 3,326           | 434    | 7.7                   | 60.6%            | 5.2%               | $2.7M                 | Y Combinator, Techstars, Antler, Seedcamp, 500 Startups                                    |

### Most active investors by sector (top 30 sectors)

| Sector                               | Rounds   | Investors   | Median round   | Most active investors (rounds)                                                                    | Most frequent lead                            |
|:-------------------------------------|:---------|:------------|:---------------|:--------------------------------------------------------------------------------------------------|:----------------------------------------------|
| Fintech                              | 8,598    | 8,997       | $14.0M         | Y Combinator (262), Tiger Global (179), Sequoia Capital (141)                                     | Y Combinator (34)                             |
| Enterprise Applications              | 8,485    | 8,279       | $10.8M         | Y Combinator (215), Insight Partners (193), Accel (179)                                           | Insight Partners (23)                         |
| Consumer                             | 5,008    | 6,324       | $11.0M         | Y Combinator (83), Accel (79), Tiger Global (78)                                                  | Softbank (17)                                 |
| High Tech                            | 4,626    | 6,692       | $15.0M         | Andreessen Horowitz (132), Y Combinator (85), Sequoia Capital (79)                                | Nvidia (16)                                   |
| Healthtech                           | 4,221    | 5,762       | $12.3M         | Y Combinator (78), Andreessen Horowitz (56), Optum Ventures (47)                                  | Y Combinator (12)                             |
| Enterprise Infrastructure            | 3,339    | 3,670       | $22.0M         | Insight Partners (148), Accel (129), Lightspeed Venture Partners (105)                            | Insight Partners (26)                         |
| Retail                               | 3,320    | 4,482       | $11.0M         | Accel (73), Tiger Global (68), Sequoia Capital (54)                                               | Alibaba (11)                                  |
| Life Sciences                        | 3,265    | 4,292       | $42.5M         | Orbimed (139), Ra Capital Management (128), Alexandria Venture Investments (97)                   | European Investment Bank (14)                 |
| Food and Agriculture Tech            | 3,250    | 4,532       | $10.0M         | Tiger Global (73), Temasek (53), Omnivore (52)                                                    | Trifecta Capital (15)                         |
| Business Services                    | 2,200    | 3,327       | $9.0M          | BGF (27), Bessemer Venture Partners (21), Antler (17)                                             | BGF (23)                                      |
| Energy Tech                          | 2,063    | 3,235       | $17.5M         | Energy Impact Partners (43), Breakthrough Energy Ventures (36), Temasek (29)                      | U.S. Department of Energy (16)                |
| Healthcare                           | 1,419    | 2,380       | $16.2M         | Y Combinator (16), Alexandria Venture Investments (16), Sequoia Capital (15)                      | BGF (8)                                       |
| Food and Agriculture                 | 1,322    | 1,980       | $7.0M          | Stray Dog Capital (18), Agronomics (18), Klub (15)                                                | Klub (12)                                     |
| Edtech                               | 1,312    | 2,067       | $6.0M          | Owl Ventures (43), GSV Ventures (38), Tiger Global (29)                                           | Blume Ventures (9)                            |
| Real Estate and Construction Tech    | 1,180    | 2,115       | $10.0M         | Tiger Global (23), Y Combinator (17), Foundamental (17)                                           | Softbank (7)                                  |
| Energy                               | 1,131    | 1,720       | $30.5M         | Santander (19), Breakthrough Energy Ventures (19), Rabobank (18)                                  | Eiffel Investment Group (6)                   |
| Environment Tech                     | 951      | 1,747       | $10.0M         | Speedinvest (18), HM Capital (17), Lowercarbon Capital (15)                                       | Sustainable Development Technology Canada (6) |
| Financial Services                   | 920      | 1,466       | $15.3M         | British International Investment (14), JP Morgan (12), responsAbility Investments (12)            | JP Morgan (6)                                 |
| Consumer Goods                       | 781      | 1,283       | $9.0M          | Fireside Ventures (23), Sixth Sense Ventures (17), Venture Catalysts (14)                         | Venture Catalysts (5)                         |
| Media & Entertainment                | 708      | 1,281       | $10.0M         | Accel (15), Lightspeed Venture Partners (13), Sequoia Capital (13)                                | Quebecor Fund (5)                             |
| Aerospace, Maritime and Defense Tech | 625      | 1,309       | $26.0M         | Airbus Ventures (26), Speciale Invest (17), Lockheed Martin Ventures (15)                         | Mumbai Angels Network (4)                     |
| Semiconductors                       | 556      | 1,205       | $22.0M         | Intel Capital (33), European Innovation Council (15), Fidelity Management & Research Company (14) | Oracle (3)                                    |
| Real Estate and Construction         | 444      | 817         | $8.4M          | Bain Capital Ventures (12), BGF (9), Kaszek (6)                                                   | BGF (8)                                       |
| Telecom                              | 427      | 803         | $21.0M         | Y Combinator (9), ING (7), International Finance Corporation (7)                                  | International Finance Corporation (7)         |
| Auto Tech                            | 345      | 776         | $32.0M         | Andreessen Horowitz (12), Toyota Ventures (12), Autotech Ventures (10)                            | European Investment Bank (4)                  |
| AI-native                            | 337      | 698         | $35.0M         | Andreessen Horowitz (21), Lightspeed Venture Partners (14), Sequoia Capital (13)                  | Government Of Ontario (2)                     |
| Environment                          | 322      | 570         | $6.0M          | IW Capital (5), Canada Pension Plan Investment Board (4), Knop Ventures (3)                       | IW Capital (5)                                |
| Gaming                               | 296      | 689         | $8.0M          | Makers Fund (15), Andreessen Horowitz (14), Griffin Gaming Partners (11)                          | Symbolic Capital (3)                          |
| Industrial Goods and Manufacturing   | 264      | 486         | $10.8M         | European Innovation Council (5), Tiger Global (4), NGP Capital (4)                                | BGF (4)                                       |
| Auto                                 | 251      | 492         | $21.0M         | Sequoia Capital (9), Tiger Global (7), Orios Venture Partners (6)                                 | British International Investment (4)          |

### Most active investors by stage

| Stage            | Rounds   | Investors   | Median round   | Most active investors (rounds)                                                                                                                                |
|:-----------------|:---------|:------------|:---------------|:--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Pre-seed         | 2,486    | 3,721       | $1.5M          | Antler (80), Techstars (50), Y Combinator (48), Better Capital (33), Seedcamp (32)                                                                            |
| Angel            | 255      | 429         | $700.0K        | Indian Angel Network (5), Ah! Ventures (5), ah! Ventures Angel Platform (5), Microsoft (4), Letsventure (4)                                                   |
| Seed             | 11,221   | 11,583      | $4.0M          | Y Combinator (423), Techstars (148), Global Founders Capital (147), Soma Capital (115), Accel (112)                                                           |
| Pre-Series A     | 1,670    | 2,682       | $2.8M          | Inflection Point Ventures (106), Venture Catalysts (80), Letsventure (44), Blume Ventures (38), 9Unicorns (35)                                                |
| Series A         | 10,472   | 11,861      | $13.0M         | Y Combinator (248), Accel (162), Andreessen Horowitz (147), Lightspeed Venture Partners (142), Insight Partners (139)                                         |
| Series B         | 5,959    | 8,294       | $35.0M         | Tiger Global (166), Insight Partners (160), Accel (152), Andreessen Horowitz (131), Lightspeed Venture Partners (129)                                         |
| Series C         | 2,932    | 5,043       | $66.6M         | Insight Partners (136), Tiger Global (132), Accel (120), Sequoia Capital (118), Andreessen Horowitz (80)                                                      |
| Series D         | 1,355    | 2,831       | $104.0M        | Tiger Global (92), Sequoia Capital (91), Andreessen Horowitz (60), Accel (59), Insight Partners (57)                                                          |
| Series E         | 617      | 1,467       | $150.0M        | Tiger Global (68), Sequoia Capital (45), Accel (38), Coatue (34), Insight Partners (32)                                                                       |
| Growth / PE      | 1,549    | 2,162       | $35.0M         | Cibc Innovation Banking (35), Insight Partners (30), Edison Partners (25), FTV Capital (23), Summit Partners (23)                                             |
| Venture debt     | 208      | 194         | $10.8M         | European Investment Bank (31), Silicon Valley Bank (25), Alteria Capital (16), Innoven Capital (15), Trifecta Capital (13)                                    |
| Debt             | 1,769    | 2,752       | $30.0M         | Trifecta Capital (53), Alteria Capital (48), Goldman Sachs (47), Innoven Capital (44), Silicon Valley Bank (44)                                               |
| Convertible note | 246      | 650         | $20.0M         | Lightspeed Venture Partners (6), Agronomics (5), Google (5), Khosla Ventures (4), Microsoft (4)                                                               |
| Grant            | 1,049    | 991         | $1.6M          | U.S. Department of Energy (28), Bill & Melinda Gates Foundation (28), European Innovation Council (27), DBS Foundation (22), National Science Foundation (20) |
| Strategic        | 916      | 1,565       | $14.0M         | Citi Ventures (18), Visa (13), Coinbase Ventures (8), Mastercard (7), Servicenow Ventures (7)                                                                 |

### Rising investors: 2025–2026 pace vs 2019–2024 (top 50)

Investors with at least 8 rounds from January 2025 to June 2026, ranked by the ratio of yearly pace (18 months now vs 6 years before).

| #   | Investor                                           | Type       | HQ             | Rounds 2019–2024   | Rounds Jan 2025–Jun 2026   | Rounds per year before   | Rounds per year now   | Top sector                           | First round   |
|:----|:---------------------------------------------------|:-----------|:---------------|:-------------------|:---------------------------|:-------------------------|:----------------------|:-------------------------------------|:--------------|
| 1   | 1789 Capital                                       | PE         | –              | 0                  | 15                         | 0.0                      | 10.0                  | Semiconductors                       | 2025          |
| 2   | Enrission India Capital                            | VC         | India          | 1                  | 11                         | 0.2                      | 7.3                   | Retail                               | 2024          |
| 3   | HSG                                                | VC         | United States  | 0                  | 11                         | 0.0                      | 7.3                   | Retail                               | 2025          |
| 4   | Zeropearl VC                                       | VC         | –              | 0                  | 11                         | 0.0                      | 7.3                   | Consumer                             | 2025          |
| 5   | Avra                                               | PE         | –              | 1                  | 10                         | 0.2                      | 6.7                   | Fintech                              | 2024          |
| 6   | British Business Bank’s South West Investment Fund | government | –              | 1                  | 8                          | 0.2                      | 5.3                   | Enterprise Applications              | 2024          |
| 7   | Titan Capital Winners Fund                         | VC         | –              | 1                  | 8                          | 0.2                      | 5.3                   | Food and Agriculture                 | 2024          |
| 8   | IAN Alpha Fund                                     | VC         | –              | 2                  | 13                         | 0.3                      | 8.7                   | Consumer                             | 2024          |
| 9   | Balerion Space Ventures                            | VC         | –              | 2                  | 11                         | 0.3                      | 7.3                   | Aerospace, Maritime and Defense Tech | 2024          |
| 10  | Anthropic                                          | CVC        | United States  | 2                  | 9                          | 0.3                      | 6.0                   | High Tech                            | 2024          |
| 11  | Z47                                                | VC         | India          | 6                  | 26                         | 1.0                      | 17.3                  | Fintech                              | 2024          |
| 12  | Entourage                                          | VC         | –              | 2                  | 8                          | 0.3                      | 5.3                   | Real Estate and Construction Tech    | 2024          |
| 13  | UNLEASH Capital Partners                           | VC         | –              | 2                  | 8                          | 0.3                      | 5.3                   | Fintech                              | 2024          |
| 14  | Tether                                             | CVC        | United States  | 4                  | 15                         | 0.7                      | 10.0                  | Fintech                              | 2024          |
| 15  | MGX                                                | PE         | –              | 4                  | 12                         | 0.7                      | 8.0                   | High Tech                            | 2024          |
| 16  | Gates Foundation                                   | other      | –              | 4                  | 11                         | 0.7                      | 7.3                   | Healthtech                           | 2020          |
| 17  | Marunouchi Innovation Partners                     | VC         | Japan          | 3                  | 8                          | 0.5                      | 5.3                   | Energy Tech                          | 2024          |
| 18  | Susquehanna Asia VC                                | VC         | –              | 3                  | 8                          | 0.5                      | 5.3                   | Consumer                             | 2024          |
| 19  | Tenity                                             | VC         | Switzerland    | 3                  | 8                          | 0.5                      | 5.3                   | Fintech                              | 2023          |
| 20  | Blue Owl Capital                                   | PE         | United States  | 5                  | 13                         | 0.8                      | 8.7                   | Fintech                              | 2021          |
| 21  | Washington Harbour Partners                        | VC         | United States  | 5                  | 13                         | 0.8                      | 8.7                   | Aerospace, Maritime and Defense Tech | 2022          |
| 22  | a16z Speedrun                                      | VC         | –              | 6                  | 15                         | 1.0                      | 10.0                  | High Tech                            | 2024          |
| 23  | Ritual Capital                                     | VC         | United States  | 4                  | 9                          | 0.7                      | 6.0                   | Enterprise Applications              | 2024          |
| 24  | ARK Invest                                         | VC         | United States  | 5                  | 11                         | 0.8                      | 7.3                   | High Tech                            | 2023          |
| 25  | TIAA Ventures                                      | VC         | United States  | 6                  | 13                         | 1.0                      | 8.7                   | Fintech                              | 2020          |
| 26  | Highlight Capital                                  | VC         | China          | 4                  | 8                          | 0.7                      | 5.3                   | Life Sciences                        | 2019          |
| 27  | Goldman Sachs Alternatives                         | PE         | –              | 11                 | 20                         | 1.8                      | 13.3                  | Enterprise Applications              | 2024          |
| 28  | Growth Equity at Goldman Sachs Alternatives        | PE         | –              | 7                  | 12                         | 1.2                      | 8.0                   | Enterprise Applications              | 2024          |
| 29  | IIMA Ventures                                      | VC         | India          | 6                  | 10                         | 1.0                      | 6.7                   | Consumer                             | 2024          |
| 30  | Shastra VC                                         | VC         | India          | 6                  | 10                         | 1.0                      | 6.7                   | High Tech                            | 2021          |
| 31  | Collide Capital                                    | VC         | United States  | 6                  | 9                          | 1.0                      | 6.0                   | Enterprise Applications              | 2022          |
| 32  | AMD                                                | CVC        | –              | 13                 | 19                         | 2.2                      | 12.7                  | High Tech                            | 2023          |
| 33  | Lingotto                                           | VC         | Netherlands    | 7                  | 10                         | 1.2                      | 6.7                   | Healthtech                           | 2022          |
| 34  | 360 ONE Asset                                      | VC         | –              | 11                 | 15                         | 1.8                      | 10.0                  | Healthtech                           | 2023          |
| 35  | Hedosophia                                         | VC         | United Kingdom | 11                 | 15                         | 1.8                      | 10.0                  | Fintech                              | 2021          |
| 36  | NATO Innovation Fund                               | VC         | –              | 6                  | 8                          | 1.0                      | 5.3                   | High Tech                            | 2024          |
| 37  | Transition VC                                      | VC         | –              | 6                  | 8                          | 1.0                      | 5.3                   | Auto                                 | 2023          |
| 38  | British Business Bank                              | government | United Kingdom | 17                 | 22                         | 2.8                      | 14.7                  | Life Sciences                        | 2020          |
| 39  | HSBC Innovation Banking                            | CVC        | United Kingdom | 7                  | 9                          | 1.2                      | 6.0                   | Fintech                              | 2023          |
| 40  | Finvolve                                           | VC         | India          | 8                  | 10                         | 1.3                      | 6.7                   | Consumer                             | 2023          |
| 41  | D. E. Shaw Group                                   | VC         | –              | 7                  | 8                          | 1.2                      | 5.3                   | High Tech                            | 2021          |
| 42  | QIC                                                | VC         | Australia      | 7                  | 8                          | 1.2                      | 5.3                   | Edtech                               | 2021          |
| 43  | Veteran Ventures Capital                           | VC         | United States  | 7                  | 8                          | 1.2                      | 5.3                   | High Tech                            | 2023          |
| 44  | AVP                                                | VC         | –              | 8                  | 9                          | 1.3                      | 6.0                   | Fintech                              | 2021          |
| 45  | Nventures                                          | CVC        | United Kingdom | 28                 | 31                         | 4.7                      | 20.7                  | High Tech                            | 2022          |
| 46  | DeVC                                               | VC         | India          | 18                 | 18                         | 3.0                      | 12.0                  | Fintech                              | 2023          |
| 47  | GVFL                                               | VC         | –              | 17                 | 17                         | 2.8                      | 11.3                  | Food and Agriculture Tech            | 2019          |
| 48  | J2 Ventures                                        | VC         | United States  | 10                 | 10                         | 1.7                      | 6.7                   | Fintech                              | 2021          |
| 49  | Merak Ventures                                     | VC         | India          | 10                 | 10                         | 1.7                      | 6.7                   | Fintech                              | 2020          |
| 50  | Zero Infinity Partners                             | VC         | United States  | 8                  | 8                          | 1.3                      | 5.3                   | Environment Tech                     | 2022          |

### Investor activity by year

| Year           | Rounds with a named investor   | Active investors   | First-time investors   | Organisation investors per round   |
|:---------------|:-------------------------------|:-------------------|:-----------------------|:-----------------------------------|
| 2019           | 6,250                          | 6,553              | 6,553                  | 2.72                               |
| 2020           | 7,580                          | 8,032              | 4,715                  | 2.83                               |
| 2021           | 11,984                         | 12,000             | 6,724                  | 3.21                               |
| 2022           | 11,193                         | 12,702             | 5,758                  | 3.20                               |
| 2023           | 9,404                          | 11,306             | 4,332                  | 2.93                               |
| 2024           | 9,145                          | 11,048             | 3,774                  | 3.06                               |
| 2025           | 6,896                          | 9,038              | 2,577                  | 3.13                               |
| 2026 (Jan–Jun) | 2,347                          | 4,422              | 877                    | 3.32                               |

## Method

1. **Source rounds.** The cleaned global startup funding table (January 2019 to June 2026, companies founded in 2000 or later, venture-style instruments only, repeated reports merged within 45 days). Two days on which archives of older articles were loaded with the load date instead of the publication date (2024-04-22 and 2025-02-13, about 1,200 rounds) are excluded.
2. **Organisations only.** An investor name is kept when it reads as an organisation and not as a person: generic phrases ("angel investors", "undisclosed", "existing investors"), names with a personal title (founder, CEO, partner at ...), "First Last" names whose first word is a given name learned from the data, and possessive or descriptive phrases are dropped. Names of data providers are dropped.
3. **Aliases.** Spellings are merged on a key that ignores case, punctuation and suffixes such as Capital, Ventures, Partners, LLC and Ltd, plus a short list of known aliases (a16z = Andreessen Horowitz, Peak XV = Sequoia Capital India). Distinct regional arms such as "Matrix Partners India" stay separate.
4. **Lead.** A round counts as led when any report of it flagged the investor as lead, or when it was the only investor named. Many reports name no lead, so lead counts are lower bounds.
5. **Website and headquarters.** The website is the news-reported domain whose name matches the investor; it is rejected when the company register lists that domain as an unrelated business. Six of the most active investors have a hand-checked website. Headquarters country and city come from the company record behind that website, or from a country in the name.
6. **Type, by rule (first match wins).** accelerator (accelerator, incubator, studio names); government (public agencies, development banks, sovereign funds); CVC (venture arms of corporates and banks, and corporates investing directly); bank-debt (banks, lenders and investors whose rounds are mostly debt); PE (buyout, growth-equity and asset-management names, or 60%+ growth rounds with a median round of US$50M+); VC (venture names, investment-firm records or mostly staged venture rounds); other (angel networks, family offices, foundations, pension and insurance money, crowdfunding platforms, the rest).
7. **Stage mix.** Seed = pre-seed, angel, seed; early = pre-Series A to Series B; growth = Series C and later plus growth/PE. Shares use staged rounds only. `median_round_usd` is the median disclosed size of the whole rounds it joined, not its own cheque.

8. **Sample.** Each investor key is ranked by `sha1(key)`. Keys are taken in rank order until the file holds max(25%, 5,000) rows (capped at 100,000).

9. **Profile links.** Links are built from Fliar's company index and checked against it. A row whose company has no public profile has an empty link.

## Columns

| Column                | Description                                                                                 |
|:----------------------|:--------------------------------------------------------------------------------------------|
| `investor_slug`       | URL-style slug of the investor name (the key for the Radar investor-profile endpoint)       |
| `investor_name`       | investor organisation name (people and generic phrases removed; aliases merged)             |
| `investor_domain`     | investor website domain when it could be matched to the name ("" when unknown)              |
| `hq_country`          | headquarters country, from the investor's company record ("" when unknown)                  |
| `hq_city`             | headquarters city, from the same record ("" when unknown)                                   |
| `investor_type`       | VC / CVC / PE / accelerator / bank-debt / government / other, assigned by rule (see Method) |
| `deals`               | funding rounds the investor joined, January 2019 to June 2026                               |
| `lead_deals`          | rounds where a report named it as lead, or it was the only investor named                   |
| `portfolio_companies` | distinct companies in those rounds (the list itself is in the API)                          |
| `first_deal_year`     | year of its first round in the data                                                         |
| `last_deal_year`      | year of its latest round in the data                                                        |
| `deals_2025_2026`     | rounds joined from January 2025 to June 2026                                                |
| `top_sectors`         | up to 3 most frequent sectors of its portfolio rounds, separated by "; "                    |
| `top_countries`       | up to 3 most frequent company countries of its rounds, separated by "; "                    |
| `seed_share`          | share of its staged rounds at pre-seed, angel or seed (0-1)                                 |
| `early_share`         | share of its staged rounds at pre-Series A to Series B (0-1)                                |
| `growth_share`        | share of its staged rounds at Series C or later, or growth/PE (0-1)                         |
| `median_round_usd`    | median disclosed size of the rounds it joined, US$ (whole round, not its cheque)            |
| `fliar_profile_url`   | full company profile on Fliar (financials, funding, team, news)                             |

**Available only through the [Radar API](https://github.com/fliarbi/radar-api-mcp):** portfolio company list with round dates, stages and amounts; co-investors on each deal; partner and contact details; fund sizes and fund vehicles; the remaining investors and the monthly refresh.

## Limitations

- Built from news: rounds that were never reported are missing, and coverage is stronger for larger and English-reported deals.
- Investor names come from article text, so a small number of aliases stay split and a few unrelated firms with the same normalised name may be merged.
- Lead investors are often not reported; `lead_deals` is a lower bound.
- Websites are matched for fewer than half of the investors, and headquarters for a similar share; a matched website can occasionally belong to a same-named company.
- Types are rule-based and approximate, especially the boundary between VC, PE and asset managers.
- 2026 covers January to June only.

## Citation

Fliar Research (2026). *VC Investor Directory 2026: 35k Startup Investors* (sample release). Data: Radar API, https://github.com/fliarbi/radar-api-mcp. Licence CC BY-NC 4.0.
